#!/usr/bin/env bash
set -euo pipefail

# Independent clip/recipe controller. User starts training; no automatic evaluation or sweeps.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
VQ_DIR="${SCRIPT_DIR}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep"
LABEL_DIR="${SCRIPT_DIR}/checkpoints/flowmatch_tf150_staged_noise"
cmd=("${PYTHON_BIN}" "${SCRIPT_DIR}/train_flowmatch_vqvae_controller.py"
  --db "${DB:-${SCRIPT_DIR}/database_100sty_375_memmap}"
  --vqvae-ckpt "${VQ_CKPT:-${VQ_DIR}/best.pt}"
  --norm-stats "${NORM_STATS:-${VQ_DIR}/norm_stats.npz}"
  --latent-stats "${LATENT_STATS:-${LABEL_DIR}/latent_stats.npz}"
  --vq-target-cache "${VQ_TARGET_CACHE:-${SCRIPT_DIR}/cache/vq_targets_vq150ep_repair_v2}"
  --style-code-prior "${STYLE_CODE_PRIOR:-${SCRIPT_DIR}/cache/style_code_prior_vq150ep_repair_v2.npz}"
  --out-dir "${OUT:-${SCRIPT_DIR}/checkpoints/flowmatch_recipe_tf50}"
  --epochs 50 --lr-schedule-epochs 50 --seed 42
  --conditioning-mode recipe --recipe-prob 1 --recipe-frames 240 --recipe-exemplar-choices 1 3 5
  --recipe-bank-size 64
  --seq-len 2 --stride 1 --unroll-steps 1 --no-train-feedback-context
  --batch-size 512 --microbatch-size "${MICROBATCH_SIZE:-128}"
  --prediction-mode target --flow-loss-space normalized
  --lr 1e-4 --min-lr 1e-5 --weight-decay 1e-4 --grad-clip 1
  --flow-hidden-dim 256 --flow-layers 2 --flow-heads 4 --flow-ffn-dim 1024 --dropout 0
  --style-num-slots 8 --style-selector-topk 4 --style-selector-temperature 1
  --style-proto-normalization none --style-selector-init random
  --style-hist-weight 0 --style-entropy-weight 0
  --recon-weight 0 --root-recon-weight 0 --style-consistency-weight 0
  --decouple-latent matched_root --decouple-prob "${DECOUPLE_PROB:-0.3}"
  --history-noise-mode structured --history-noise-start-epoch 51 --history-noise-probability .3
  --prev-latent-noise-std .3 --prev-motion-noise-std .2 --history-root-noise-std .05
  --prev-latent-dropout 0 --prev-motion-dropout 0
  --noise-std 1 --solver-steps 8 --inference-requantize --inference-latent-clip
  --matmul-precision highest --no-tf32 --rollout-val-every 0
  --val-every 1 --save-every 5 --num-workers 8 --prefetch-factor 4)
if [[ -n "${RESUME:-}" ]]; then
  cmd+=(--resume "${RESUME}")
else
  cmd+=(--init-ckpt "${INIT_CKPT:-${LABEL_DIR}/best.pt}")
fi
if [[ -n "${DEVICE:-}" ]]; then cmd+=(--device "${DEVICE}"); fi
cmd+=("$@")
printf '[Run]'
printf ' %q' "${cmd[@]}"
printf '\n'
if [[ "${DRY_RUN:-0}" != "1" ]]; then "${cmd[@]}"; fi
