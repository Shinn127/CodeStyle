# FlowMatch / style prior 修复版 v2

本文保留 v2 基线说明。当前直接训练入口的 style 默认设置已更新，见 [`STYLE_REFINEMENT_RUNBOOK.md`](STYLE_REFINEMENT_RUNBOOK.md)；`run_repair_pipeline.py` 显式使用 v2 的 random 初始化、LayerNorm、entropy=.02 和 recipe=0，仍可重现这里的基线配置。

本次仅修改实现并运行轻量 CPU fixture 验证。没有启动真实数据训练、GPU smoke、全量 cache/precompute 或 test 评估。论文近似联合指标是否恢复，仍需下面的独立实验验证；不使用历史每 epoch 速度推算本版耗时。

## 冻结 VQ 与训练目标

固定使用 `checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt` 及同目录 normalization。encoder、codebook、decoder 全部 `requires_grad=False`、eval，optimizer 只包含控制器参数。移除 decoder 的 `no_grad` 是为了让 reconstruction loss 穿过固定 decoder 更新 flow/selector，不是联合训练 VQ。缓存、目标编码、推理仍禁用梯度。

保留现有 6-token transformer（hidden=256、2 layers、FFN=1024）。新训练默认 target + normalized MSE；旧配置缺少字段时保留旧 loss 语义。reconstruction/root L1 使用 continuous Euler 输出与原始 GT 或 matched_root 合成目标。反馈统一为 clip → quantize → decode，motion 与反馈 latent 匹配，默认 detach。

matched_root 在完整有效 batch 上选择同动作 suffix、另一 style 的窗口 donor。所有目标帧满足平面速度与 yaw 阈值；均匀选合格 style 后按 root/yaw/四个脚部位置选最近 donor。目标保留 source root，使用 donor pose/rotation，修正 joint velocity 并在线重新编码 source trajectory + 合成 motion。无候选时回退原样本，日志记录实际 `decoupled_fraction`。该分支消除监督冲突，其风格/内容解耦效果尚未由实验验证。

## 手动执行有界流水线

在 NewCode 目录、mcc 环境运行。以下命令已做参数检查及 dry-run，真实作业未执行：

```bash
cd /home/shinn/桌面/multimedia/revision/NewCode
conda activate mcc
python analysis/run_repair_pipeline.py --mode all --dry-run --microbatch-size 128
python analysis/run_repair_pipeline.py --mode prepare
python analysis/smoke_repair_controller.py --output checkpoints/flowmatch_repair_smoke --microbatch-size 128
python analysis/run_repair_pipeline.py --mode train --microbatch-size 128
python analysis/run_repair_pipeline.py --mode evaluate
```

`prepare` 在独立 `cache/vq_targets_vq150ep_repair_v2`、`cache/style_code_prior_vq150ep_repair_v2.npz` 生成新 artifacts，已有 artifacts 只在内容验证通过后复用。中断缓存会被拒绝；重建请指定新目录，或直接 precompute 时明确传 `--overwrite`。旧缓存/结果不迁移、不覆盖。

`smoke` 每配置 100 optimizer updates，额外检查 60/600 帧 rollout、VQ 状态及 feedback 一致性，输出耗时、峰值显存、按实测训练部分外推的 50 epoch GPU 小时（不含完整验证、准备与 test）。这 300 updates 写入单独目录，不计入正式训练。未运行 smoke，因此当前没有实测 GPU 小时或显存结论。

`train` 顺序 A/B/C，各最多 50 epoch，总上限 150，seed=42，失败立即停止。B 从 A 的验证 best 初始化，C 从 B 的验证 best 初始化；只继承兼容权重，重置 optimizer/scheduler/RNG。不会追加 sweep、seed 或 epoch。有效 batch=512；`--microbatch-size 512/256/128` 分别对应一次/两次/四次反传，donor 在切分前选择、每次 optimizer update 只裁剪一次。OOM 时手动使用更小 microbatch 和新 run 目录；128 仍失败则停止。严格 resume 不允许改变 microbatch，以保证同环境 epoch 边界复现。

| 阶段 | seq / unroll | decouple | root weight | lr |
|---|---|---|---:|---:|
| A | 2 / 1 | 0 | 0 | 5e-4 |
| B | 3 / 2 | 0 | 0 | 1e-4 |
| C | 3 / 2 | matched_root 0.3 | 0.1 | 1e-4 |

固定 FP32、highest、TF32=False、Euler8、noise=1、top-k=4、temperature=1、dense prior、8 slots；flow/recon/prior/entropy 权重 1/.1/.02/.02。三阶段 style consistency 都关闭。clip-style 仍是 clip → VQ histogram → recipe → style token，没有新增 learned clip encoder/content MLP。

## 保存、初始化与续训

- `best_loss.pt`：teacher-forced validation loss；`best.pt`：每 5 epoch 固定 90 个未镜像 validation clips × 3 个 60 帧窗口 × 2 个 cross targets 的联合选择。先比较 ADE 约束是否通过，再比较规划中的 J。全部未过约束时保存最低 J 诊断候选，并记录 `constraints_passed=false`。
- `latest.pt`：保存更新后的 best 状态、optimizer、cosine scheduler、Python/NumPy/Torch CPU/CUDA RNG。train shuffle、worker seed 与 validation 随机数独立。保存采用临时文件替换。
- `--init-ckpt PATH`：同 prediction mode、模型形状、slot 顺序、VQ 内容的权重初始化。不会加载 optimizer/scheduler/RNG；新数据的 prior 和 latent stats 重新设置。velocity→target 的权重转换不在此入口支持范围。
- `--resume PATH`：仅允许同实现/目标版本、data/VQ/norm/prior/cache/latent stats/classifier 内容、loss、反馈策略及关键配置的训练状态。运行流水线 `--mode train` 会续跑已有兼容 `latest.pt`；已完成 50 epoch 的阶段不重复训练。
- 旧 controller 仍可加载评估，缺省反馈 continuous+clip。旧训练状态不能直接 resume；兼容旧模型可作为 init 源。显式 `--legacy-inference-order` 才重放历史 quantize→decode→clip 顺序。VQ override 必须与 checkpoint 内嵌权重相同。

新版缓存、prior、train-only latent stats 与 controller 记录数据库帧内容、split、VQ state 和 normalization 指纹；同路径内容替换会被拒绝，内容相同的路径迁移可接受。`--allow-legacy-artifacts` 仅用于缺少溯源的历史诊断，不用于 A/B/C。nearest-code 在不同设备/chunk 下可能因距离 margin 小而不同，不能用 CPU/GPU 逐码完全一致作为跨设备验收。

## 评估与接口

`evaluate` 先依据已保存 validation selection 锁定最终 checkpoint，随后统一 test：三阶段全部 60 帧/stride30 运动质量、1,000 sources × 5 seen targets；最终模型 4/8/16 ODE、100 个 600 帧长 rollout、OOD 五个独立 240 帧 exemplars/style 和保留 clips 的 real-motion reference。每个 case 的 Gaussian noise 按 seed/source_start/target 哈希生成，独立于 batch size 与 ODE steps。

输出包括 `seen_cases.json`、逐样本结果、source_entry_id 聚类 bootstrap 1,000 次 CI、`path_diagnostics.json`（continuous/quantized AE、teacher-forced/rollout）、`long_rollout.json`、OOD recipe provenance、`acceptance.json`、`paper_comparison.md`，以及 matched/cross/OOD/600 帧/style-switch 的 NPZ、BVH 和 root 图。主评估无 decode smoothing。零 contact 的 F.S. 标为不可用；local 历史口径与新增 world F.S./contact coverage 分别报告。global/style/clip FID 使用同一固定 extractor，各自命名。

需要旧 baseline 同一 seen manifest 重测时，直接调用：

```bash
python analysis/evaluate_repair_protocol.py \
  --runs checkpoints/flowmatch_repair_v2/A/best.pt checkpoints/flowmatch_repair_v2/B/best.pt checkpoints/flowmatch_repair_v2/C/best.pt \
  --out checkpoints/flowmatch_repair_v2/evaluation \
  --legacy-baselines /absolute/path/to/legacy/best.pt
```

手动诊断：

- `evaluate_motion_375to291.py --vq-eval-path pre_vq|quantized`；主 VQ path=quantized。
- `--flow-eval-mode reconstruct|rollout` 区分 teacher-forced controller 与自回归。
- `--no-flow-requantize-z` 显式启用 continuous 反馈；`--flow-latent-clip/--no-flow-latent-clip` 控制量化前 clipping。
- recipe 支持 `[M,K]`、`[1,M,K]` 广播与 `[B,M,K]` 逐样本；label+recipe 可以缺省 slots，pure recipe/OOD 必须全 slots、strength=1。NaN、负概率、空 slot、错误 VQ 指纹和 slot 顺序会被拒绝。历史无 metadata JSON 需显式 `--allow-legacy-recipe`。
- library `reconstruct_motion_batch` 的 `[B,T]` labels 支持 style 切换。style-consistency 研究分支传 motion291 stats[84:]、按名称映射 classifier labels；classifier 冻结/eval，输入梯度保留。

九项联合验收阈值已写入评估脚本，必须同一 validation-selected checkpoint、Euler8、同一主反馈设置共同满足。没有通过时报告分路径差距，不拼接阶段最好值，也不追加训练。

## 本次验证边界

执行全套现有轻量测试及新增有针对性的 regression：recon-only 梯度、VQ/EMA 不变、target/velocity、真实 epoch 与 tiny-DB CLI 的单步/展开/matched_root、索引与反馈一致、regularizer 权重、合成速度修正与 cache 开关、recipe 广播/OOD、style-loss normalization/名称映射与梯度、train-only stats、缓存替换检测、实际 CLI epoch resume 数值一致、best/latest 顺序、旧模型读取/override 校验、world foot sliding/零 contact、现有 BVH 导出。

CPU fixture 全部使用临时目录、小模型、小数据库；实际 CLI 续训一致性在 num_workers=0 下验证，worker/shuffle 的独立随机流另有单元测试。它们验证实现，不提供运动质量或论文复现数字。新版 precompute 完成前默认抽查 3 个同设备、同精度、同 chunk 的缓存块，失败会保留 incomplete 标记。真实缓存抽查、GPU 100-step smoke、真实 90-style rollout、正式训练与最终 test 尚未执行。
