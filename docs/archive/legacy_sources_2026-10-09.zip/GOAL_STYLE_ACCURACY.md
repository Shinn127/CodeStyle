# 目标追踪：style 准确率 matched ≥ 85 / cross ≥ 80

协议（与 `run_evaluate_minor_revision_generalization.sh --horizons 60` 一致）：1000 个测试源片段，
cross 每源 5 个随机目标风格；60 帧 rollout；分类器 = `fid_feature_extractor_camdm100_mirror`
（100 类、45 维 ybot、含镜像训练）；每 clip 一次 60 帧窗口判决（h=60 时窗口数正好为 1）。

## 1. 战果表（同一口径实测）

| 配置 | matched | cross | matched RootADE | cross RootADE |
|---|---|---|---|---|
| **目标** | **≥85** | **≥80** | 参考 | 参考 |
| real motion 上界 | 96.40 | — | — | — |
| VQ AE 路径（teacher-forced，仅表征层） | 91.33 | — | — | — |
| 配对训练基线（p=0，50 ep） | 64.90 | 10.44 | 1.348 | 1.790 |
| **解耦 p=0.2（donor latent，20 ep）** | **67.80** | **57.14** | 3.930 | 9.292 |
| 解耦 p=0.3（donor latent，20 ep） | **72.20** | **66.62** | 4.104 | 9.406 |
| 论文 R2 表（无法复现出处） | 84.40 | 71.02 | 2.747 | 3.088 |

## 2. 廉价（推理端）杠杆——已封顶，实测

对 p=0.2 检查点做推理端变换（n=120 源，CI≈±8）：

| 变体 | matched | cross |
|---|---|---|
| raw, 8 步（默认） | 60.83 | 58.33 |
| raw, 16 步 | 62.50 | 56.67 |
| raw, 32 步 | 65.00 | 58.00 |
| 因果 EMA α=0.5 | 65.00 | 57.33 |
| 因果 EMA α=0.3 | **66.67** | 56.50 |
| 3-tap 二项式 | 63.33 | 57.00 |
| 5-tap 二项式 | 63.33 | 56.00 |

结论：推理端最多 +5（且在噪声内），**cross 完全不动**；且 h=60 时每 clip 只有 1 个分类窗口，
没有"多窗口平均"这种杠杆。→ 目标必须靠训练侧解决。

（此前的 token 干预诊断同样封顶：τ 锐化、token 放大、推理期混先验全部无效或有害，见
`RUN_STYLE_PRIOR_50EP.md` §9。）

## 1b. 筛选轮结果（retarget 解耦，各 25 ep，同一口径）

| 配置 | matched | cross | RootADE (m/c) | 判定 |
|---|---|---|---|---|
| retarget p=0.5 | 73.70 | 69.34 | 6.30 / 11.39 | 可用 |
| retarget p=0.7 | 71.10 | 69.76 | 13.72 / 20.45 | **轨迹不可用**（>8 cm 守卫线）|
| **retarget p=0.5 + 条件噪声 0.6** | **73.40** | **71.98** | 7.38 / 13.52 | **赢家**（分数 145.4）|

- p=0.7 饱和并反噬（matched 掉、RootADE 恶化到 13.7）→ **p=0.5 是甜点**。
- 说明：retarget 并没有像预期那样修复轨迹——因为 retarget 的目标 latent 是
  `encode(源轨迹, donor 动作)` 这种**合成组合**，VQ 编码器训练时从未见过，量化后落在码边界附近，
  解码不稳定。**轨迹与风格在 latent 里是纠缠的**（编码器看 traj+motion，解码器只出 motion），
  这是这套架构的结构性问题；要两者兼得需要改 VQ（让解码器显式条件于轨迹）或加轨迹一致性损失。
- 筛选后自动选了赢家并启动 150 epoch 长训练（`checkpoints/flowmatch_vqvae_controller_goal_long`）。

## 1c. re-quantization 实测（评估期开关，零训练成本）

现状：**没有在用**。训练目标是 VQ 缓存里的**量化** latent，但评估 rollout 解码的是**连续**预测 latent
（`--flow-requantize-z` 默认关），而部署运行时（Unity/Sentis）解的是**码本条目** —— 三者不一致。

对两个最优检查点开启 `--flow-requantize-z` 重测（同一批 1000 源 × 5 目标，h=60）：

| 配置 | req 关（当前口径） | req 开 | 变化 |
|---|---|---|---|
| retarget p=0.5 | 73.70 / 69.34（RootADE 6.30/11.39）| 72.30 / 68.36（6.61/12.05）| −1.40 / −0.98 |
| retarget p=0.5 + 噪声 0.6 | 73.40 / 71.98（7.38/13.52）| 72.60 / 70.74（8.03/13.97）| −0.80 / −1.24 |

结论：对**未按 requantize 训练**的模型，评估期开 requantize 是**轻微负收益**（之前对配对基线也测到 jitter +6%、
FID 变差）。原因：flow 损失的回归目标是码嵌入，连续预测是邻近码的"混合"，解码它天然比任何单码更平滑；
一旦 requantize 就跳变到单码，反而增加换码抖动。**requantize 只有在训练侧也一致（展开回放时也 requantize）
才可能变成正收益**——那时模型学会"预测能被量化到好码的 latent"，也正是部署语义。

已落地：`unrolled_flow_loss(..., requantize_feedback=True)`（默认开）——展开训练回放时把反馈 latent
量化到码本，与运行时/`--requantize-z` 评估一致；3 项新单测（中间步数恰为 steps−1 次、关闭则 0 次、
目标值确实不同）→ 全套 110 passed。**尚未跑任何据此的完整训练**。

## 2b. p 的标度律（donor latent，20 ep，同一口径）

| p | matched | cross |
|---|---|---|
| 0（配对） | 64.90 | 10.44 |
| 0.2 | 67.80 | 57.14 |
| 0.3 | **72.20** | **66.62** |

→ **两项都随 p 单调上升**（cross 每 +0.1p 约 +10 点），且 donor-latent 的轨迹代价（RootADE≈4.1/9.4）
是当前唯一拖累项——正是 retarget 要修的。因此筛选轮直接上 p=0.5 / 0.7 + retarget。

## 3. 差距分解（为什么 matched 卡在 68）

| 阶段 | matched | 说明 |
|---|---|---|
| real motion | 96.4 | 分类器上限 |
| VQ AE 路径 | 91.3 | 表征层几乎无损 → **不是 VQ 的问题** |
| 控制器 rollout | 67.8 | 自回归 rollout 的运动质量（MPJPE≈6 cm、jitter 0.83 vs AE 1.3/0.23）导致分类判决退化 |

要把 matched 推到 85，rollout 质量必须接近 AE 路径——这是主攻方向。

## 4. 训练侧杠杆与队列（按目标价值排序）

| # | 杠杆 | 状态 | 预期 |
|---|---|---|---|
| 1 | **retarget 解耦**（轨迹保留；`--decouple-latent retarget`）| 已实现+单测，队列首个 50 ep 运行 | cross 维持 ~57 且 RootADE 回落 → 运动回到流形，**两项都可能上行** |
| 2 | 高 p（0.5）| 队列中（同上） | cross ↑ |
| 3 | 更长训练（50 → 150 ep）| 待前两项结果 | matched ↑（val flow 在 ep20 仍在降） |
| 4 | **自回归展开训练**（scheduled sampling / k-step unroll）| ✅ **已实现**（`--unroll-steps`，6 项单测，全套 107 passed）| 直接缩小 rollout-AE 质量差，是 matched 85 的主要希望 |
| 5 | style-consistency 损失（λ_sc）| 已实现+单测；弱代理（帧级 61% held-out） | 直接优化报告指标，风险是代理噪声 |
| 6 | 条件噪声增强（prev noise 0.3→0.6）| 队列中 | rollout 鲁棒性 |

**自驱动流水线**（`analysis/run_goal_pipeline.sh`，已挂后台）：
1. 运行中：筛选轮 3 × 25 ep —— `retarget p=0.5` / `retarget p=0.7` / `retarget p=0.5 + 条件噪声 0.6`（各带评测）
2. 自动按 (matched+cross) 选赢家 → **150 epoch 长训练 + 评测**
3. 若仍未达标 → 赢家配置 + **`--seq-len 3 --unroll-steps 2`（自回归展开）60 epoch + 评测**

自回归展开实现要点（`unrolled_flow_loss`）：按评测器的 rollout 逐步回放，每步的条件为
（真实的未来轨迹, 模型自己上一步解码出的动作），prev latent 也换成模型自己的预测（detached），
每步都施加 flow/recon 损失；`steps=1` 严格退化为原目标（有单测钉住）。解耦在窗口路径上同样支持
（donor 的 latent 与"由其解码出的动作"一起换），并修掉了一个链式 donor 的错配 bug。

## 5. 诚实评估

- cross 80 有现实路径：p=0.2 已达 57.1（相对 chance 50×），retarget + 更高 p + 更长训练有望推到 70–80。
- **matched 85 是硬骨头**：需要 rollout 运动质量接近 AE 路径（91.3%）。若 50 ep retarget 只把 matched
  推到 ~70，则必须上"自回归展开训练"（第 4 项）——那是唯一直接攻击 exposure bias 的手段。
- 参考：论文 R2 的 84.40/71.02 在仓库内无出处，其 rollout MPJPE（论文自身消融表 6.0–6.3 cm）与我们同级，
  因此在**我们的协议下**达到 85/80 需要明显优于论文自身控制器的生成质量，而不是"对齐表里的数字"。
- 明确不做：用同一个分类器做推理期引导（自证循环，属指标作弊）。
