# 保持论文核心逻辑的 style 修订版 v3

本版保留 `label → learned selector → top-4 code mixture → 拼接 prototype → P → style token → conditional flow`，以及 `exemplar clip → 冻结 VQ histogram → recipe → 同一个 P` 的 OOD 接口。prior 计数、Laplace smoothing=1、JS saliency、8 slots、top-k=4、temperature=1 均不改变。保留现有 6-token / hidden256 / 2-layer / FFN1024 控制器、target flow、cosine scheduler 和 v2 的展开/反馈修复。

VQ encoder、codebook、decoder 全部冻结并保持 eval，optimizer 只更新控制器。reconstruction 梯度通过固定 decoder 回传，不更新 decoder 或 VQ EMA。style classifier 不参与默认训练优化。

FP32 提效实现与短测见 [`FP32_PERFORMANCE.md`](FP32_PERFORMANCE.md)。新 run 默认 microbatch512、CUDA fused AdamW；128×4 的历史 run 续训须显式保留原 microbatch128，不能原地改变严格续训配置。下方手动命令更新为512。

## 三项默认修订及依据

1. **从 prior 初始化现有 selector。** 保留现有 label embedding 和 MLP，只用一次线性最小二乘初始化最后一层，让初始 dense softmax 接近对应 train prior。目标 logits 为 `temperature × log(prior)`，去掉每个 slot 的均值；隐藏特征设计矩阵必须满行秩，初始化后检查概率误差。没有添加固定 log-prior residual、额外网络或训练损失。仅从头训练初始化；`--init-ckpt` 和 `--resume` 保留已有 selector 权重。
2. **原始 prototype 直接进入 P。** 新训练默认 `--style-proto-normalization none`，避免额外 LayerNorm 抹去 prototype 的整体幅度/偏置差异。保留 code 向量加权求和与原有 P，符合论文 `P(concat(u_j))` 的表达。旧 LayerNorm 的 state keys 保留，关闭时其参数不训练。此修订保留已存在的信息，不能恢复 histogram 丢失的时序、联合分布或高阶矩。
3. **entropy 从 .02 降为 .003。** prior CE 权重仍为 .02。固定 top-k 支持 A 时，内部概率的 prior 约束实际乘以 `p(A)`，而 entropy 不乘该质量。历史 prior 的平均 top-4 mass≈.193，使两个权重同为 .02 时有效比例约 5.19；.003 时约 .78。较小的 entropy 减少近似单码塌缩压力，仍保留原 entropy 项。该尺度解释不保证所有 slots 稳定，也没有证明生成准确率提高。

prior 继续监督 dense softmax，CE 与 forward KL 的梯度相同；top-k 用于构造 token。对 Laplace-positive prior 与 hard sparse distribution 直接计算 forward KL 是无限值，旧 log-clamp 只能作历史数值替代。日志分别保存 CE、真实 KL、target entropy、selector entropy、top-1、覆盖情况和 actual conditioning entropy；不根据 CE 常数下界占 total loss 的比例判断梯度影响。推导和历史静态证据见 [`analysis/STYLE_PRIOR_ANALYSIS_2026-10-05.md`](analysis/STYLE_PRIOR_ANALYSIS_2026-10-05.md)。

## 默认配置与可选开关

| 参数 | v3 默认 | 保留的 v2 基线 |
|---|---|---|
| `--style-selector-init` | `prior`，仅 fresh run | `random` |
| `--style-proto-normalization` | `none` | `layernorm` |
| `--style-entropy-weight` | `.003` | `.02` |
| `--recipe-prob` | `0` | `0` |
| `--style-consistency-weight` | `0` | `0` |

默认训练始终通过 learned label selector。新增 `--recipe-prob > 0` 仅是显式研究开关，不属于默认论文复现路径：从 train 中未镜像的独立原始 clips 构造 recipe，排除当前 batch 的 source/donor 原始 clips，默认最多 5 个 240 帧 exemplar；不读取 val/test。样本 target label 在 donor 选择后确定，同一窗口和各 microbatch 使用同一配方。没有独立可用 clip 时回退 label，记录实际 `recipe_fraction`。正则项仍约束 learned selector，避免把不可优化的手动 recipe entropy 混作 selector 正则。训练与 OOD 导出共用 histogram/top-k helper。

该增强改变了训练条件的采样方式，应独立标注和验证；v3 A/B/C 脚本明确设置 `recipe-prob=0`。现有 label、partial label+recipe、共享 recipe、逐样本 recipe、pure OOD recipe 接口继续可用。

## 手动运行入口

在 `NewCode`、mcc 环境中使用。以下只展示命令，本次没有执行准备、GPU smoke、完整训练或真实数据评估。

```bash
cd /home/shinn/桌面/multimedia/revision/NewCode
conda activate mcc

# 默认只打印 A/B/C 命令，无训练副作用
python analysis/run_style_refinement.py --microbatch-size 512

# 数据来源与精度沿用 v2 修复版；需要时由使用者准备独立 cache/prior
python analysis/run_repair_pipeline.py --mode prepare --dry-run
python analysis/run_repair_pipeline.py --mode prepare

# 使用者按需进行实测；100 updates × 3 配置，另测 60/600 帧 rollout
python analysis/smoke_repair_controller.py --style-refinement \
  --output checkpoints/flowmatch_style_paper_v3_smoke --microbatch-size 512

# 必须显式 --execute 才训练；失败即停止，不追加 sweep/epoch
python analysis/run_style_refinement.py --microbatch-size 512 --execute
```

独立目录默认为 `checkpoints/flowmatch_style_paper_v3/A|B|C`，直接 trainer/wrapper 默认为其中的 `standalone`。已有 v2、历史 checkpoint 和结果不覆盖。A/B/C 沿用原先计划：seed42、每阶段最多50 epoch、总上限150；A 单步 matched 从头训练，B 从 A 的 validation best 只继承权重并展开2步，C 从 B 的 validation best 只继承权重，使用 matched_root probability=.3/root L1=.1。微调阶段不是独立从头消融。

有效 batch512，microbatch128/256/512；donor 在完整 batch 中选择。FP32/highest/TF32=False、Euler8、noise1、prior=.02、recon=.1、entropy=.003、style consistency=0。其他配置和验证集联合选择遵循 [`REPAIR_RUNBOOK.md`](REPAIR_RUNBOOK.md)。本次没有 GPU 耗时或显存测量。

若要从兼容的已有 **target** controller 开始新 A 阶段：

```bash
python analysis/run_style_refinement.py --init-ckpt /absolute/path/to/controller/best.pt
```

此命令同样只打印；运行仍需 `--execute`。VQ 内容、模型形状、prediction mode 和 slot 身份/顺序必须匹配。不会重置 selector 为 prior，也不会继承旧 optimizer/scheduler/RNG。将旧模型切到 raw prototype 会改变 P 的输入，需要在新目录微调和验证；仅加载旧模型不会自动获得本版效果。

## checkpoint 兼容与评估

- 旧 checkpoint 缺少 `style_proto_normalization` 时按 `layernorm` 构建，保持原推理行为。v3 checkpoint 按保存字段恢复 `none`；没有额外 state keys。
- v3 保存 `training_objective_version=3`、初始化记录和原有 RNG/指纹。新旧训练状态不能在默认设置下混用 resume；`--init-ckpt` 可继承兼容权重。v2 修复 checkpoint 需要 v2 的显式设置才能续训，历史更早版本仍只作为兼容权重来源。
- 直接 trainer 续训时，指定原 run 的数据、prior/cache、norm、latent stats、microbatch 和全部训练参数，再加 `--resume PATH`；严格校验配置和内容。有界脚本自动续跑其目录中兼容 latest，完成50 epoch且存在 validation selection 的阶段才跳过。
- `analysis/run_repair_pipeline.py` 显式保留 v2 的三项旧 style 设置；可与 v3 使用相同 case/noise 比较。不要从 test 挑 checkpoint。

锁定 validation-selected checkpoint 后，使用者可运行原统一 test 协议：

```bash
python analysis/evaluate_repair_protocol.py \
  --runs checkpoints/flowmatch_style_paper_v3/A/best.pt \
         checkpoints/flowmatch_style_paper_v3/B/best.pt \
         checkpoints/flowmatch_style_paper_v3/C/best.pt \
  --out checkpoints/flowmatch_style_paper_v3/evaluation --device cuda
```

优先检查 selector top-1/entropy 是否仍近单码、同源 seen label 与 seen recipe 的差距、matched/cross style accuracy 与 Root ADE 是否同时改善；使用同一 case manifest 和 Gaussian noise，指标口径沿用 v2。即使 token 更可分，也不能直接宣称 cross-style 或 OOD 生成改善。

## 已验证与未验证

新增轻量回归覆盖实际 90-style/8-slot/2048-code 形状的 prior 初始化、VQ 状态不变、entropy 局部目标、prototype 幅度保留、旧模型默认 LayerNorm、recipe 正则梯度/展开复用、train-only/exemplar source 隔离、cache/在线一致以及真实 tiny-DB CLI 的初始化和 epoch resume 数值一致。所有 fixture 都是 CPU 小模型/临时目录。

2026-10-05 全套轻量测试结果：**151 passed、5 subtests passed**（10.28 秒）；新增 style 回归 10 项。命令为 `PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -m pytest -q -p no:cacheprovider`。trainer `--help`、三阶段命令 dry-run、8 个相关 Python 文件的 AST、wrapper `bash -n` 和已跟踪改动的 `git diff --check` 均通过。55 条 warning 来自既有 Torch/CPU pin-memory/多进程和依赖提示，无失败。

代码修订和轻量测试已经完成。尚未运行真实数据 cache、GPU smoke、正式训练或 test；不能把这些检查当作 style accuracy、motion quality 或论文联合指标恢复的证据。
