#!/usr/bin/env bash
set -euo pipefail

# NOTE (2026-10): this is the project's own 24-joint / 72-dim extractor recipe. The current
# FID protocol is CAMDM's extractor trained on all 100 styles -- use
# `run_train_fid_feature_extractor_camdm.sh` instead unless you specifically need this variant
# (see FID_EXTRACTOR_AND_PAPER_PARITY.md).
#
# Key overrides:
#   DB=... OUT=... DEVICE=cuda \
#   ./NewCode/run_train_fid_feature_extractor_head10.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/Utils/run_utils.sh"

PYTHON_BIN="${PYTHON_BIN:-python}"
TRAIN_PY="${SCRIPT_DIR}/train_fid_feature_extractor_head10.py"

DB="${DB:-${SCRIPT_DIR}/database_100sty_375_memmap}"
OUT="${OUT:-${SCRIPT_DIR}/checkpoints/fid_feature_extractor_head10}"
DEVICE="${DEVICE:-cuda}"
LOAD_INTO_MEMORY="${LOAD_INTO_MEMORY:-0}"

ru_require_file "${TRAIN_PY}" "train script"
ru_require_python_modules "${PYTHON_BIN}" torch tqdm

cmd=(
  "${PYTHON_BIN}" "${TRAIN_PY}"
  --db "${DB}"
  --out-dir "${OUT}"
  --device "${DEVICE}"
)

ru_append_if_enabled cmd "${LOAD_INTO_MEMORY}" --load-into-memory

cmd+=("$@")
"${cmd[@]}"
