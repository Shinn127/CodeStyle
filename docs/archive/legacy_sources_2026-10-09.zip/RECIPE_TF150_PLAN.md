# 独立 clip / recipe controller：代码检查与150 epoch计划

后续修订实现和从零训练入口见 [CLIP_RECIPE_REVISION_PLAN.md](/home/shinn/桌面/multimedia/revision/NewCode/CLIP_RECIPE_REVISION_PLAN.md)。本文件及原脚本保留为已经完成的 histogram-recipe TF150 实验记录。

2026-10-06。本轮更新为150 epoch预算，与label训练的epoch数对齐，不启动正式训练或rollout。历史50 epoch计划与脚本保留。

## 本轮检查与修正

原实现支持pure recipe推理，但训练的`--recipe-prob`是label augmentation。它会保留label selector计算与正则；没有exemplar时回退label；validation默认只看label。因此仅设置`recipe-prob=1`不能建立独立recipe controller。

新增`--conditioning-mode recipe`：

- train和validation始终使用纯recipe、`style_label=None`、strength=1，完全不访问style embedding / learned logits。冻结这些未使用的参数，训练现有prototype projection和flow。
- 禁用selector prior/entropy优化项，不添加label feature对齐或classifier loss。保留recipe entropy、top-1概率和实际exemplar数量的诊断统计。
- 逐样本排除原始source clip及实际matched_root donor clip；它们的mirror也不能成为独立exemplar。旧label augmentation继续保留原语义。
- 支持`--recipe-exemplar-choices 1 3 5`，按recipe均匀抽取数量。纯模式不允许缺候选时回退label或静默缩小数量；不足时直接报错。
- `--recipe-bank-size 64`为每个style/被排除clip/数量提供64个确定性配方变体。首次使用随机独立clips/crops构建，后续只缓存TopK ids与FP32 weights；私有构建RNG不影响训练RNG，冷缓存续训与热缓存连续训练的条件和权重一致。bank=0保留每次重新抽crop的路径。
- 训练前检查每style至少有`max(choices)+1`个独立train clips。当前数据83个style有6个、5个有7个、2个有8个，满足1/3/5配置。
- 新checkpoint保存conditioning mode和目标版本6；严格resume检查recipe配置和随机状态。旧checkpoint缺少mode时按label解释；可以通过init继承兼容权重。
- recipe-only checkpoint拒绝误用label条件。seen评估自动使用recipe进行matched和cross，`--source-split val`支持验证集选型，manifest拒绝val/test混用。
- 固定noise的pure-recipe TF评估按时间点批处理，复用style feature，不把2048维概率沿时间展开；显式legacy replay保留原路径。

这说明训练入口可用，不说明当前label-only checkpoint的exemplar / unseen能力已经修复。训练后才能验证效果。

最终轻量回归：203项通过、2项CUDA测试跳过、5项subtests通过；包含真实CLI的pure train/validation、matched_root source/donor隔离、冷/热bank一致性、epoch边界精确续训、旧label入口兼容、matched/cross recipe评估、TF批处理与逐帧参考一致性。Python编译、shell语法与diff检查通过。本轮未验证正式GPU吞吐或生成风格达标。

## 固定训练配置

| 项目 | 设置 |
|---|---|
| 模型 | 新clip/recipe controller，现有label模型单独保留 |
| 初始化 | 默认从头训练recipe projection和flow；同一VQ冻结。可显式选择label best权重初始化，但必须另标记为warm-start |
| VQ / normalization | 当前VQ150ep best及既有统计，全部冻结 |
| 数据 | 90-style IND现有clip-level split；OOD不进入generator训练 |
| 缓存 / prior | 复用指纹匹配的FP32 repair_v2；prior仅确定同一组8 slots及来源 |
| latent stats | 复用已验证的train-only统计，不重新估计、不修改原文件 |
| 条件 | 每个有效样本均使用独立train exemplar recipe；随机1/3/5 clips，每clip随机240帧crop |
| Recipe | 8 slots、K=2048、TopK4、同slot顺序和码本；同一recipe可服务多个相同排除约束的样本 |
| Recipe bank | 64 variants / style / 排除集合 / exemplar数，seed42；有限随机变体，稀疏内存缓存，不改旧VQ cache |
| Teacher-forced | seq_len=2、stride=1、unroll=1，GT上一帧motion / latent，无feedback reconstruction |
| Cross监督 | matched_root请求概率0.3；实际合格比例另记，source root保留 |
| 目标 / loss | target prediction，normalized latent MSE，flow=1；recon/root/prior/entropy/classifier loss=0 |
| 网络 | 现有6-token Transformer，256 hidden / 2 layers / 4 heads / FFN1024，dropout=0 |
| Epoch / seed | 本轮最多150 epoch，seed42；不自动追加训练 |
| Batch | 有效512，默认128×4；donor选择在完整512上进行，clip grad=1，每次update一次 |
| Optimizer | AdamW，lr=5e-4，min_lr=1e-5，weight_decay=1e-4，cosine horizon=150 |
| History noise | epoch1–50 clean；epoch51–150以0.3概率共享gate/strength加噪，latent幅度0.3、pose/velocity幅度0.2、root幅度0.05，rotation不加噪 |
| 精度 | FP32、highest、TF32=False；不启用AMP |
| 验证 / 保存 | 每epoch pure-recipe matched validation loss，每5 epoch保存；rollout validation=0 |
| 主推理 | Euler8，Gaussian std=1；continuous latent→clip→quantize→decode |

默认不加载label controller权重，以150个recipe epoch与label的150 epoch作独立训练预算比较。共享VQ、normalization、train-only latent stats不等于继承label模型；两个controller的style features不要求数值相等，没有feature对齐损失。

可选warm-start仍支持`INIT_CKPT`，但继承label best再训练150个recipe epoch应标为warm-start微调，不能称为两个模型均从头训练150 epoch。epoch数及有效batch对齐不保证GPU小时相同。

## 运行方式

先检查命令，不运行：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DRY_RUN=1 \
  bash run_train_flowmatch_recipe_tf150.sh
```

如需用户自行做GPU入口smoke，使用独立输出，仅2个updates与1个validation batch；它不计入正式epoch：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python \
OUT=checkpoints/flowmatch_recipe_smoke \
  bash run_train_flowmatch_recipe_tf150.sh \
  --epochs 1 --max-train-batches 2 --max-val-batches 1 --num-workers 0
```

正式150 epoch：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DEVICE=cuda \
  bash run_train_flowmatch_recipe_tf150.sh
```

可选warm-start（额外150 epoch微调，独立输出，lr建议1e-4）：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DEVICE=cuda \
INIT_CKPT=checkpoints/flowmatch_tf150_staged_noise/best.pt LR=1e-4 \
OUT=checkpoints/flowmatch_recipe_warmstart150 \
  bash run_train_flowmatch_recipe_tf150.sh
```

只在同配置、同输出目录下resume；optimizer/scheduler/RNG均恢复。下面为默认从头训练的run，warm-start续训需保留其OUT和LR：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DEVICE=cuda \
RESUME=checkpoints/flowmatch_recipe_tf150/latest.pt \
  bash run_train_flowmatch_recipe_tf150.sh
```

中途在5 epoch检查表现，应保持原`epochs=150`配置后停止并按原配置resume。不要先把run设成5 epoch，再改150续训；strict resume会拒绝更改训练目标。额外smoke使用独立目录，正式run默认从头训练，按原150 epoch配置续训。

## 验证与checkpoint选择

训练内`best.pt` / `best_loss.pt`根据pure-recipe matched validation loss选择，它们是loss候选，不是style accuracy最优的证明。比较`epoch_0005/0010/.../0150.pt`时使用固定validation cases，先完成seen配方能力验证。

例如对5 epoch checkpoint进行240帧teacher-forced评估，不反馈生成motion：

```bash
/home/shinn/miniforge3/envs/mcc/bin/python evaluate_minor_revision_generalization.py \
  --flow-ckpt checkpoints/flowmatch_recipe_tf150/epoch_0005.pt \
  --classifier-ckpt checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth \
  --source-split val --unmirrored-sources --recipe-only \
  --recipe-profile canonical --recipe-window 240 --recipe-exemplars-per-style 5 \
  --flow-eval-mode reconstruct --horizons 240 --flow-ode-steps 8 \
  --flow-requantize-z --flow-latent-clip --flow-microbatch-size 512 \
  --num-sources 270 --targets-per-source 5 --seed 42 --recipe-seed 42 \
  --case-manifest eval_results/recipe_tf150_val_cases.json \
  --out-dir eval_results/recipe_tf150_val_e0005_n5 --device cuda
```

建议在epoch5/25/50/75/100/125/150检查固定validation matched/cross，并比较保存的候选；避免把每个5-epoch快照都做完整大评估。后续checkpoint共用该manifest及recipe seed，输出各放独立目录。它抽取最多270个未镜像validation windows，不保证每style恰好3个；报告实际style覆盖率。classification只看240个生成frames，初始化GT context不计入accuracy。

主评估先固定5 exemplars，再对候选checkpoint用`--recipe-exemplars-per-style 1`及`3`检查单clip/少clip稳定性；复用同一source/target/noise manifest，分别记录recipe来源与统计。降低batch/microbatch不改变Gaussian输入。

报告matched/cross accuracy、Root ADE、按source_entry_id聚类的CI，以及不同exemplar数量的差距。目标仍为matched85+、cross80+；这些是结果目标，不是代码保证。4秒Root ADE单独报告，不套用旧1秒阈值。挑选时同时看matched/cross与轨迹保持，不拼接多个checkpoint的最好值。

150 epoch后根据验证集锁定一个checkpoint，再以`--source-split test`和全新的test manifest复测。OOD最后通过`evaluate_unseen_style.py --flow-ckpt <locked checkpoint>`评估，仍用固定独立5×240帧exemplars及独立reference clips，报告unseen与seen cross的差距。禁止OOD数据、test accuracy或报告classifier loss参与generator训练与选型。

## 需要观察的现象与成本

- train / val的recipe_fraction必须为1、shortfall_fraction为0；projection/flow有梯度，VQ与未使用的label selector不变。bank_hit_fraction记录缓存命中率；冷缓存恢复后的耗时/命中率可以不同，但条件、loss随机输入和权重应一致。
- 实际matched_root比例、conditioning_entropy、实际exemplars_mean随日志保留。没有可优化selector时，selector_entropy=0，不能据此宣称recipe被“锐化”。
- 若seen recipe仍明显低于label，先分解单clip/多clip、matched/cross、GT/quantized-AE差距与recipe-action依赖；150 epoch内仍不理想时先作失败分析，不自动追加训练或改classifier。
- 如果seen recipe有效而unseen很差，检查所选8 slots及TopK直方图是否保留OOD信息；取消label对齐本身不能补回时序或跨slot关系。
- GPU小时和显存由用户的实际smoke/正式epoch测量。日志的train_time_sec可估算150 epoch成本；本轮不沿用label模型耗时作承诺。recipe采样有CPU/传输开销，但跳过了大尺寸learned selector forward以及训练中的decoder/Euler。

本轮真实模型CPU检查：从epoch135 checkpoint加载，使用真实repair_v2缓存、真实train clips，FP32执行2样本FM backward与1次临时optimizer update；projection/flow梯度非零，VQ和未使用selector权重不变，没有调用embedding、在线GT encoder、decoder或Euler，不保存模型。诊断见`analysis/recipe_training_audit_2026-10-06.json`，复查入口为`analysis/audit_recipe_training.py`。

512样本CPU recipe构建的5次测量：bank=0中位约67–69ms；bank64首次约85ms，重复同一批变体、100%缓存命中时中位约3.48ms。它是隔离CPU构建测量，不是GPU整epoch或训练提速倍率；新变体的首次构建仍有成本。正式run需观察命中率和实测epoch时间。
