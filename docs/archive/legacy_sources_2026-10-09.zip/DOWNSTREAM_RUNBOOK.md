# 下游链路检查与运行手册（VQ → 控制器 → 评测）

检查时间：2026-10-01（训练 150-epoch VQ 期间）。结论：链路顺序、命名派生、安全护栏都就位；
修掉了两个「静默用错基线」的坑，并记录了几处需要显式覆盖的默认值。

## 1. 链路与就位情况

```
VQ ckpt ──► precompute_vq_targets ──► precompute_style_code_prior ──► 训练 flowmatch 控制器
                     │                          │                            │
                     └── cache/vq_targets_<VQ目录名>   cache/style_code_prior_<VQ目录名>.npz
                                                                              ▼
                                          build_zeroshot_style_recipe（OOD 风格配方）
                                                                              ▼
                       evaluate_motion_375to291 / evaluate_rollout_mpjpe_curve /
                       evaluate_minor_revision_generalization / simulate_realtime_*
```

已核实就位：

- **缓存名按 VQ 目录自动派生**：`run_train_flowmatch_vqvae_controller.sh` 用
  `default_vq_target_cache/default_style_code_prior` 从 `VQ_CKPT` 的父目录名生成
  `cache/vq_targets_<ckpt_dir>` 与 `cache/style_code_prior_<ckpt_dir>.npz`，不同 VQ run
  不会互相覆盖 ✓。
- **缺缓存自动预计算**：控制器 wrapper 检测缓存缺失（`looks_like_vq_target_cache` 要求
  `meta.json` + `indices.u16/i32`）就自动跑预计算，存在则打印 `(reuse existing)` ✓。
- **缓存有溯源**：`Utils/vq_target_cache.py::VQTargetCacheMeta` 记录
  `db / vqvae_ckpt / norm_stats / num_codebooks / code_dim / num_embeddings / indices_dtype` ✓；
  且 `precompute_vq_targets.py` 默认拒绝覆盖（`FileExistsError`，需 `--overwrite`）✓。
- **所有下游脚本 CLI 正常**：6 个入口脚本 `--help` 全部通过，无残留参数（历史遗留的
  `allow_unsplit_segments`、`h5_cache_*`、`split_mode` 参数错配已不存在）。
- **OOD 库接线正确**：`run_build_zeroshot_style_recipe.sh` 默认 `DB=database_100sty_375_memmap_zeroshot`
  （role=zero_shot、无 split）✓。

## 2. 本次修掉的两个坑（静默用错基线）

评测脚本里 `lmm` / `mvae` / `camdm` / `mann` / `flowmatch_*` 的 **DEFAULT_CKPTS 仍指向
`*_head10`**（那是论文数值的复现口径，保留）。在 90-style 新库上评测时，如果直接跑默认
模型列表，head10 的基线会被当成新库基线用，指标不可比。

- 已在 `evaluate_motion_375to291.py` 与 `evaluate_rollout_mpjpe_curve.py` 增加
  `warn_if_checkpoint_db_differs()`：评测前读取每个 checkpoint 的 `args.db`，与 `--db`
  不一致就打 `[Warn] ... out of distribution and not comparable`（已验证：head10 的
  lmm/mvae/camdm/flowmatch_velocity 会告警，新库的 `lmm_375to291`/`mvae_375to291` 不告警）。
- 新库基线的**正确路径**：`--lmm-ckpt checkpoints/lmm_375to291/best.pt`
  `--mvae-ckpt checkpoints/mvae_375to291/best.pt`（两者的 config 均为 `database_100sty_375_memmap`）。

## 3. 检查点溯源表（`config.json` 的 `db` 字段）

| 训练库 | checkpoints |
|---|---|
| **新 90-style 库**（可直接用于新 split 表格）| `lmm_375to291`、`mvae_375to291`、`flowmatch_vqvae_controller_full`(50ep)、`flowmatch_vqvae_controller_full_new`(100ep)、`vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048{,_phase1_100k,_150ep}` |
| head10（已退役库，OOD）| `*_head10` 全部、`camdm_controller`、`mann_controller`、`diffusion_vqvae_controller`、`diffusion_lmm_controller`、`vqvae_motion_only_375to291_32_4_2048` |

含义：**表征层三行表（MotionVQ / LMM-AE / MotionVAE）可以在新 split 上完整重建**（三者的
新库权重都在）；而**控制器/生成类对比（CAMDM、MANN、diffusion、flowmatch）目前只有 head10
权重**，要出新库数字必须重训（新库的控制器链路已经就位，见下）。

## 4. 待修/待清理（未自动改，需你确认）

1. **`cache/zeroshot_style_recipes/*.json` 已过期**：metadata 里记录的是
   `vqvae_ckpt: .../vqvae_traj_motion_375to291_32_4_2048_full/best.pt`（重写前的旧 VQ）与旧项目路径
   （`/home/shinn/桌面/revision/...`），且 `slots[].codes` 是**旧码本的索引**——换用新 VQ 后这些
   配方无意义。文件名不含 VQ 版本，容易被误用；建议用新 VQ + 新控制器重建
   （`run_build_zeroshot_style_recipe.sh` 会把 `vqvae_ckpt/flow_ckpt` 写进 metadata）。
2. **控制器 wrapper 的默认输出目录 `checkpoints/flowmatch_vqvae_controller` 里放的是 head10 控制器**
   ——按默认值训练会覆盖它。请显式给版本化 `OUT`（例如 `flowmatch_vqvae_controller_150ep`）。
3. **FID 特征提取器**：现行口径是 `checkpoints/fid_feature_extractor_full100_v4/best.pt`
   （训练库 `database_100sty_375_memmap_fid_full100` = 90 IND + 10 OOD 合并，100 个风格；
   由 `merge_memmap_dbs.py` + `run_train_fid_feature_extractor_full100.sh` 产出）。
   **不要再用 `fid_feature_extractor_head10`**：它只见过 10 个风格，在 90-style 库上属分布外
   特征空间，算出来的 FID 与论文口径不可比（详见 `FID_EXTRACTOR_AND_PAPER_PARITY.md` §1.3/§3）。
4. **独立预计算 wrapper 的默认缓存名不带 VQ 版本**（`cache/vq_targets_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048`），
   与控制器 wrapper 从 `VQ_CKPT` 派生的名字不一致；单独跑会多算一份，不影响正确性。建议统一用
   控制器 wrapper 或显式传 `OUT`/`VQ_TARGET_CACHE`。

## 5. 150-epoch VQ 跑完后的推荐命令序列

```bash
PY=/home/shinn/miniforge3/envs/mcc/bin/python
VQ=checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt   # 或 epoch_0150.pt
NORM=checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/norm_stats.npz

# ① 表征层评测（论文口径，含 FID）；--norm-stats 用该 run 自己的
$PY evaluate_motion_375to291.py --models basic_vqvae --basic-vqvae-ckpt $VQ \
  --db database_100sty_375_memmap --norm-stats $NORM \
  --fid-extractor-ckpt checkpoints/fid_feature_extractor_full100_v4/best.pt \
  --seq-len 60 --stride 30 --test-fraction 1.0 --out-dir eval_results/vqvae_150ep

# ② 三行对照表（新库基线，guard 不会告警）
$PY evaluate_motion_375to291.py --models basic_vqvae lmm mvae \
  --basic-vqvae-ckpt $VQ --lmm-ckpt checkpoints/lmm_375to291/best.pt \
  --mvae-ckpt checkpoints/mvae_375to291/best.pt \
  --db database_100sty_375_memmap --norm-stats $NORM \
  --fid-extractor-ckpt checkpoints/fid_feature_extractor_full100_v4/best.pt \
  --seq-len 60 --stride 30 --test-fraction 1.0 --out-dir eval_results/table_150ep

# ③ 滤波/长窗口分析（可选）
$PY analysis/full_compare.py --ckpt $VQ --device cuda --out /tmp/full_compare_150ep.json
$PY analysis/full_compare.py --ckpt $VQ --window 120 --stride 60 --device cuda --out /tmp/fc_150ep_120.json

# ④ 控制器链路（缓存/风格先验按 VQ 目录自动派生并自动预计算）
PYTHON_BIN=$PY VQ_CKPT=$PWD/$VQ OUT=$PWD/checkpoints/flowmatch_vqvae_controller_150ep \
  bash run_train_flowmatch_vqvae_controller.sh

# ⑤ OOD 零样本风格配方（必须用新 VQ + 新控制器重建，旧配方已过期）
PYTHON_BIN=$PY DB=database_100sty_375_memmap_zeroshot \
  VQ_CKPT=$PWD/$VQ FLOW_CKPT=$PWD/checkpoints/flowmatch_vqvae_controller_150ep/best.pt \
  STYLE_CODE_PRIOR=$PWD/cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz \
  bash run_build_zeroshot_style_recipe.sh
```
