# 150 epoch 单步TF与阶段式历史噪声

2026-10-06：实现用户建议的前50epoch干净条件、随后100epoch以30%概率加噪。仅修改代码并完成轻量验证，没有启动正式训练、生成评估或rollout。本方案是新的研究配置，未证明能达到matched85/cross80或OOD目标。

## 固定配置

| 项目 | 设置 |
|---|---|
| 初始化/预算 | 默认从头训练，seed42，一条run最多150epoch；不自动追加实验 |
| Epoch 1–50 | 历史motion/latent不加噪声 |
| Epoch 51–150 | 每样本30%概率同时扰动motion和latent；其余70%保持干净 |
| 加噪幅度 | 选中样本两路共享a~Uniform(0,1)；normalized motion pose/velocity最大std=.2，root=.05；latent最大std=.3并乘train transport_std |
| 不扰动项 | trajectory84、motion的rotation144维、监督目标、style标签；历史dropout=0 |
| 训练 | teacher-forced，seq_len2、stride1、unroll1；首帧取GT历史，每个相邻pair独立训练 |
| Cross监督 | matched_root请求概率.3，两个阶段均开启；与加噪事件独立 |
| Target | normalized latent target prediction；flow weight1 |
| Loss | recon0、root0、style-consistency0、dense prior .02、entropy .003 |
| Style | 8 slots、TopK4、temperature1、prior初始化、raw prototype；recipe训练增强0 |
| 模型 | 既有6-token transformer，hidden256、2layers、4heads、FFN1024，dropout0 |
| VQ | 固定VQ150ep best、固定normalization，全冻结/eval；repair_v2 cache/prior、train-only latent stats |
| Batch | 512；可设MICROBATCH_SIZE=256/128，完整512先选donor，分批反向后每update裁剪一次 |
| 优化器 | fused AdamW，lr5e-4，weight decay1e-4，grad clip1 |
| Scheduler | 单一cosine horizon150，min lr1e-5；第51epoch不重置optimizer或scheduler |
| 精度 | FP32/highest、TF32=False，无AMP |
| 保存/验证 | 每epoch干净TF loss validation；每5epoch快照；关闭rollout validation |
| 生成设置 | Euler8、noise std1、clip→quantize→decode；训练主路径不使用此采样 |

“0.3概率”和“0.3 latent幅度”是两个不同参数。实现的增强为：

`b_i ~ Bernoulli(p_epoch), a_i ~ Uniform(0,1)`

`observed_motion_i = GT_motion_i + b_i * a_i * group_std * epsilon_motion_i`

`observed_latent_i = normalized_GT_latent_i + b_i * a_i * .3 * transport_std * epsilon_latent_i`

两路共享b_i和a_i，Gaussian方向分别采样。共享强度不保证motion与latent在VQ流形上严格一致；这里是低成本condition augmentation，不宣称是真实rollout误差分布。输入噪声不做VQ重编码或decoder前向。history root中的vx/yaw/vz依照各自既有normalization扰动，.05是normalized幅度，不是直接的m/s或deg/s阈值。motion布局为root[0:3]、position[3:75]、rotation[75:219]、velocity[219:291]。

## 启动与续训

独立入口不会自动预计算或覆盖缓存，缺少/不匹配的产物由训练入口报错。默认输出为 `checkpoints/flowmatch_tf150_staged_noise`；已有目录有训练产物时必须明确resume或换目录。

只查看命令，不执行：

```bash
DRY_RUN=1 bash run_train_flowmatch_tf150_staged_noise.sh
```

用户自行启动：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DEVICE=cuda \
  bash run_train_flowmatch_tf150_staged_noise.sh
```

原样恢复此新run：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DEVICE=cuda \
RESUME=checkpoints/flowmatch_tf150_staged_noise/latest.pt \
  bash run_train_flowmatch_tf150_staged_noise.sh
```

阶段由checkpoint恢复的epoch确定，不因重启重新计数。新配置目标版本5；noise模式、起始epoch、概率和root幅度都参与严格resume校验。旧run保存的独立噪声语义保持可读/可续训，不允许直接resume成此新方案。

如明确要继承当前5epoch模型，可指定 `INIT_CKPT=checkpoints/flowmatch_tf50_short5/best.pt` 和新OUT，内部使用 `--init-ckpt`。这会重置optimizer/scheduler/RNG，阶段计数从新run第1epoch开始；额外150epoch加原有5epoch共155epoch，不能称为累计150epoch。如果要限制总量150，需要同时指定 `--epochs 145 --lr-schedule-epochs 145`；新run仍先50epoch不加噪声。默认脚本不继承旧权重。

关闭cross监督做matched-only配置，可以设 `DECOUPLE_PROB=0`，但不能将其当作已监督cross。如显存不足，可设 `MICROBATCH_SIZE=256` 或128。通用旧wrapper仍使用原默认配置；运行新方案请使用本入口，避免把旧5epoch目录变为新run。

## 日志、评估与限制

每epoch history.jsonl记录 `history_augmentation`（mode、start_epoch、当前概率、实际增强比例），train指标新增 `history_noise_fraction`。前50epoch及validation均应为0；后100epoch的实际比例应在.3附近，短batch可能有随机偏差。`decoupled_fraction`另行记录实际cross覆盖，不能用请求.3代替。

matched_root保持source root/trajectory，使用同动作suffix、root兼容、最近foot位置的donor，并修正joint velocity后在线重新编码合成目标。这个配对仍为近似；当前seq_len2的root/foot匹配主要针对target frame，没有严格双帧contact/步态相位约束。新噪声功能不解决这项配对质量限制，不把增强成功等同于cross提升。

噪声路径保持单次flow前向，recon/root/style-consistency都关闭时无Euler和decoder；matched_root对实际cross子集额外使用冻结VQ encoder前向。不能直接沿用旧matched-only的GPU小时预测新配置，也不宣称150epoch比50epoch总成本低。没有执行真实GPU计时。

现有best.pt/best_loss.pt仍按干净validation loss选择；独立240帧TF style联合选择接口尚未实现。需要用户训练并冻结60fps/240帧classifier后，在固定validation cases上独立报告matched/cross、source retention和Root ADE，再锁定checkpoint做test。不可把test用于训练选模，也不能把旧1秒ADE gate套到4秒。noise增强不保证长期闭环稳定性，本方案不执行rollout评估。

最小回归测试覆盖：epoch50/51/150边界、30%共享门控、rotation与目标保持、无额外Euler/decoder、实际cross入口、干净validation、VQ状态不变、阶段切换处中断续训与连续训练一致，以及错误阶段配置拒绝resume。

验证结果：全部现有轻量测试183项通过、2项CUDA测试跳过、5项subtests通过；新入口shell语法与完整CLI参数解析通过。GPU耗时、长期反馈稳定性与style指标尚未实测。
