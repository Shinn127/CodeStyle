# 历史文档归档

这些文件保留历史配置、结果与修复过程，不能用于推断当前默认参数。

| 文档 | 保留用途 |
| --- | --- |
| [CHECKPOINT_MAP.md](CHECKPOINT_MAP.md) | head10 时期的 checkpoint / cache 对应关系 |
| [STYLE_PRIOR_FIX_PLAN.md](STYLE_PRIOR_FIX_PLAN.md) | 早期 style-prior 修复过程 |
| [STYLE_PRIOR_TRAINING_PLAN.md](STYLE_PRIOR_TRAINING_PLAN.md) | 原 50 epoch 控制器实验规划 |
| [RUN_100K_RESULTS.md](RUN_100K_RESULTS.md) | VQ 100k steps 历史结果及 FID 口径更正 |
| [RUN_150EP_RESULTS.md](RUN_150EP_RESULTS.md) | VQ 150 epoch 历史结果及 FID 口径更正 |

当前命令见 [NewCode README](../../README.md)。head10 产物已按用户要求删除，详见 [清理记录](../CLEANUP_HEAD10_2026-10-05.md)；其余数据、权重与模型代码保留。旧 LMM 转发入口仍保留兼容；当前训练应使用 `train_lmm_375to291.py` / `run_train_lmm_375to291.sh`。`train_fid_feature_extractor_head10.py` 虽有旧名称，仍被 full100 wrapper 使用。
