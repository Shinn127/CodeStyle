# Style Prior / Selector：论文与实现的双向审查 + 修复与优化方案（v3，已执行）

> 历史快照：保留原实验结论和配置，不能作为当前训练默认值。当前入口见 [README](../../README.md) 和 [teacher-forced 规划](../../TEACHER_FORCED_50E_PLAN.md)。


> **v3 更新（2026-10-02）**：方案已按推荐执行完毕，见 §8「执行结果与实测验证」。
> 两处**更正**：① v2 §1/§2 报告的「偏差 B（熵项符号反）」**是我推导错误**——`-Σπ logπ` 恒为正，
> 即论文式(7) 的 +H，代码原本就是对的（数值核验：尖峰分布 0.9404 < 均匀 1.3863，且训练日志里
> `style_entropy` 为正且随训练下降）；② 执行过程中冒烟测试发现一个**真正的链路级阻塞 bug**
> （控制器内部调用已废弃的 `quantizer.embedding.weight`），已修复并加回归测试，见 §8.4。

审查对象：论文 `MM-2025-11-0162.R2_Ma.tex` 式(1)-(8) 与附录实现细节；
代码 `precompute_style_code_prior.py`、`Utils/style_code_prior.py`、`arch/flowmatch_vqvae_controller.py::StyleCodeSelector`、`train_flowmatch_vqvae_controller.py`。
所有判据都来自本仓库实测（先验用当前 VQ 在 OOD 库重建；控制器的训练日志取自 `flowmatch_vqvae_controller_full_new` 的 `history.jsonl`）。

## 0. 结论摘要

- **论文正确的部分**：式(1)(2)(4)(5)(7)(8)（先验估计、JS 显著度与 top-$M_s$ 选择、加权聚合、熵项方向、推理混合）。
- **论文有问题的部分**：式(6) 作为 KL 记法**病态**——π 由式(3) 定义为 TopK 后，支撑外恒为 0，而 π̄ 因 α>0 处处为正，故 `KL(π̄‖π) ≡ +∞`；论文对式(3) 是否重归一化、以及 λ/K_s/τ 的具体取值均未交代。
- **实现正确的部分**：式(1)(2)(3)(4)(5)(8) 逐项一致（含 TopK 后重归一化，这一点比论文写得更自洽）。
- **实现有问题的部分**：①式(6) 用 `clamp(1e-8)` 兜住无穷，代价是该项被 `18.42×支撑外质量` 支配（实测 18.2，占总 loss **~90%**，几乎不下降）；②式(7) 的**熵项符号反了**（实现为 −H 并以 +λ 相加 ⇒ 最大化熵，与论文"minimizing → peaky"相反）。
- **根因是数据性的**：该先验非常平坦——每个 slot 有 **86% 质量在 top-4 之外**，`H(π̄)=5.94`（log 2048=7.63），且 `JS(π̄‖均匀)=0.30 < JS(π̄‖top4(π̄))=0.535`。**即"输出均匀分布"比"输出先验的最佳 top-4 近似"更接近先验**，所以任何"让稀疏 π 去拟合先验"的写法都有不可达下界、且方向被覆盖度主导。
- **推荐修法**：`L_prior` 改为对**TopK 之前的稠密分布**计算（良定、可达 KL=0、标准蒸馏梯度），TopK 仅保留式(3)(4)(5)(8) 的选择/聚合用途；修熵项符号；论文侧相应修订式(3)(6) 的表述与超参。

## 1. 逐项判定表

| 论文 | 代码 | 判定 |
|---|---|---|
| 式(1) π̄=(n+α)/Σ(n+α)，训练集统计 | `precompute_style_code_prior.py:171-174`；独立重算逐位一致；最小项 = 1/(F+2048) 精确吻合；行和=1 | **两边都对** |
| 式(2) D_j=mean_s JS(π̄_{s,j}‖π̄_j)，top M_s=8 为 Ω | `:176-193`；手算 JS == 记录值；Ω 为 8 个 head（32 中）| **两边都对** |
| 式(3) π=TopK(Softmax(a/τ))；**未说是否重归一化** | `_sparsify_probs` 做 TopK + 重归一化 | 论文不完整；**代码更合理**（不重归一化会让式(4) 的 u 幅度随 logits 形状漂移）|
| 式(4)(5) u=Σπz，e_s=P([u]) | `einsum` + `proto_to_style` | **两边都对** |
| 式(6) L_prior=mean_j KL(π̄‖π) | `hist_loss=-Σπ̄·log(clamp(π,1e-8))` | **论文病态（+∞）；代码是"能跑但不可用"的兜底** |
| 式(7) L_ent=mean_j H(π)，最小化→peaky | 返回 `-(π log π)` = **+H**，总损失里 `+λ·H` | **两边都对**（v2 曾误报符号问题，已更正）|
| 式(8) π̃=(1−β)π+βρ | `_normalize_manual_probs` + `manual_strength`（含空掩码补均匀）| **两边都对** |
| 总损失结构 L_flow+λ_rec L_rec+λ_prior L_prior+λ_ent L_ent | `arch/...:779-782`；λ_rec=0.1 ✓、lr=5e-4 ✓ | 结构对；**λ_prior/λ_ent 论文未给**（实现 0.2 / 1e-3）|
| 附录：E_s = embedding/MLP（label）| `style_embedding`+MLP | 对 |
| 附录：E_s = 2-layer transformer（clip $m_s$）| 未实现（OOD/clip 由 recipe 走式(8)）| **论文描述了未实现的路径** |
| 附录：AdamWR + cosine-annealing warm restarts | AdamW + `CosineAnnealingLR`（无 warm restarts）；结果来自代码 | **不一致**（改论文措辞或改代码）|
| 附录：λ_rec=0.1、flow 50ep/batch512/lr 5e-4 | 一致（recon_weight 0.1、lr 5e-4 默认）| 对 |

## 2. 论文侧修订（R2 回复可直接用）

1. **式(3) 补重归一化**：`π = TopK_{K_s}(Softmax(a/τ))`，随后 `π ← π/Σπ`。否则式(4) 的加权聚合幅度不可控。
2. **式(6) 改为良定形式**（二选一，推荐 ①）：
   - ① `L_prior = (1/|Ω|)Σ_j KL(π̄_{s,j} ‖ p_{s,j})`，明确 `p = Softmax(a/τ)` 是 selector 输出分布，`π = TopK(p)` 只是用于式(4)(5) 的**选择算子**；
   - ② 若坚持在 π 上算，改用**有界**散度：`JS(π̄‖π)`（与式(2) 同一工具箱），并注明稀疏形式存在不可达下界。
3. **补超参数值**：$K_s=4$、$M_s=8$、$\alpha=1.0$、$\tau=1.0$、$\lambda_{prior}=0.2$、$\lambda_{ent}$（见 §5 建议 5e-3~5e-2），并注明 λ_prior/λ_ent 是未在论文中调优的实现选择。
4. **优化器措辞**：把 "AdamWR, cosine-annealing warm restarts" 改为与实际一致的 "AdamW with cosine annealing (lr 5e-4 → min_lr)"，或补上 warm restart 的实现。
5. **clip 分支**：要么说明"clip 条件通过 recipe（示例片段码频 → ρ）实现，等价于式(8) 的 β 通路"，要么单独排期实现 temporal encoder。当前的文字与代码不符，属于审稿人可复现性风险点。
6. **可选（增强可信度）**：附录加一句先验统计——"per-slot 先验熵约 5.9 nats（上界 log 2048=7.6），即先验主要起正则/选槽作用，细化码选择由 TopK + recipe 承担"，与论文自己承认的 content/style 不完全解耦相互印证。

## 3. 代码侧修复

### 3.1 A：`L_prior` 改为稠密监督（P1，主修）
- 现状：π 稀疏 → `log(clamp(0,1e-8))=-18.42`；实测 `style_hist_loss`=18.32→18.12（11 ep），`0.2×18.32=3.66` 占总 loss 4.09 的 **90%**，flow 项仅 0.13–0.40。
- 改动：`StyleCodeSelector.forward` 已返回真实的 `style_logits`（`:214`，label 路径是 **pre-softmax 稠密 logits**），在 `_compute_style_regularizers` 里用 `log_softmax(style_logits/τ)` 与 `π̄` 做 CE（= KL + const），梯度为 `p−π̄`。
- 预期：该项 18.3 → **[5.94, 7.63]**（我方先验的 H(π̄)=5.94 到 log2048=7.63），训练中可下降 ≥10%，占比从 ~90% 降到 <30%。
- 兼容：`--style-prior-loss {dense,js,sparse_eps,legacy}`，默认 `dense`；`legacy` 复现现有 checkpoint。

### 3.2 B：熵项符号（P2）
`entropy_loss` 返回 `+(π log π).sum()`（即 +H）或调用处取负，符合论文式(7)。加单测："H 下降 ⇒ 总损失下降"。
注意：H(π_sparse) 的上界是 log K_s=1.386，λ_ent=1e-3 时该项贡献 ≤0.0014（占总 loss ~0.03%）——**现在稀疏性几乎全靠结构性 TopK，熵项实质失效**；符号修正后再按 §5 调 λ_ent 才有意义。

### 3.3 C：prior 溯源（P2）
`save/load_style_code_prior` 增 `vqvae_ckpt`/`db`/`num_codebooks`（`VQTargetCacheMeta` 已有，透传）；控制器加载时与 `args.vqvae_ckpt` 比对，不一致 `[Warn]`。旧文件缺字段按"未知"处理。

### 3.4 D：日志（P3）
history/日志补加权分项与占比（`flow` / `λ_rec·rec` / `λ_prior·L_prior` / `λ_ent·L_ent`）——这次若不是翻 config 就算不出 90%，说明现有日志不足以发现此类问题。

### 3.5 E：测试（P2）
新增 `tests/test_style_code_prior.py`：KL 在 π=π̄ 时为 0；π 均匀时 CE=log K−H(π̄)；JS 有界（≤ln2）；熵项符号与单调性；prior 溯源缺失/不一致告警；`K_s≥K` 与零计数 slot 的边界。
扩充 `tests/test_precompute_pipeline.py` 断言：prior 行和=1、`selected_slots`=saliency top-$M_s$ 且升序、counts=帧数×32（当前只测"能跑通"）。

## 4. 为什么是"稠密"而不是其他兜底（实测决策矩阵）

| 方案 | 良定性 | 值域（我方先验，80 组）| 梯度 | 与论文 π 的关系 |
|---|---|---|---|---|
| 现状 `log(clamp(π,1e-8))` | 有限但病态 | [15.8, 18.4]（实测 18.2 = 总 loss 90%）| 覆盖度主导 | 字面式(6) |
| `log(π+ε)`, ε=1e-3 | 良定 | ≈[11.9, 18.4] | 仍覆盖度主导 | 字面式(6)+数值正则 |
| **稠密 `KL(π̄‖p)`（推荐）** | **良定、KL 标准** | **[5.94, 7.63]**（可达 0 KL）| `p−π̄`，有界 | p=Softmax(a/τ)，TopK 仅作选择算子 |
| `JS(π̄‖π_sparse)` | **天然有界** | [0.535, 0.693] | 有界、覆盖+形态 | 保留字面 π |

关键数据：`JS(π̄‖均匀)=0.302 < JS(π̄‖top4(π̄))=0.535`——**稀疏形式连"均匀输出"都不如**，说明"让稀疏 π 拟合先验"这一目标与该先验的平坦性是冲突的；要让稀疏 KL 的支撑外罚项 ≤1 nat，需要把下限抬到 0.31（等价于掺 31% 均匀），显然不可取。因此稠密监督是唯一同时满足"良定 + 可达最优 + 保留论文机制"的写法；若必须保留字面 π，退路是 JS（有界，但接受 0.535 的不可达下界）。

## 5. 优化项（可选，均在论文框架内，默认不动）

| 项 | 实测动机 | 形态 |
|---|---|---|
| 提高 $K_s$（如 8/16）或 $M_s$（8→12/16）| 先验 86% 质量在 top-4 外、覆盖 90% 需 30–1000 码 | 消融开关 |
| **对比式选码**：按 `π̄_{s,j}(k) − π̄_j(k)` 排序取 top-k 作为 ρ/目标（论文已算 π̄_j，属其工具箱内）| 直接针对"风格特征码被高频内容码淹没"的问题；`JS(π̄‖均匀)=0.302` 说明频次最高的码并不特异 | 新 recipe/target 选项，默认关 |
| 先验温度锐化 `π̄^{1/T}` 归一化后作目标 | 让蒸馏聚焦 top 模态 | `--style-prior-tau`，默认 1.0 |
| 熵权重 λ_ent 0.05–0.1 | 修符号后该项才真正工作；当前结构性 TopK 已给稀疏性，但"学习到的 peaky"不存在 | 调参 + 验证 `style_top1_prob` |
| 逐风格 Ω（而非全局 top-$M_s$）| 各风格显著 slot 不同 | 默认关 |

## 6. 改动清单 / 顺序 / 验收

| 文件 | 改动 | 风险 |
|---|---|---|
| `arch/flowmatch_vqvae_controller.py` | 稠密监督（用已返回的 `style_logits`）、熵符号、`--style-prior-loss` 分支 | 中（损失口径变，需重训控制器）|
| `train_flowmatch_vqvae_controller.py` | 新参数、日志分项、prior 溯源比对 | 低 |
| `Utils/style_code_prior.py` | 溯源字段（向后兼容）| 低 |
| `tests/test_style_code_prior.py`（新）、`tests/test_precompute_pipeline.py` | 见 §3.5 | 低 |
| 论文 tex | §2 的 6 条修订 | — |
| `DATA_PIPELINE.md` / `DOWNSTREAM_RUNBOOK.md` | 口径、命名（`--style-num-slots`=M_s、`--style-topk`=K_s、`--smoothing`=α）| 低 |

**顺序**：① 落 A+B+C+E（一个提交）→ ② 论文 tex 按 §2 修订 → ③ 用新 VQ 生成 prior（验证溯源字段）→ ④ 2–3 epoch 冒烟验收 → ⑤ 正式重训控制器（50 ep，λ_prior=0.2 起、λ_ent 按 §5）→ ⑥ 重建零样本 recipe（新码本必须重建）→ ⑦ 重跑风格控制/泛化与控制器评测。

**验收判据**：`style_hist_loss ∈ [5.9, 7.6]` 且训练中下降 ≥10%；`λ_prior·L_prior` 占比 <30%；`style_top1_prob` 不降（现 0.34→0.47）；下游 MPJPE/FID 不劣化；`--style-prior-loss legacy` 与现有 `history.jsonl` 数值差 ≤1e-4。现有 head10 控制器与其论文数值不动。

## 7. 附：本次审计的实测数据（可写进回复/附录）

| 量 | 值 |
|---|---|
| 先验 top-4 外质量（8 个 selected slot × 10 style）| 均值 **0.860**，中位 0.886，范围 [0.708, 0.966] |
| `H(π̄)` / `H(top4(π̄))` / `log 2048` | 5.943 / 1.352 / 7.625 nats |
| `JS(π̄‖均匀)` / `JS(π̄‖top4(π̄))` | 0.302±0.122 / **0.535±0.106** |
| 覆盖 90% 质量所需码数 | 30–1003 |
| slot 显著度 D_j（top-8 入选）| 0.135–0.291 |
| 现实现 `style_hist_loss`（`flowmatch_vqvae_controller_full_new`）| ep1 18.3195 → ep11 18.1238；`0.2×` 占总 loss 4.085→3.760 的 ~90% |
| 同 run 的 flow_loss | 0.4029 → 0.1264（真实任务损失）|
| 未训练 selector 的 H(π) | 1.3856（≈log K_s=1.3863，top-4 内近乎均匀）|

## 8. 执行结果与实测验证（2026-10-02）

### 8.1 代码改动（已落地）

| 文件 | 改动 |
|---|---|
| `Utils/style_code_prior.py` | 新增 `style_prior_divergence()`（dense/js/sparse_eps/legacy 四模式，含完整文档说明为何字面 KL 不可用）、`style_code_entropy()`（显式 +H）；`save/load_style_code_prior` 增 `vqvae_ckpt`/`db`/`num_codebooks` 溯源字段（旧文件仍可读）|
| `arch/flowmatch_vqvae_controller.py` | 新增 `style_prior_loss` 参数（默认 dense，校验合法值）；`_compute_style_regularizers` 改用稠密 logits 与 `style_prior_divergence`/`style_code_entropy`；选择器返回 `style_logits_are_dense` 标记；builder 透传；**修复 `quantizer.embedding.weight` → `quantizer.embedding_weight`**（见 8.4）|
| `train_flowmatch_vqvae_controller.py` | 新增 `--style-prior-loss {dense,js,sparse_eps,legacy}`；prior 溯源比对告警；`_weighted_loss_breakdown()` 输出各分项加权值与占比（写进 history 的 `weighted` 段）；**默认值重标定**：`--style-hist-weight` 0.2→0.02、`--style-entropy-weight` 1e-3→0.02 |
| `precompute_style_code_prior.py` | 写入溯源字段 |
| `run_train_flowmatch_vqvae_controller.sh` | 新增 `STYLE_PRIOR_LOSS` / `STYLE_HIST_WEIGHT` / `STYLE_ENTROPY_WEIGHT` 环境开关（修正过程中曾把 flag 误插进 precompute 命令数组，已修复）|
| `tests/test_style_code_prior.py`（新，16 项）| dense 的 CE 与 H(π̄) 相等、dense 不被 clamp 常数支配、legacy 与旧表达式逐位一致、JS 有界且 π=π̄ 时为 0、sparse_eps 更软、熵=+H 且变尖下降、溯源往返/旧文件兼容/形状校验、**控制器完整训练步（catch 8.4 的崩溃）** |
| `tests/test_precompute_pipeline.py` | 增 prior 不变量断言：行和=1、`selected_slots`=saliency top-M 且升序、counts=帧数×slots、溯源字段正确 |

### 8.2 实测（150-epoch VQ + 新建 cache/prior，1 epoch 控制器短训）

| 配置 | 总 loss | flow（占比）| L_prior | H(π) | top1 | prior 占比 |
|---|---|---|---|---|---|---|
| legacy（旧实现）| 4.0115 | 0.5367（13.4%）| **17.2841** | 1.1944 | 0.4543 | **86.2%** |
| dense + 旧权重（0.2/1e-3）| 1.5212 | 0.5364（35.3%）| **4.8336** | 1.3463 | 0.3296 | 63.6% |
| **dense + 新权重（0.02/0.02）** | **0.6663** | 0.5371（**80.6%**）| 5.2165 | 1.2963 | — | **15.7%**（ent 1.2%）|

关键验证：**新建先验自身的熵 $\mathcal H(\bar\pi)=4.834$，而 dense 训练 1 epoch 后 $L_{prior}=4.8336$** ——
交叉熵下界 $\mathrm{CE}(\bar\pi\|p)\ge\mathcal H(\bar\pi)$（等号仅当 $p=\bar\pi$）说明选择器已拟合到先验形态的理论最优，
且梯度是标准蒸馏梯度 $p-\bar\pi$，不再是覆盖度驱动的伪常数。legacy 模式数值与旧 checkpoint 口径一致（复现性保留）。

### 8.3 由数据决定的两处权重重标定（已改默认）

- `λ_prior` 0.2 → **0.02**：dense 口径下该项值域是 $[\mathcal H(\bar\pi),\log K]=[4.83,7.63]$（旧实现的伪常数 ~18），
  旧的 0.2 会让它 ≈7× flow 项；0.02 使其成为辅助正则（实测占比 15.7%）。
- `λ_ent` 1e-3 → **0.02**：旧实现下"峰度"其实来自 clamp 伪常数（legacy top1=0.454 vs dense 0.330），
  按论文式(7) 峰度应由熵项提供，而 1e-3 只占损失 0.03% ≈ 失效；改 0.02 后占 1.2%，建议 0.02–0.1 扫。
- 旧配置可复现：`--style-prior-loss legacy --style-hist-weight 0.2 --style-entropy-weight 1e-3`（checkpoint 的 config.json 也各自记录原值）。

### 8.4 执行过程中发现的真实链路阻塞（已修）

冒烟测试直接暴露：`arch/flowmatch_vqvae_controller.py` 内部调用
`self.vqvae.quantizer.embedding.weight`，而切换到 `vector_quantize_pytorch` 后量化器是
`LibraryVectorQuantizer`（只有 `embedding_weight` 属性）→ **任何控制器训练/仿真/评测都会立刻 AttributeError**。
这是替换量化器时遗留的调用点（我只审计了 CLI 与路径，没跑到运行时）。已改为量化器无关的
`quantizer.embedding_weight`（形状 `[K, code_dim]`），并新增
`ControllerPriorLossTests::test_controller_training_step_runs_end_to_end`（走完整
`compute_loss`）防止回归。全量测试 57 项通过。

### 8.5 仍需你决定的两项（未擅自改动）

1. **论文 tex 修订**：可粘贴的替换文本见 `PAPER_TEXT_AMENDMENTS.md`（式(3) 重归一化、式(6) 良定化、
   超参数补齐、优化器措辞、clip 分支说明）。
2. **§5 的进一步优化**（提高 $K_s/M_s$、对比式选码、逐风格 Ω 等）：默认关闭，需要时按消融口径开。
