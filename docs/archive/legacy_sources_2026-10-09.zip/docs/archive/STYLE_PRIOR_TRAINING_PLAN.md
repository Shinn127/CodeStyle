# Style prior 训练规划（Flow-matching 控制器阶段）

> 历史快照：保留原实验结论和配置，不能作为当前训练默认值。当前入口见 [README](../../README.md) 和 [teacher-forced 规划](../../TEACHER_FORCED_50E_PLAN.md)。


> 目标：用已修好的 style-code prior 监督，训练 flow-matching 控制器（style-code selector），
> 使**风格选择与离线先验一致、且不牺牲控制/重建质量**——即论文式 (4)(7)(8) 那套
> $\mathcal{L}=\mathcal{L}_{flow}+\lambda_{rec}\mathcal{L}_{rec}+\lambda_{prior}\mathcal{L}_{prior}+\lambda_{ent}\mathcal{L}_{ent}$
> 在当前 90-style 库 + 150-epoch VQ 表征上真正跑通。

---

## 0. 先厘清：哪些是"预计算"，哪些是"训练"

| 对象 | 性质 | 产物 | 是否本阶段训练 |
|---|---|---|---|
| 风格-码本先验 $\bar\pi_{s,j}$（式 1–3） | **离线统计**（Laplace 平滑的码频直方图，只用 train split 的帧） | `cache/style_code_prior_<vq>.npz` | 否（已生成，见 §2）|
| 显著度 $D_j$ 与 top-$M_s$ 槽位 $\Omega$（式 4） | 离线统计（JS 散度） | 同上（`slot_saliency` / `selected_slots`） | 否 |
| **style-code selector**（$\pi=\mathrm{TopK}_K(\mathrm{softmax}(a/\tau))$，式 5–6） | **可训练**（每槽位的码分布来自控制器输入） | 控制器权重 | ✅ 主要对象 |
| 控制器主干（content/style encoder + flow generator）（式 8 的 $\mathcal{L}_{flow}$、$\mathcal{L}_{rec}$） | 可训练 | 控制器权重 | ✅ 同一次训练 |

也就是说"训练 style prior"在本仓库的准确含义是：**在 flow-matching 训练里加先验监督，
把 selector 训到与先验一致**；先验本身是数据统计量，若换 VQ 表征必须重算。

---

## 1. 成功判据（改前 vs 现在的口径已不同）

先前发现的真实问题：论文式 (6) 的字面写法（KL 对齐 **TopK 稀疏的** $\pi$）在数学上是 $+\infty$
（本先验实测：$\Omega$ 内每个 (style, slot) 平均有 **80.7%** 的分布质量落在 top-4 之外，
range 3.9%–97.8%）；而旧的 `log(clamp(pi,1e-8))` 实现让 $\mathcal{L}_{prior}$ 常驻 ~18 nats，
占控制器总损失 ~86–90%，正好触发式 (7) 的熵项、把 loss 曲线"做平"。修好后
（`--style-prior-loss dense`）该顶的真值是 $\mathrm{CE}\ge \mathbb{E}_{\Omega}[\mathcal{H}(\bar\pi)]
= **4.834**$ nats（$\Omega$ 内 8 槽位平均；全 32 槽位为 5.133 nats，$\log 2048=7.625$），
1-epoch 冒烟实测 **5.18**（test）——已在下界附近。

| 判据 | 目标 | 现状（1-epoch 冒烟） |
|---|---|---|
| `style_hist_loss`（$\lambda_{prior}\mathcal{L}_{prior}$ 的裸值）| 收敛到 $\approx\mathbb{E}_{\Omega}[\mathcal{H}(\bar\pi)]=4.83$ nats（下界），且**占总损失 ≤30%** | 5.18 nats；flow 80.6% / prior 15.7% / entropy 1.2% |
| `style_entropy` $\mathcal{H}(\pi)$ | 随训练下降（式 7 鼓励 peaky） | 0.389 |
| `style_top1_prob` | 保持高位、不塌 | 0.911 |
| `flow_loss` / val flow loss | 与**无 selector 基线**同量级（劣化 ≤2%），即先验监督不伤控制 | 0.560（test）|
| 下游运动指标 | MPJPE/FID/F.S./Jitter 不差于基线控制器；风格准确率（CAMDM 分类器）不下降 | 待测（§7）|
| 复现性 | 同一配置 `--style-prior-loss legacy` 与旧 history 数值一致（回归护栏）| 已有单测 |

---

## 2. 就位情况审计（已核对）

| 依赖 | 路径 | 状态 |
|---|---|---|
| 90-style 库 | `database_100sty_375_memmap`（7,068,516 帧，clip 级 90/10/10 划分）| ✅ |
| 冻结 VQ 表征 | `checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt` + `norm_stats.npz` | ✅ |
| VQ 目标缓存 | `cache/vq_targets_..._150ep/`（`indices.u16` 452 MB，meta 记录 db / vqvae_ckpt / 32×4 / K=2048 全匹配）| ✅ |
| 先验统计 | `cache/style_code_prior_..._150ep.npz`：`prior (90,32,2048)`、`slot_saliency (32,)`、`selected_slots (8,)`、`counts`、`split=train`、`smoothing=1.0`，且记录了 vqvae_ckpt/db/num_codebooks 溯源 | ✅ |
| 代码修复 | `--style-prior-loss dense` 默认、权重 0.02/0.02、溯源告警、`quantizer.embedding_weight` 崩溃修复 | ✅（87 tests passed）|
| 待避的默认值 | wrapper 的 `VQ_CKPT` 默认指向 **100k/ep8** 权重；`OUT` 默认目录里是 head10 控制器 | ⚠️ 必须显式覆盖 |

---

## 3. 数据与切分

- 训练窗口：`seq_len=2, stride=1` → **5,712,896 窗/epoch**（实测）；val/test 各 10%（按 clip 划分，镜像变体随源 clip）。
- 先验只用 **train split 的帧**统计（含镜像变体，因为它们同属 train 的源 clip），val/test 不进入统计
  → 先验与评测集无泄漏。
- 条件构造（实测代码）：`encode_conditions()` 给出三条条件流 —— content = 当前帧的 motion 块
  （按数据布局，含义是"上一帧动作 + 当前轨迹上下文"）、traj = 当前帧轨迹上下文、
  style = $e_s$（selector 输出的风格 token，即论文式 (8) 的 $e_s=P([u])$）。
- 生成器 token 布局：`FlowGenerator.forward` 把 `z_t, z_prev, content, traj, style, time` 拼成
  **6 个 token**，读出第 0 个（$z_t$）预测速度；预测目标是**下一帧**的 32×4 量化 latent（由 VQ 目标缓存查表，不重跑编码器）。
  ⚠️ 论文写的是"noisy input 按 trajectory/content/style 以 3:1 patchify"，本实现是固定 6-token
  条件布局 —— 又一处需要在正文澄清的措辞差异（不影响本阶段训练，但写论文时要统一）。

---

## 4. 模型与超参（默认即论文口径）

| 项 | 值 | 来源 |
|---|---|---|
| content encoder | 2 层 MLP，256 hidden | 论文 |
| flow generator | 2 层 transformer，256 hidden / 4 heads / FFN 1024 / dropout 0 | 论文 |
| style encoder（label 分支）| 2 层 MLP，256 hidden（本仓库为 embedding+MLP）| 论文 |
| selector | hidden 128，slots $M_s=8$，TopK $K_s=4$，$\tau=1.0$ | 代码/论文式 (5)(6) |
| batch / lr / epochs | 512 / 5e-4 → 1e-5（cosine）/ **50**（论文）| 论文 §Training |
| 权重 | $\lambda_{rec}=0.1$、$\lambda_{prior}=0.02$、$\lambda_{ent}=0.02$ | 论文给出 0.1；prior/ent 为本次重调（旧值 0.2/1e-3 分别过大/无效）|
| 预测模式 | `velocity` | 论文（MFM 同款）|
| prev-frame 噪声 | latent 0.3 / motion 0.3 | 代码默认 |
| 推理 | Euler，$N=8$ steps | 论文 |

⚠️ **三处与论文文字的差异，需要你定**：

1. 论文写 **AdamWR（cosine-annealing warm restarts）**，代码是 `CosineAnnealingLR`（无重启）。
   建议改代码加重启（约 5 行）而不是改论文；否则在正文补一句"single cosine cycle"。
2. 论文 Table 2 的 FID 是用**全控制器 rollout** 算的（`simulate_realtime_flowmatch_control.py`），
   与我们表征层的 AE 重建口径不同；比较时必须走 rollout 路径。
3. 条件注入方式：论文"3:1 patchify" vs 实现"6-token 条件布局"（见 §3）——需要统一表述。

---

## 5. 训练日程与预算（RTX 5070 Ti 16 GB，实测 202.9 s/epoch）

| 阶段 | 配置 | 时长 | 说明 |
|---|---|---|---|
| ① 冒烟 | `--epochs 2` | ~7 min | 校验溯源、loss 分项、显存 |
| ② 主训练 | 50 epoch，默认超参 | **~2.8 h** | 对应论文口径，产出 `best.pt` |
| ③ 长训练（可选）| 150 epoch | ~8.5 h | 与控制器的 150ep 表征对齐；留 15 个快照 |
| ④ 消融 A | 去 selector（`USE_STYLE_CODE_SELECTOR=0`）| ~2.8 h | 对照组：先验监督的净效果 |
| ⑤ 消融 B | `--style-prior-loss legacy` | ~2.8 h | 证明修复的必要性（loss 常驻 ~18 nats）|
| ⑥ 消融 C | $\lambda_{prior}\in\{0.05,0.1\}$（各 25 epoch）| ~2.4 h | 先验权重敏感性 |
| ⑦ 评测 | rollout + 风格准确率 + 延迟 | ~1 h | §7 |
| ⑧ 换 VQ 快照时重算缓存 | 全库编码 + 索引/统计 | ~2–4 min | 实测 128,313 frames/s |

存储：控制器 checkpoint **71 MB/份**（实测 best/latest）；50 ep + `--save-every 10` ≈ 0.43 GB；150 ep ≈ 1.1 GB。

**推荐**：先跑 ②（50 ep，论文口径）→ ⑦ 评测 → 再决定是否补 ③/④/⑥。

---

## 6. 检查点与门禁

- `--val-every 1`、`--save-every 10`；`best.pt` 以 **val flow loss** 最小为准（现状行为）。
- 每个 epoch 记录 `history.jsonl`：`loss / flow_loss / recon_loss / style_hist_loss / style_entropy /
  style_top1_prob` 及 `weighted`（各项 raw/weighted/share）。
- **建议新增两条软门禁**（不改 best 逻辑，只在日志里告警）：
  - `style_hist_loss > 6.0` 或 prior 占比 > 35% → 打印 `[Warn]`（说明先验未被很好吸收或权重失衡）；
  - `style_top1_prob < 0.5` → `[Warn]`（选择塌陷）。
- 断点续训：`RESUME=<latest.pt>`（优化器/调度器/best_metric 都会恢复）。

---

## 7. 评测协议（训练完成后按顺序）

1. **控制器级**（不用 rollout）：val/test 的 `flow_loss`、`L_prior`、$\mathcal{H}(\pi)$、top1；
   与消融 A（无 selector）比较。
2. **风格准确率**：`run_evaluate_minor_revision_generalization.sh`（matched / cross / zero-shot），
   分类器用 **CAMDM 口径**的 `checkpoints/fid_feature_extractor_camdm100/...pth`
   ——注意 wrapper 默认仍是 7 月的 `fid_feature_extractor_classifier_full100`，需显式覆盖，
   否则与 FID 那条链路口径不一致。
3. **运动质量**：`run_simulate_realtime_flowmatch_control.sh` 产出 rollout，再用
   `evaluate_motion_375to291.py --models flowmatch_velocity` 评测（论文 Table 2 的 FID/FSD/Accel/TrajErr 口径）；
   同时报我们表征层那套 7 指标的 AE 口径值以便与表征表对齐。
4. **实时性**：8 步 Euler 的 p95 延迟 / 内存（论文 Table 3–4 口径）。

---

## 8. 命令（可直接执行）

```bash
PY=/home/shinn/miniforge3/envs/mcc/bin/python
VQ=$PWD/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt
PRIOR=$PWD/cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz
CACHE=$PWD/cache/vq_targets_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep
OUT=$PWD/checkpoints/flowmatch_vqvae_controller_prior_90st

# ① 冒烟（2 epoch）
PYTHON_BIN=$PY DB=$PWD/database_100sty_375_memmap VQ_CKPT=$VQ \
  VQ_TARGET_CACHE=$CACHE STYLE_CODE_PRIOR=$PRIOR \
  OUT=${OUT}_smoke STYLE_PRIOR_LOSS=dense \
  ./run_train_flowmatch_vqvae_controller.sh --epochs 2 --save-every 1

# ② 主训练（50 epoch，论文口径）
PYTHON_BIN=$PY DB=$PWD/database_100sty_375_memmap VQ_CKPT=$VQ \
  VQ_TARGET_CACHE=$CACHE STYLE_CODE_PRIOR=$PRIOR \
  OUT=$OUT STYLE_PRIOR_LOSS=dense STYLE_HIST_WEIGHT=0.02 STYLE_ENTROPY_WEIGHT=0.02 \
  ./run_train_flowmatch_vqvae_controller.sh --epochs 50 --save-every 10

# ③ 消融 A：无 selector 基线
... USE_STYLE_CODE_SELECTOR=0 OUT=${OUT}_nosel ...
# ④ 消融 B：旧实现口径（回归对照）
... STYLE_PRIOR_LOSS=legacy OUT=${OUT}_legacy ...

# 若换 VQ 快照（例如 epoch_0150.pt），先重算两级缓存（实测编码 128k frames/s → 全库 ~1 min GPU + 452 MB 索引写盘）
PYTHON_BIN=$PY DB=$PWD/database_100sty_375_memmap VQ_CKPT=<new_vq> \
  OUT=$PWD/cache/vq_targets_<new_vq_dirname> ./run_precompute_vq_targets.sh
PYTHON_BIN=$PY DB=$PWD/database_100sty_375_memmap \
  VQ_TARGET_CACHE=$PWD/cache/vq_targets_<new_vq_dirname> \
  OUT=$PWD/cache/style_code_prior_<new_vq_dirname>.npz ./run_precompute_style_code_prior.sh
# ⚠️ 两个独立 wrapper 的默认 OUT 都**不带 VQ 版本号**（按 INPUT_MODE/NETWORK_ARCH 派生），
#    换快照时必须显式给 OUT，否则会覆盖/复用错版本。控制器 wrapper 内部派生是带版本的。
```

---

## 9. 风险与对策

| 风险 | 影响 | 对策 |
|---|---|---|
| wrapper 默认 `VQ_CKPT` 指向 100k/ep8 权重 | 先验/缓存与控制器不匹配 | 全部显式传 `VQ_CKPT`；`VQTargetCache.validate()` 与先验溯源检查会报错 |
| 默认 `OUT` 覆盖 head10 控制器 | 丢历史产物 | 一律用版本化 `OUT` |
| 先验权重失衡（历史问题）| $\mathcal{L}_{prior}$ 主导、loss 曲线失真 | 已修 dense + 0.02/0.02；§6 的软门禁再兜一层 |
| 先验与地表征不匹配（VQ 换了没重算）| 静默劣化 | npz 记录 `vqvae_ckpt/db/num_codebooks`，加载时比对并告警 |
| 50 epoch 不足以吸收先验（$\mathcal{L}_{prior}$ 未降到 ~5）| 结论"先验没训进去" | 先看 ② 的曲线；不够再上 ③（150 ep）或把 $\lambda_{prior}$ 提到 0.05 |
| 风格准确率评测用错分类器口径 | 数字不可比 | §7.2 显式覆盖 `CLASSIFIER_CKPT` 为 CAMDM 版 |
| 论文写 AdamWR 但代码无 warm restart | 文字与实现不一致 | 二选一（§4 决策 1）|

---

## 10. 需要你拍板的三件事

1. **VQ 快照**：用 `150ep/best.pt`（缓存齐全，推荐）还是 `epoch_0150.pt`（精度更好、jitter 更差，
   需重算缓存 ~20 min）？
2. **训练长度**：50 epoch（论文口径，2.8 h）还是直接 150 epoch（8.5 h，与控制器的 150ep 对齐）？
3. **消融范围**：只做"无 selector"对照（④），还是加上 legacy 回归（⑤）与 $\lambda_{prior}$ 扫描（⑥）？

我的建议：**150ep/best.pt + 50 epoch 主训练 + ④ 对照**先出一版结果（约 6 h 机时），
再按曲线决定是否补长训练与权重扫描。
