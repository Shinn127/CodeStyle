# Checkpoint / Config / 脚本对应关系

> 历史快照：保留原实验结论和配置，不能作为当前训练默认值。当前入口见 [README](../../README.md) 和 [teacher-forced 规划](../../TEACHER_FORCED_50E_PLAN.md)。


整理日期：2026-07-01

这份文档用于把当前 `NewCode/checkpoints` 里的产物，对应回训练脚本、基础模型、cache、评估和仿真入口。后续开新实验前，建议先从这里确认 DB、checkpoint、cache 是否匹配。VQ 常用命令统一维护在 [`README.md`](../../README.md)，本文件不再重复命令示例。

## 总览

`NewCode` 目前主要有三类 DB：

| DB | 范围 | 用途 |
| --- | --- | --- |
| `NewCode/database_100sty_375_memmap_head10` | 10-style 子集 | 当前大部分 controller、VQ ablation、FID head 实验 |
| `NewCode/database_100sty_375_memmap` | full 100STYLE | full LMM/MVAE/VQ，以及 full VQ+FlowMatch |
| `NewCode/database_100sty_375_memmap_zeroshot` | zero-shot exemplar | 从外部/保留风格样例提取 style recipe |

## Head10 DB

对应 DB：`NewCode/database_100sty_375_memmap_head10`

这是当前最常用、最完整的一条实验线。推荐默认先用这一组，除非明确要跑 full DB。

### Head10 推荐主线

| 目的 | 路径 | 生成脚本 | 说明 |
| --- | --- | --- | --- |
| 基础 VQ-VAE | `checkpoints/vqvae_traj_motion_skip_mlp_375to291_32_4_2048/best.pt` | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，ControlOperators `SkipMLP`，32 slots x 4 dim，2048 codes |
| VQ target cache | `cache/vq_targets_vqvae_traj_motion_skip_mlp_375to291_32_4_2048_head10` | `run_precompute_vq_targets.sh`，或 Flow/Diffusion wrapper 自动生成 | 必须匹配 head10 DB 和上面的 VQ checkpoint |
| Style code prior | `cache/style_code_prior_vqvae_traj_motion_skip_mlp_375to291_32_4_2048_head10.npz` | `run_precompute_style_code_prior.sh`，或 Flow/Diffusion wrapper 自动生成 | 给 style-code-selector 监督使用 |
| 当前 style-prior FlowMatch | `checkpoints/flowmatch_vqvae_controller/best.pt` | `run_train_flowmatch_vqvae_controller.sh` | `prediction_mode=velocity`，启用 style-code-selector |
| plain velocity FlowMatch | `checkpoints/flowmatch_vqvae_controller_velocity_head10/best.pt` | `run_train_flowmatch_vqvae_controller.sh` | 未记录 style selector，适合作为无 style-prior 对照 |
| target-mode FlowMatch | `checkpoints/flowmatch_vqvae_controller_target_head10/best.pt` | `run_train_flowmatch_vqvae_controller.sh` | `prediction_mode=target` ablation |
| MANN baseline | `checkpoints/mann_controller/best.pt` | `run_train_mann_controller.sh` | head10 direct controller baseline |
| CAMDM baseline | `checkpoints/camdm_controller/best.pt` | `run_train_camdm_controller.sh` | head10 diffusion-style baseline |

### Head10 Checkpoints

| Checkpoint | 类型 | 训练脚本 | 关键配置 | 依赖 |
| --- | --- | --- | --- | --- |
| `checkpoints/basic_vqvae_375to291_8_16_1024` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，`num_latents=8`，`code_dim=16`，`num_embeddings=1024`，`seq_len=2` | 无 |
| `checkpoints/basic_vqvae_375to291_16_8_1024` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，`num_latents=16`，`code_dim=8`，`num_embeddings=1024`，`seq_len=2` | 无 |
| `checkpoints/basic_vqvae_375to291_32_4_512` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，`num_latents=32`，`code_dim=4`，`num_embeddings=512`，`seq_len=2` | 无 |
| `checkpoints/basic_vqvae_375to291_32_4_1024` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，`num_latents=32`，`code_dim=4`，`num_embeddings=1024`，`seq_len=2` | 无 |
| `checkpoints/basic_vqvae_375to291_32_4_2048` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，`num_latents=32`，`code_dim=4`，`num_embeddings=2048`，`seq_len=2` | 无 |
| `checkpoints/vqvae_traj_motion_skip_mlp_375to291_32_4_2048` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | 新主线；ControlOperators `SkipMLP` encoder/decoder，稳定 EMA，启用 rotation trick | 无 |
| `checkpoints/vqvae_traj_motion_375to291_32_4_2048` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | 与 `basic_vqvae_375to291_32_4_2048` 基本同构 | 无 |
| `checkpoints/vqvae_motion_only_375to291_32_4_2048` | VQ-VAE ablation | `run_train_basic_vqvae_375to291.sh` | `input_mode=motion_only`，`num_latents=32`，`code_dim=4`，`num_embeddings=2048` | 无 |
| `checkpoints/lmm_375to291_head10` | LMM autoencoder | `run_train_lmm_375to291.sh` | `seq_len=2` | 无 |
| `checkpoints/mvae_375to291_head10` | MVAE rollout AE | `run_train_mvae_375to291.sh` | `seq_len=8` | 无 |
| `checkpoints/mann_controller` | direct controller | `run_train_mann_controller.sh` | `model_type=mann_375to291_controller`，`seq_len=2` | 无 |
| `checkpoints/camdm_controller` | direct diffusion controller | `run_train_camdm_controller.sh` | `model_type=camdm_375to291_controller`，`seq_len=2` | 无 |
| `checkpoints/flowmatch_vqvae_controller_velocity_head10` | VQ+FlowMatch | `run_train_flowmatch_vqvae_controller.sh` | `prediction_mode=velocity`，未记录 style selector | `basic_vqvae_375to291_32_4_2048`，`vq_targets_basic_vqvae_375to291_32_4_2048_head10` |
| `checkpoints/flowmatch_vqvae_controller_target_head10` | VQ+FlowMatch | `run_train_flowmatch_vqvae_controller.sh` | `prediction_mode=target`，未记录 style selector | `basic_vqvae_375to291_32_4_2048`，`vq_targets_basic_vqvae_375to291_32_4_2048_head10` |
| `checkpoints/flowmatch_vqvae_controller` | VQ+FlowMatch | `run_train_flowmatch_vqvae_controller.sh` | `prediction_mode=velocity`，`use_style_code_selector=true` | `basic_vqvae_375to291_32_4_2048`，VQ target cache，style code prior |
| `checkpoints/flowmatch_lmm_controller_velocity_head10` | LMM+FlowMatch | `run_train_flowmatch_lmm_controller.sh` | `prediction_mode=velocity` | `lmm_375to291_head10` |
| `checkpoints/diffusion_vqvae_controller` | VQ+Diffusion | `run_train_diffusion_vqvae_controller.sh` | `use_style_code_selector=true` | `basic_vqvae_375to291_32_4_2048`，VQ target cache，style code prior |
| `checkpoints/diffusion_lmm_controller` | LMM+Diffusion | `run_train_diffusion_lmm_controller.sh` | `base_model_type=lmm` | `lmm_375to291_head10` |
| `checkpoints/fid_feature_extractor_head10` | FID feature extractor | `run_train_fid_feature_extractor_head10.sh` | 当前没有 `config.json` | 无 |

### Head10 Caches

| Cache | 生成方式 | 消费方 | 必须匹配 |
| --- | --- | --- | --- |
| `cache/vq_targets_vqvae_traj_motion_skip_mlp_375to291_32_4_2048_head10` | `run_precompute_vq_targets.sh`，或 VQ Flow/Diffusion wrapper 自动生成 | head10 VQ+FlowMatch、VQ+Diffusion | head10 DB + `vqvae_traj_motion_skip_mlp_375to291_32_4_2048` |
| `cache/style_code_prior_vqvae_traj_motion_skip_mlp_375to291_32_4_2048_head10.npz` | `run_precompute_style_code_prior.sh`，或 VQ Flow/Diffusion wrapper 自动生成 | style-selector 版本的 VQ+FlowMatch/VQ+Diffusion | 上面的 VQ target cache |

### Head10 常用命令入口

| 任务 | Wrapper | 建议显式设置 |
| --- | --- | --- |
| 训练 VQ+FlowMatch | `run_train_flowmatch_vqvae_controller.sh` | `DB=NewCode/database_100sty_375_memmap_head10`，`VQ_CKPT=...basic_vqvae.../best.pt`，`OUT=...` |
| 训练 VQ+Diffusion | `run_train_diffusion_vqvae_controller.sh` | 同上 |
| 训练 MANN | `run_train_mann_controller.sh` | `DB=NewCode/database_100sty_375_memmap_head10` |
| 训练 CAMDM | `run_train_camdm_controller.sh` | `DB=NewCode/database_100sty_375_memmap_head10` |
| 统一指标评估 | `run_evaluate_motion_375to291.sh` | `DB=NewCode/database_100sty_375_memmap_head10`，并显式传入模型 checkpoint |
| rollout MPJPE 曲线 | `run_evaluate_rollout_mpjpe_curve.sh` | 默认就是 head10 DB |
| FlowMatch rollout / style transfer | `run_simulate_realtime_flowmatch_control.sh` | 必须显式设置 head10 DB，见“已知命名漂移” |
| MANN rollout | `run_simulate_realtime_mann_control.sh` | 必须显式设置 head10 DB |
| CAMDM rollout | `run_simulate_realtime_camdm_control.sh` | 默认就是 head10 DB |

## Full DB

对应 DB：`NewCode/database_100sty_375_memmap`

full DB 线主要用于完整 100STYLE 数据上的表示模型、LMM/MVAE，以及 full VQ+FlowMatch。

### Full Checkpoints

| Checkpoint | 类型 | 训练脚本 | 关键配置 | 依赖 |
| --- | --- | --- | --- | --- |
| `checkpoints/vqvae_traj_motion_375to291_32_4_2048_full` | VQ-VAE | `run_train_basic_vqvae_375to291.sh` | `traj_motion`，full DB，`num_latents=32`，`code_dim=4`，`num_embeddings=2048`，`seq_len=2` | 无 |
| `checkpoints/lmm_375to291` | LMM autoencoder | `run_train_lmm_375to291.sh` | `seq_len=2`，full DB | 无 |
| `checkpoints/mvae_375to291` | MVAE rollout AE | `run_train_mvae_375to291.sh` | `seq_len=8`，full DB | 无 |
| `checkpoints/flowmatch_vqvae_controller_full` | VQ+FlowMatch | `run_train_flowmatch_vqvae_controller.sh` | `prediction_mode=velocity`，`use_style_code_selector=true`，full DB | `vqvae_traj_motion_375to291_32_4_2048_full`，full VQ target cache，full style code prior |

### Full Caches

| Cache | 生成方式 | 消费方 | 必须匹配 |
| --- | --- | --- | --- |
| `cache/vq_targets_vqvae_traj_motion_skip_mlp_375to291_32_4_2048_full` | `run_precompute_vq_targets.sh` | `flowmatch_vqvae_controller_full` | full DB + matching `skip_mlp` VQ checkpoint |
| `cache/style_code_prior_vqvae_traj_motion_skip_mlp_375to291_32_4_2048_full.npz` | `run_precompute_style_code_prior.sh` | `flowmatch_vqvae_controller_full` | full VQ target cache |
| `cache/vq_targets_basic_vqvae_375to291_32_4_2048` | `run_precompute_vq_targets.sh` | 旧实验/混合命名实验 | 需要回查生成时 DB，不建议新实验优先使用 |
| `cache/style_code_prior_basic_vqvae_375to291_32_4_2048.npz` | `run_precompute_style_code_prior.sh` | 旧实验/混合命名实验 | 需要回查生成时 DB，不建议新实验优先使用 |

### Full 常用命令入口

| 任务 | Wrapper | 建议显式设置 |
| --- | --- | --- |
| 训练 full LMM | `run_train_lmm_375to291.sh` | 默认 DB 是 full，可显式设置以避免混淆 |
| 训练 full MVAE | `run_train_mvae_375to291.sh` | 默认 DB 是 full，可显式设置以避免混淆 |
| 训练 full VQ+FlowMatch | `run_train_flowmatch_vqvae_controller.sh` | `DB=NewCode/database_100sty_375_memmap`，`VQ_CKPT=...vqvae_traj_motion...full/best.pt`，`OUT=...flowmatch_vqvae_controller_full` |
| baseline reconstruction preview | `run_simulate_realtime_baselines.sh` | 默认 DB 是 full，适合 full LMM/MVAE/VQ |

## Zero-shot DB

对应 DB：`NewCode/database_100sty_375_memmap_zeroshot`

这条线不是训练主模型，而是从 exemplar clip 中提取 style recipe，再喂给支持 style-code-selector 的 FlowMatch checkpoint。

| 产物 | 生成脚本 | 消费脚本 | 说明 |
| --- | --- | --- | --- |
| `cache/zeroshot_style_recipes/*.json` | `run_build_zeroshot_style_recipe.sh` | `run_simulate_realtime_flowmatch_control.sh`，通过 `STYLE_RECIPE=...` 传入 | 需要 style-selector FlowMatch checkpoint |
| `style_recipe_demo.json` | 手写/示例 recipe | `run_simulate_realtime_flowmatch_control.sh` | 用于演示 style recipe 格式 |

## 评估和仿真入口

| 任务 | Wrapper | 默认目标 |
| --- | --- | --- |
| 统一 motion 指标评估 | `run_evaluate_motion_375to291.sh` | `eval_results/motion_375to291` |
| rollout MPJPE 曲线 | `run_evaluate_rollout_mpjpe_curve.sh` | CAMDM、MANN、VQ+FlowMatch velocity、LMM+FlowMatch velocity |
| VQ/LMM/MVAE 重建预览 | `run_simulate_realtime_baselines.sh` | full DB 和 baseline checkpoints |
| MANN rollout 预览 | `run_simulate_realtime_mann_control.sh` | `checkpoints/mann_controller/best.pt` |
| CAMDM rollout 预览 | `run_simulate_realtime_camdm_control.sh` | `checkpoints/camdm_controller/best.pt` |
| FlowMatch rollout / style transfer | `run_simulate_realtime_flowmatch_control.sh` | `checkpoints/flowmatch_vqvae_controller/best.pt` |
| Zero-shot recipe 提取 | `run_build_zeroshot_style_recipe.sh` | zeroshot DB + FlowMatch checkpoint |

## 已知命名漂移和风险点

这些不一定是 bug，但最容易导致 checkpoint/cache/DB 配错。

1. `basic_vqvae_375to291_32_4_2048` 和 `vqvae_traj_motion_375to291_32_4_2048` 是旧纯 MLP 实验；新默认主线使用 `vqvae_traj_motion_skip_mlp_375to291_32_4_2048`。
2. 新 VQ checkpoint 改变了 encoder/decoder 结构、rotation backward 和 EMA 更新，不能复用旧 VQ target cache 或 style code prior。
3. `run_simulate_realtime_flowmatch_control.sh` 默认 `DB` 是 full DB，但默认 `FLOW_CKPT` 是 head10 的 `flowmatch_vqvae_controller/best.pt`。跑当前 head10 主线时，应显式设置 `DB=NewCode/database_100sty_375_memmap_head10`。
4. `run_simulate_realtime_mann_control.sh` 默认 `DB` 是 full DB，但 `checkpoints/mann_controller/best.pt` 是 head10 训练出来的。做公平对比时也要显式设置 head10 DB。
5. 有些新 controller 产物写 `last.pt`，多数旧训练产物写 `latest.pt`。除非是续训，否则优先使用 `best.pt`。
6. `checkpoints/fid_feature_extractor_head10` 有训练产物和 `history.jsonl`，但当前没有 `config.json`。

## 后续新实验命名建议

新建 `OUT` 目录时建议包含：基础表示、方法、模式、DB 范围、是否使用 style prior。

推荐格式：

```text
<base>_<method>_<mode>_<db_scope>[_styleprior][_ablation]
```

示例：

```text
vqvae_traj_motion_32x4x2048_head10
flowmatch_vqvae_velocity_head10_styleprior
flowmatch_vqvae_target_head10_no_styleprior
flowmatch_lmm_velocity_head10
flowmatch_vqvae_velocity_full_styleprior
```

开新 run 时，建议显式设置 `DB`、base checkpoint、cache 路径和 `OUT`。这样 `config.json` 会成为可靠的记录源，也能避免误用相近名字的默认路径。
