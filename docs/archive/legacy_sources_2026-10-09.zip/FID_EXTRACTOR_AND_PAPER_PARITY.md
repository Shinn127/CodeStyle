# FID 特征提取器：训练方式、口径核验与论文同口径复测

2026-10-05更新：新style classifier入口默认60fps/240帧，见 [`STYLE_CLASSIFIER_240F.md`](STYLE_CLASSIFIER_240F.md)。下文训练结果与FID数字属于历史60帧协议；新4秒classifier不自动替换FID extractor。官方与本地帧率、Hips中心化、生成分类聚合的差异见 [`CAMDM核对记录`](analysis/CAMDM_STYLE_EVAL_AUDIT_2026-10-05.md)，不能仅凭同构网络宣称完整评估口径相同。

本文回答两件事：

1. **FID 用的特征提取器是怎么训练的**（`Utils/fid_feature_extractor.py` +
   `train_fid_feature_extractor_head10.py`），以及"必须在完整 100 style 上训练"这条要求
   在代码里的落点。
2. **口径核验**：本轮修订中我们曾用哪个提取器、哪些库做评测，与论文表格里的数字是否同口径；
   结论是**曾经不同口径**，本文给出证据与修正后的同口径复测表。

---

## 1. 提取器是什么、怎么训练

### 1.1 结构（`Utils/fid_feature_extractor.py::MotionFeatureClassifier`）

与 CAMDM 的 `CAMDM-main/Evaluation/feature_extractor/train_classifier.py` 结构一致：

```
输入 x: [B, T=60, 72]（24 个选中关节的 root-相对局部位置，xyz × 24 = 72 维）
↓ permute → [B, 72, 60]
Conv1d(72→64,  k=3, pad=1) + BN + LeakyReLU + 1×1 残差
Conv1d(64→128, k=3, pad=1) + BN + LeakyReLU + 1×1 残差
Dropout(0.5) → flatten(128×60) → Linear(→1024) + BN + LeakyReLU
           → Linear(→512) + BN + LeakyReLU      ← 这一层 512 维激活就是 FID 特征
           → Linear(→ num_styles)               ← 只用于训练时的交叉熵
```

- **FID 特征 = 512 维倒数第二层激活**（`get_feats()`），`forward()` 同时返回
  `(feats, logits)`；FID = real / generated 两组 512 维特征的 Fréchet 距离
  （`Utils/motion_eval.py::frechet_distance`，含 `fid_eps=1e-6` 岭修正与 bootstrap CI）。
- 输入取的是 375 维特征的 `[..., 87:159]`（`motion375_clip_to_classifier_input`），
  即 motion 块里 root 后面那 72 维局部位置；**使用反归一化后的原生米制数值**
  （`evaluate_motion_375to291.py` 里先 `denormalize_motion_batch`，再送分类器）。

### 1.2 训练方式（监督信号是"风格分类"）

`train_fid_feature_extractor_head10.py`（脚本名是历史遗留，逻辑与 DB 无关，可训练任意库）：

| 项 | 值 |
|---|---|
| 目标 | 交叉熵风格分类，`class_num = len(StyleNames.json)` |
| 样本 | 每个 clip 内按 `--stride`（默认 10）滑 60 帧窗口 |
| batch / 优化器 | 1024 / AdamW(lr=1e-3, wd=1e-4)，CosineAnnealing 到 1e-3 |
| epochs | 50；`best.pt` 取验证 loss 最低；每 `--save-every`（默认 10）存快照 |
| 归一化 | **不归一化**（`normalize=False`），直接吃库里的原始特征 |
| 标签来源 | `Labels.i32` + `StyleNames.json` |

checkpoint 里除 `state_dict` 还写 `class_names / class_num / in_feat / window_size / args`，
评测时 `build_motion_feature_classifier_from_checkpoint()` 会校验 `window_size==--seq-len`。

### 1.3 "必须在完整 100 style 上训练"——为什么

分类器的 512 维特征空间是由**它见过的风格**塑造的。只在 10 个风格上训练的提取器，
对另外 90 个风格处于分布外，产出的"特征"仍是一个确定性函数，但 FID 就变成
**任意特征空间里的一个数**，与论文表格里的 FID 不可比。

实测（`database_100sty_375_memmap`，每风格 60 个窗口，按镜像分组）：

| 提取器 | 训练库 | unmirrored 准确率 | mirrored 准确率 |
|---|---|---|---|
| `fid_feature_extractor_head10`（10 类） | `database_100sty_375_memmap_head10`（10 style） | **100.00 %** | 3.17 % |
| `fid_feature_extractor_classifier_full100`（100 类，2026-07） | `..._classifier_full100`（100 style） | 99.83 % | 99.67 % |
| `fid_feature_extractor_full100_v4`（100 类，本次新建） | `database_100sty_375_memmap_fid_full100`（100 style） | 98.83 % | 99.33 % |

- 10 类提取器在**自己那 10 个风格、无镜像**的数据上 100% 正确 → 论文口径的数据是
  **无镜像**的；它在 90-style 库上整体只有 57.75%（= 100% / 3% 按镜像比例混合）。
- 两个 100 类提取器对镜像/非镜像都 ~99% → 2026-07 之后的库（含 v4）与论文期库的差别
  **不只是风格数量，还有镜像增强**。

### 1.4 本次补做：100 style 提取器的可复现训练

```bash
# 1) 合成 100-style 库（90 IND + 10 OOD，帧数据逐字节复制，只重映射标签/切分）
python merge_memmap_dbs.py \
  --primary   database_100sty_375_memmap \
  --secondary database_100sty_375_memmap_zeroshot \
  --out       database_100sty_375_memmap_fid_full100
#    → 100 styles / 7,492,226 帧 / 1539 segments；val/test 仍只含 IND（OOD 全部进 train）

# 2) 在完整 100 style 上训练（~4.5 min，RTX A4500）
./run_train_fid_feature_extractor_full100.sh     # OUT=checkpoints/fid_feature_extractor_full100_v4
```

结果：50 epoch，`train_acc 99.96%`，`val_acc 79.28%`，`test_acc 78.92%`
（监控集是 90 个 IND 风格的 held-out clip，OOD 全部在训练集中——见 §4 讨论）。

### 1.5 与 CAMDM 官方提取器对齐（现行主口径）

CAMDM（https://github.com/AIGAnimation/CAMDM）的 FID 提取器在
`Evaluation/feature_extractor/train_classifier.py` + `process_train_data.py`：15 个
`ybot_skeleton` 关节（45 维）、60 帧窗口、`clip_offset=10`、batch 1024、Adam lr 1e-3、
CrossEntropyLoss、50 epoch、**不划分训练/验证/测试，全部 clip 都是训练数据**，
存盘键为 `state_dict / in_feat / acc / class_names`。

本次按该实现新增 `train_fid_feature_extractor_camdm.py`（+ wrapper
`run_train_fid_feature_extractor_camdm.sh`），**逐项对齐**：

| 项 | CAMDM 上游 | 本次实现 |
|---|---|---|
| 网络 | `Classifier`：conv1/bn1+conv2/bn2 残差栈、`residual1x1_*`、dropout 0.5、fc1(128·W→1024)+bn3、fc2(1024→512)+bn4、fc3(512→C) | 同一结构（`Utils.fid_feature_extractor.MotionFeatureClassifier`），逐层一致 |
| 输入 | 15 个 ybot 关节的 root-相对局部位置 = 45 维 | 同（`YBOT15_JOINT_NAMES` 顺序；由本项目 24 关节块按**关节名**抽取，`YBOT15_TO_SELECTED24_INDICES = [0,5,7,8,9,10,12,13,14,16,17,18,20,21,22]`）|
| 窗口/步长 | 60 帧，`clip_offset=10` | 同（每个 clip 内 `arange(0, n-59, 10)`）|
| 优化 | Adam(lr=1e-3)、CE、batch 1024、shuffle、50 epoch | 同（默认值即上游值，命令行可查） |
| 数据划分 | 无（全量训练） | 无（`--db` 的 `split` 字段被忽略；见下） |
| 存盘 | `state_dict / in_feat / acc / class_names` | 同 + 本项目溯源字段（`window_size / joint_set / db / clip_offset / epochs / include_mirror / temporal_stride`）|

两处**有意为之**的差异（已写进脚本 docstring）：

1. **数据源**：CAMDM 读 `data/100style_position_ori+ybot.pkl`（他们自己在 100STYLE BVH 上
   跑的预处理），本项目读 schema-v4 memmap 库中同一份 100STYLE 动作的本地位置；两者都是
   "root-相对、米制、ybot 骨架"，但 CAMDM 发布的 pkl 先把 BVH 重采样到 **30 fps**，本项目库
   保持原生 **60 fps**，所以 60 帧窗口是 1 s 而不是 2 s。选择按 60 fps 训练是为了让提取器与
   评测数据同分布（跨帧率的特征分布漂移会污染 FID）。
2. **镜像**：CAMDM / 100STYLE 本身无镜像增强，故默认只用**非镜像** segment 训练
   （`--include-mirror` 可打开）；镜像版另存一份 `checkpoints/fid_feature_extractor_camdm100_mirror/`，
   供带镜像的库使用。

训练与校验（`database_100sty_375_memmap_fid_full100`，810 个非镜像 clip、391,373 个窗口、
100 个风格，~2.5 min）：

| 产物 | 训练数据 | 训练准确率 | 评测窗口准确率（无镜像 / 镜像）|
|---|---|---|---|
| `checkpoints/fid_feature_extractor_camdm100/100style_position_classifier.pth` | 100 style，非镜像 | 99.90 % | 90.4 % / 0.8 % |
| `checkpoints/fid_feature_extractor_camdm100_mirror/100style_position_classifier.pth` | 100 style，含镜像 | 99.92 % | ~99 % / ~99 % |

（"评测窗口准确率"是在库里按随机 clip+偏移取样测的；无镜像版对镜像数据接近 0 是因为它从未见过
镜像——这正是 §3 的协议只在**无镜像**测试集上做 FID 的原因之一。）

⚠️ **聚合方式注意**：CAMDM 的 `eval_motion_FID.py` 是**逐 style**把生成/真值的特征在
**非重叠** 60 帧 clip 上求 mu/sigma，算出 Fréchet 距离后还要 **除以特征维度**（`fid/len(sigma)`）
再对该 style 的所有文件取平均；本项目评测脚本（论文表格口径）是把整个测试集的特征池化后算**一个**
Fréchet 距离、不做维度归一。两者数值不可直接比较（CAMDM 报的 0.961 是前者）。

---

## 2. 口径核验：论文那一行到底是在什么数据上测的

论文表格（R2 版 `MM-2025-11-0162.R2_Ma.tex` 第 524 行）的 MotionVQ 行
`3.653 / 3.060 / 0.277 / 0.252` 来自 `eval_results/basic_vqvae_32_4_2048/motion_eval_summary.json`：

- 权重：`checkpoints/basic_vqvae_375to291_32_4_2048/best.pt`
  （其 `args.db` = `database_100sty_375_memmap_head10`，即**只有 10 个风格**的训练库，50 epoch）
- 测试库：`database_100sty_375_memmap_head10`，905 个 60 帧窗口（stride 30）
- FID 提取器：`checkpoints/fid_feature_extractor_head10/best.pt`（**10 类**）

**复现实验（本次）**：用当前生成器重建同样口径的库

```bash
python generate_database_100sty.py --style-limit 10 --zero-shot-style-count 0 --no-mirror \
  --output database_100sty_375_memmap_head10_v4 --zero-shot-output /tmp/unused
python evaluate_motion_375to291.py --db database_100sty_375_memmap_head10_v4 \
  --models basic_vqvae \
  --basic-vqvae-ckpt checkpoints/basic_vqvae_375to291_32_4_2048/best.pt \
  --allow-legacy-quantizer --out-dir eval_results/diag_paper_ckpt_head10_v4
```

得到 `MPJPE 3.653 ± 0.187 / RootADE 2.840 ± 0.172 / Heading 3.024 ± 0.168 /
VelDir 3.923 ± 0.174 / F.S. 0.277 ± 0.026 / Jitter 0.252 ± 0.006`
——与论文表格**逐位一致**。这一步同时证明了三件事：

1. 论文口径 = **10 style、无镜像、905 窗口**的测试集；
2. v4 特征空间与论文期特征空间在**无镜像**数据上一致（否则不可能复现到小数点）；
3. `--allow-legacy-quantizer` 的 AE 兼容加载是正确的
   （论文期 checkpoint 的量化器是 `quantizer.embedding.weight / ema_*` 旧键；
   AE 路径 `encode_pre_vq → decode(z_e)` 不经过量化器，故可安全丢弃那 3 个张量加载）。

### 2.1 镜像增强是 v4 新增的

论文期 checkpoint 在 v4 的**镜像**半区会崩：同一模型在 v4 库上按镜像分组测
`local_pos` 归一化 MAE = **0.178（无镜像） vs 14.37（镜像）**。
这解释了为什么把论文 checkpoint 直接丢到带镜像的 90-style 库上会得到 MPJPE 24.97 cm
（表观上像"库不兼容"，实为镜像半区 + 10-style 模型对 90 风格的双重失配）。

---

## 3. 同口径复测（Protocol A / B）

- **Protocol A**：`database_100sty_375_memmap_head10_v4`（10 style、无镜像、905 窗口）
  ——论文自己的测试集，论文行的数字就是 `3.653 / … / 0.252`。
- **Protocol B**：`database_100sty_375_memmap_unmirrored`（90 个 IND 风格、无镜像、~10k 窗口）
  ——我们模型的更宽测试集；论文 checkpoint 在这里会被 80 个没见过的风格拖垮，
  只能作为"它是 10-style 模型"的证据，不作为竞争力对比。
- 两个协议都用**同一个提取器**，且 FID 只在**无镜像**测试集上算（§2.1 的原因）。
- `--decode-smooth-taps`：解码端对 291 维动作块做二项式时序滤波（3 = `[1,2,1]/4`），
  轨迹 84 维不动；这是"带时序解码器的表征"档位，与 raw 档并列报告。

复现：
```bash
# 主口径（CAMDM 45 维提取器）
EXTRACTOR=$PWD/checkpoints/fid_feature_extractor_camdm100/100style_position_classifier.pth \
TAG_PREFIX=camdm100 ./analysis/run_paper_parity.sh all
# 备份口径（本项目 24 关节 / 72 维提取器）
TAG_PREFIX=paper_parity ./analysis/run_paper_parity.sh all
python analysis/summarize_paper_parity.py
```

FID 依赖提取器：**跨提取器的 FID 数值不可比**，所以下面按提取器分两套表。
主口径 = CAMDM 的 45 维提取器（§1.5，与 R2 定稿里"FID uses the feature extractor from
the CAMDM implementation"一致）；备份口径 = 本项目 72 维提取器（交叉验证）。

### 3.1 Protocol A（论文自己的测试集，905 窗口）— CAMDM 提取器（主口径）

| run | MPJPE (cm) | RootADE (cm) | Heading (deg) | VelDir (deg) | FID | F.S. (cm) | Jitter (cm) |
|---|---|---|---|---|---|---|---|
| 论文 MotionVQ（taps=1） | 3.6534 | 2.8399 | 3.0238 | 3.9225 | 23.2909 | 0.2772 | 0.2519 |
| 100k best（taps=1） | 1.8086 | 0.8756 | 0.2813 | 0.6419 | 33.4628 | 0.2918 | 0.2544 |
| 100k best（taps=3） | 1.8081 | 0.8766 | 0.2833 | 0.6764 | 33.3219 | 0.2812 | 0.2271 |
| 150ep best（taps=1） | 1.3240 | 0.3892 | 0.2531 | 0.4084 | 22.9302 | 0.2810 | 0.2702 |
| **150ep best（taps=3）** | **1.3230** | **0.3897** | **0.2584** | **0.4581** | **22.8290** | **0.2659** | **0.2292** |

与论文行逐项比较（✓ = 优于论文点估计；FID 差/优按同一提取器判定）：

| run | MPJPE | RootADE | Heading | VelDir | FID | F.S. | Jitter | 合计 |
|---|---|---|---|---|---|---|---|---|
| 100k best（taps=1） | ✓ 2.0× | ✓ 3.2× | ✓ 10.8× | ✓ 6.1× | ✗ +43.7% | ✗ +5.3% | ✗ +1.0% | 4/7 |
| 100k best（taps=3） | ✓ 2.0× | ✓ 3.2× | ✓ 10.7× | ✓ 5.8× | ✗ +43.1% | ✗ +1.4% | ✓ 0.227 | 5/7 |
| 150ep best（taps=1） | ✓ 2.8× | ✓ 7.3× | ✓ 11.9× | ✓ 9.6× | ✓ 1.6% | ✗ +1.4% | ✗ +7.3% | 5/7 |
| 150ep best（taps=3） | ✓ 2.8× | ✓ 7.3× | ✓ 11.7× | ✓ 8.6× | ✓ 2.0% | ✓ 0.266 | ✓ 0.229 | **7/7** |

（完整 CI 见 `eval_results/camdm100_*/motion_eval_summary.json`。）

说明：Protocol A 只有 905 个窗口，FID 的 bootstrap CI 约 ±1.9（±8%），所以 150ep 的
FID 优势（22.83 vs 23.29）是"同向、不过 CI"的量级；F.S. 的 CI 约 ±0.03，
raw 档 0.2810 vs 0.2772 在 CI 内重叠，滤波后 0.2659 才稳定低于论文。
Protocol B 的 ~10k 窗口上结论更硬（FID 12.85 vs 127.11，F.S. 0.278 vs 0.2777 持平，
jitter 0.216 vs 0.2323 更优）。

### 3.2 Protocol B（90 个 IND 风格、无镜像，~10k 窗口）— CAMDM 提取器（主口径）

| run | MPJPE (cm) | RootADE (cm) | Heading (deg) | VelDir (deg) | FID | F.S. (cm) | Jitter (cm) |
|---|---|---|---|---|---|---|---|
| 论文 MotionVQ（10-style，taps=1） | 6.1669 | 3.9944 | 4.3227 | 6.0520 | 127.1140 | 0.2885 | 0.2706 |
| 论文 MotionVQ（10-style，taps=3） | 6.1641 | 3.9942 | 4.3228 | 6.0445 | 127.0680 | 0.2777 | 0.2323 |
| 100k best（taps=1） | 1.5049 | 0.5617 | 0.2561 | 0.6400 | 21.1539 | 0.2907 | 0.2359 |
| 100k best（taps=3） | 1.5018 | 0.5608 | 0.2590 | 0.6834 | 21.0665 | 0.2778 | 0.2084 |
| 150ep best（taps=1） | 1.3644 | 0.3917 | 0.2844 | 0.4821 | 12.8517 | 0.2983 | 0.2621 |
| **150ep best（taps=3）** | 1.3616 | 0.3922 | 0.2889 | 0.5467 | 12.8499 | 0.2784 | 0.2155 |

### 3.3 CAMDM 聚合口径的 FID（与 CAMDM 论文数字同一种数法）

CAMDM 报出来的 FID（他们论文里 CAMDM 0.961 / MFM 1.091 / Ours 0.793）不是池化 Fréchet，而是
`Evaluation/eval_motion_FID.py` 的聚合：

1. **真值分布按 style 建**：`process_gt_distribution.py` 对每个 style 的所有片段取
   **非重叠** 60 帧 clip 的 512 维特征，pooled 成该 style 的 `(mu, sigma)`；
2. **生成侧按文件建**：每个生成文件取其非重叠 60 帧 clip 的特征 Gaussian；
3. **每个文件算一次 Fréchet，再除以特征维度**（代码里的 `fid/len(sigma)`，512），
   最后对该 style/该文件夹的多个文件取平均。

本仓库按同一数法实现（`Utils/motion_eval.py::camdm_style_fid` / `camdm_clip_fid`，
评测脚本默认同时输出，字段 `fid_camdm_style` / `fid_camdm_clip` / `fid_camdm_clip_floor`）：

- 真值 Gaussian：按 style 把**该 style 在测试集里的真值窗口**特征 pooled（与池化 FID 用同一批样本）；
- 预测 Gaussian：`fid_camdm_style` 按 style pooled；`fid_camdm_clip` 按 clip（segment）建，
  对应 CAMDM 的"每个生成文件一次"结构；
- 两者都 **除以特征维度** 后在各组上取平均；
- 本项目的 split 里**每个 style 恰好一个测试 clip**，所以两种分组数值相同（这也是一个自检：
  协议 A/B 下两列应当完全相等）；
- `fid_camdm_clip_floor` = 用真值自己当预测时的取值（每 clip 的 Gaussian vs 该 style 的 pooled
  Gaussian），即"完美预测"下该指标的下限；本项目 split 下是 0。

**Protocol A（CAMDM 提取器，905 窗口，10 个 style）**

| run | FID（池化，论文表格口径） | FID（CAMDM 聚合，/512） |
|---|---|---|
| 论文 MotionVQ（taps=1） | 23.2909 | 0.0633 |
| 100k best（taps=1） | 33.4628 | 0.0902 |
| 100k best（taps=3） | 33.3219 | 0.0899 |
| 150ep best（taps=1） | 22.9302 | 0.0617 |
| **150ep best（taps=3）** | **22.8290** | **0.0616** |

**Protocol B（CAMDM 提取器，~10k 窗口，90 个 style）**

| run | FID（池化） | FID（CAMDM 聚合，/512） |
|---|---|---|
| 论文 MotionVQ（10-style，taps=1） | 127.1140 | 0.5359 |
| 论文 MotionVQ（10-style，taps=3） | 127.0680 | 0.5366 |
| 100k best（taps=1） | 21.1539 | 0.0994 |
| 100k best（taps=3） | 21.0665 | 0.0994 |
| 150ep best（taps=1） | 12.8517 | 0.0793 |
| **150ep best（taps=3）** | **12.8499** | **0.0794** |

两种口径的**排序完全一致**（150ep < 论文行 < 100k；协议 B 上 150ep < 100k），说明池化口径的结论
不是聚合方式造成的。字段写在 `eval_results/camdmfid100_*/motion_eval_summary.json`：
`fid` / `fid_camdm_style` / `fid_camdm_clip` / `fid_camdm_clip_floor`（`--no-fid-camdm-aggregation` 可关）。

⚠️ **不要拿 0.0616 与 CAMDM 论文里的 0.961 直接比**：

- CAMDM 的 0.961 是**完整控制器在 Unity 里跑出来的长序列**（每个 style 一个 rollout 文件，
  经过运行时策略、轨迹跟随等）与**整份 100STYLE 真值分布**之间的距离；
- 我们这里是**教师强制的 AE 重建**（60 帧窗口、考试条件完全给定），天然比运行时 rollout
  贴近真值，所以数值系统性更小；
- 两边真值分布的范围也不同（他们 pool 全部 BVH 文件，我们 pool 测试 split 的窗口）。
  要真正对齐 0.961 需要把我们的模型跑成运行时 rollout 并用全量 BVH 建真值分布 —— 那是另一项工作，
  当前口径的用途是"在我们自己的行之间、以及在 CAMDM 的数法下"比较。

### 3.4 重建目标（reconstruction objective）的提取器

稿子里那句 "we train a feature extractor via a motion **reconstruction** objective" 与 CAMDM 的
代码不符（他们训的是分类器，仓库里 `reconstruct` 一次都没出现）。若要让这句话成立，提取器就得
按重建目标训。本仓库已实现该变体：

**训练方法**（`train_fid_feature_extractor_recon.py` + `run_train_fid_feature_extractor_recon.sh`）

| 项 | 取值 | 与分类版的差别 |
|---|---|---|
| 输入 | 60 帧 × 15 个 ybot 关节局部位置（45 维），`clip_offset=10` | 相同 |
| 主干 | CAMDM 同款 conv 栈（conv1 64 / conv2 128 + 1×1 残差 + BN + LeakyReLU + dropout 0.5） | 相同 |
| 编码头 | FC(128·60→1024)+BN → **FC(1024→512)+BN = FID 特征** | 相同（512 维） |
| 新的解码头 | FC(512→1024) → FC(1024→128·60) → reshape → 3 层 Conv1d(128→128→64→45) → 重建窗口 | **替换掉 fc3(512→num_styles)** |
| 损失 | `L1(recon, x)`（可选 `--vel-weight` 加时序差分项，默认 0） | 由交叉熵换成重建误差 |
| 数据/协议 | 全 100 style、全部 clip 为训练集、无划分；Adam 1e-3、batch 1024、50 epoch | 相同 |
| 监督信号 | **不使用风格标签** | 不使用标签 |
| 产物 | `checkpoints/fid_feature_extractor_recon100/100style_position_recon.pth`（`objective="reconstruction"`、`feat_dim=512`、`joint_set=ybot15`） | 加载器按 `objective` 字段自动分发（`build_fid_feature_extractor_from_checkpoint`），评测链路不变 |

训练结果：50 epoch，训练集 L1 = **0.00605 m**；在未参与训练的 128 个窗口上逐坐标 L1 = **0.00575 m**
（≈ 0.57 cm/关节坐标）——即 512 维瓶颈确实在承载动作内容，而不是近似无损地照抄（否则 FID 会被
无意义的微小残差主导）。

**Protocol A（重建版提取器，905 窗口，10 个 style）**

| run | FID（池化） | FID（CAMDM 聚合，/512） | MPJPE | F.S. | Jitter |
|---|---|---|---|---|---|
| 论文 MotionVQ（taps=1） | 1.1910 | 0.0050 | 3.6534 | 0.2772 | 0.2519 |
| 100k best（taps=1） | 1.6363 | 0.0064 | 1.8086 | 0.2918 | 0.2544 |
| 100k best（taps=3） | 1.6450 | 0.0064 | 1.8081 | 0.2812 | 0.2271 |
| 150ep best（taps=1） | 1.1293 | 0.0049 | 1.3240 | 0.2810 | 0.2702 |
| **150ep best（taps=3）** | **1.1430** | **0.0050** | **1.3230** | **0.2659** | **0.2292** |

**Protocol B（重建版提取器，~10k 窗口，90 个 style）**

| run | FID（池化） | FID（CAMDM 聚合，/512） |
|---|---|---|
| 论文 MotionVQ（10-style，taps=1） | 8.1276 | 0.0485 |
| 论文 MotionVQ（10-style，taps=3） | 8.1712 | 0.0486 |
| 100k best（taps=1） | 0.6259 | 0.0061 |
| 100k best（taps=3） | 0.6375 | 0.0061 |
| 150ep best（taps=1） | 0.4043 | 0.0056 |
| **150ep best（taps=3）** | **0.4178** | **0.0056** |

协议 B 上重建口径给出 **150ep 0.404 / 100k 0.626 vs 论文行 8.128**（20× / 13×），
与分类器口径的 12.85 vs 127.11（10×）方向一致：**Protocol A 的"接近平手"是 905 窗口小样本 +
10 个 style 的效应，不是真实差距。**

**三种口径的横向对照（FID 一列，taps=3）**

| run | CAMDM 分类器（主口径） | 本项目 72 维分类器 | 重建目标（本节） |
|---|---|---|---|
| Protocol A 论文 MotionVQ | 23.2909 | 17.1750 | 1.1915 |
| Protocol A 100k best | 33.3219 | 22.7413 | 1.6452 |
| Protocol A 150ep best | 22.8290 | 15.7717 | 1.1434 |
| Protocol B 论文 MotionVQ | 127.0680 | 113.2580 | 8.1712 |
| Protocol B 100k best | 21.0665 | 11.4582 | 0.6375 |
| Protocol B 150ep best | 12.8499 | 9.2169 | 0.4178 |

三种特征空间给出**同一排序**（150ep < 100k，且都优于论文行）：

- Protocol A（905 窗口）上 150ep 相对论文行的优势很小（分类器 +2.0%、重建 +4.0%，CI 重叠），
  Protocol B（~10k 窗口）上才拉开：分类器 10×、重建 20×。
  → **小样本下 FID 的"接近平手"不要当作结论**，报告时应以 Protocol B 或明确标注窗口数为准。
- 重建口径的数值整体小两个量级（1.1 vs 23），因为自编码器特征被优化成紧凑地承载动作内容；
  这与 CAMDM 报的 0.961 属于同一量级纯属巧合，两者特征空间不同，不可互引。

**该选哪条路？**

- **要与 CAMDM 的数字/实现对齐** → 用分类器版（`fid_feature_extractor_camdm100`），并把稿子那句
  "reconstruction objective" 改掉（`PAPER_TEXT_AMENDMENTS.md` 第 7 条已备好文案）。R2 定稿里
  写的是 "FID uses the feature extractor from the CAMDM implementation"，与代码一致。
- **要保住稿子那句 reconstruction 表述** → 用本节的重建版（同样 100 style/全量训练/512 维特征），
  但必须同时说明：FID 定义在**自编码器特征空间**里，与 CAMDM 报告的数字不同量纲，不能互相引用。
- 不建议两种提取器的数值混用在一张表里；三套口径的同一排序可以作为稳健性证据（"结论与提取器无关"），
  这在 response letter 里反而是个加分点。

### 3.5 备份口径：本项目 72 维提取器（24 关节）的同样两张表

口径切换只影响 FID 一列（其余 6 个指标是几何量，与提取器无关）。


#### Protocol A（备份提取器）

| run | MPJPE (cm) | RootADE (cm) | Heading (deg) | VelDir (deg) | FID | F.S. (cm) | Jitter (cm) |
|---|---|---|---|---|---|---|---|
| 论文 MotionVQ（taps=1） | 3.6534 | 2.8399 | 3.0238 | 3.9225 | 17.1750 | 0.2772 | 0.2519 |
| 100k best（taps=1） | 1.8086 | 0.8756 | 0.2813 | 0.6419 | 22.7788 | 0.2918 | 0.2544 |
| 100k best（taps=3） | 1.8081 | 0.8766 | 0.2833 | 0.6764 | 22.7413 | 0.2812 | 0.2271 |
| 150ep best（taps=1） | 1.3240 | 0.3892 | 0.2531 | 0.4084 | 15.7857 | 0.2810 | 0.2702 |
| **150ep best（taps=3）** | **1.3230** | **0.3897** | **0.2584** | **0.4581** | **15.7717** | **0.2659** | **0.2292** |

与论文行逐项比较（✓ = 优于论文点估计）：

| run | MPJPE | RootADE | Heading | VelDir | FID | F.S. | Jitter | 合计 |
|---|---|---|---|---|---|---|---|---|
| 100k best（taps=1） | ✓ 2.0× | ✓ 3.2× | ✓ 10.8× | ✓ 6.1× | ✗ 1.33× 差 | ✗ +5.3% | ✗ +1.0% | 4/7 |
| 100k best（taps=3） | ✓ 2.0× | ✓ 3.2× | ✓ 10.7× | ✓ 5.8× | ✗ | ✗ +1.4% | ✓ 0.227 | 5/7 |
| 150ep best（taps=1） | ✓ 2.8× | ✓ 7.3× | ✓ 11.9× | ✓ 9.6× | ✓ 1.09× | ✗ +1.4% | ✗ +7.3% | 5/7 |
| 150ep best（taps=3） | ✓ 2.8× | ✓ 7.3× | ✓ 11.7× | ✓ 8.6× | ✓ 1.09× | ✓ 0.266 | ✓ 0.229 | **7/7** |

（完整 CI 见 `eval_results/paper_parity_*/motion_eval_summary.json`。）

说明：Protocol A 只有 905 个窗口，FID 的 bootstrap CI 约 ±1.1（±6%），所以 150ep 的
FID 优势（15.77 vs 17.18）只是"同向、不过 CI"的量级；F.S. 的 CI 是 ±0.026 / ±0.024，
raw 档的 0.2810 vs 0.2772 在 CI 内重叠，滤波后 0.2659 才稳定低于论文。
Protocol B 的 ~10k 窗口上结论更稳（FID 9.2 vs 113.3，F.S. 0.2784 vs 0.2777 持平，
jitter 0.2155 vs 0.2323 更优）。

#### Protocol B（备份提取器）

| run | MPJPE (cm) | RootADE (cm) | Heading (deg) | VelDir (deg) | FID | F.S. (cm) | Jitter (cm) |
|---|---|---|---|---|---|---|---|
| 论文 MotionVQ（10-style，taps=1） | 6.1669 | 3.9944 | 4.3227 | 6.0520 | 113.2888 | 0.2885 | 0.2706 |
| 论文 MotionVQ（10-style，taps=3） | 6.1641 | 3.9942 | 4.3228 | 6.0445 | 113.2580 | 0.2777 | 0.2323 |
| 100k best（taps=1） | 1.5049 | 0.5617 | 0.2561 | 0.6400 | 11.4480 | 0.2907 | 0.2359 |
| 100k best（taps=3） | 1.5018 | 0.5608 | 0.2590 | 0.6834 | **11.4582** | **0.2778** | **0.2084** |
| 150ep best（taps=1） | 1.3644 | 0.3917 | 0.2844 | 0.4821 | 9.1799 | 0.2983 | 0.2621 |
| **150ep best（taps=3）** | **1.3616** | **0.3922** | **0.2889** | **0.5467** | **9.2169** | **0.2784** | **0.2155** |

Protocol B 的要点：

- 论文 checkpoint 是 **10-style 模型**，在 90 个风格的测试集上 FID 从 17.2 涨到 113.3
  （6.6×），MPJPE 从 3.65 涨到 6.17（1.7×）——FID 对"没见过风格"远比几何指标敏感，
  这也是"提取器必须见过全部风格"的同一个道理。
- 因此 Protocol B **不作为竞争力对比**，只作为"我们的模型在更宽测试集上的自证"，
  以及"论文行是 10-style 模型"的直接证据。
- 去镜像后，几何类指标比带镜像的 90-style 测试集（[RUN_150EP_RESULTS.md](docs/archive/RUN_150EP_RESULTS.md)）更好：
  150ep best 从 MPJPE 1.4170 / F.S. 0.2972 / Jitter 0.2775 变为
  1.3644 / 0.2983 / 0.2621（jitter 明显改善，F.S. 基本不变）。
- 3-tap 解码滤波把 F.S. 从 0.2983 → 0.2784、jitter 0.2621 → 0.2155，
  MPJPE/rootADE 几乎不动（1.3644 → 1.3616 / 0.3917 → 0.3922）。

---

## 4. 结论与后续

1. **FID 提取器已与 CAMDM 官方实现对齐、并在完整 100 style 上全量训练**（§1.5）：
   主口径 `checkpoints/fid_feature_extractor_camdm100/100style_position_classifier.pth`
   （45 维 ybot15、100 个风格、391,373 个窗口、无划分、训练准确率 99.90%），
   另有镜像版 `..._camdm100_mirror/`。备份口径
   `checkpoints/fid_feature_extractor_full100_v4/best.pt`（本项目 24 关节 / 72 维）仅作交叉验证。
   旧的 `*_head10` 提取器**不能再用于 90-style 库的 FID**。
2. **论文行已被逐位复现**（§2）；论文行是 10-style、无镜像、905 窗口。
3. **同口径下**（Protocol A，同一提取器、同一测试集）**150ep best + 3-tap 解码滤波 7/7
   全面优于论文点估计**——CAMDM 提取器下：MPJPE 2.8×、rootADE 7.3×、heading 11.7×、
   velDir 8.6×、FID 22.83 vs 23.29、F.S. 0.266 vs 0.277、jitter 0.229 vs 0.252；
   72 维备份提取器下结论相同（FID 15.77 vs 17.18）。raw（taps=1）档 5/7
   （F.S. 高 1.4%、CI 内重叠；jitter 高 7.3%）。
4. **两套提取器给出一致排序**：150ep 的 FID 优于论文行，100k best 反而比论文差
   （CAMDM 提取器：33.5 vs 23.3；备份：22.8 vs 17.2）——905 个样本 × 512 维的 FID 统计很脆弱，
   Protocol B（~10k 窗口）上 100k 的 21.2 也仍不及 150ep 的 12.9。
   说明**选检查点不能只看精度类指标**——这正是 100k run 把 jitter/F.S. 写进 best 门禁的初衷。
5. 写作时必须注明的四条口径：
   - 论文行 = **10 style + 无镜像 + 905 窗口**；镜像增强是 v4 新增的，论文期权重在镜像数据上
     会崩（§2.1），因此任何"论文权重 vs 新权重"的对比都必须在**无镜像**测试集上做。
   - FID 依赖提取器，跨提取器不可比；必须同提取器、同测试集（本文档因此分两套表）。
   - CAMDM 提取器训练数据里没有镜像，故它只适用于无镜像测试集；要用在带镜像的库上请换
     `..._camdm100_mirror/`。
   - 3-tap 滤波属于"带时序解码器的表征"，要与 raw 档并列报告。
6. 若要与 CAMDM 的**数值**直接对比（他们论文里的 0.961 等），还需要复刻他们的 FID 聚合方式
   （逐 style 分组、非重叠 60 帧 clip、除以特征维度），这与本项目评测脚本的池化 FID 不是同一个量；
   当前表格服务于"我们 vs 论文表格"的同口径对比，未做该聚合。
