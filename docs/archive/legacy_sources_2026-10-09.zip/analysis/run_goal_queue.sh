#!/usr/bin/env bash
# Goal queue (matched >= 85, cross >= 80): runs after the running decouple sweep finishes.
#   1) lambda_prior 0.05 control (already queued as "E" earlier, kept here for one clean chain)
#   2) F: retarget-latent decoupling p=0.5, 50 epochs   (trajectory-preserving style transfer)
#   3) G: retarget p=0.5 + stronger conditioning noise, 50 epochs
# Each: train -> generalization eval (h=60) so numbers are directly comparable.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-}"
if [[ -z "${PY}" ]]; then
  if [[ -x /home/shinn/miniforge3/envs/mcc/bin/python ]]; then PY=/home/shinn/miniforge3/envs/mcc/bin/python; else PY=python; fi
fi
VQ="${ROOT}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt"
CACHE="${ROOT}/cache/vq_targets_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep"
PRIOR="${ROOT}/cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz"

run() {
  local tag="$1"; shift
  local out="${ROOT}/checkpoints/flowmatch_vqvae_controller_${tag}"
  local log="/tmp/goal_${tag}.log"
  echo "=============================================================="; echo "[Run] ${tag}"
  PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
    VQ_CKPT="${VQ}" VQ_TARGET_CACHE="${CACHE}" STYLE_CODE_PRIOR="${PRIOR}" \
    STYLE_PRIOR_LOSS=dense STYLE_ENTROPY_WEIGHT=0.02 OUT="${out}" \
    setsid "${ROOT}/run_train_flowmatch_vqvae_controller.sh" "$@" > "${log}" 2>&1
  echo "[Done] training ${tag}"
  PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
    FLOW_CKPT="${out}/best.pt" OUT="${ROOT}/eval_results/gen_${tag}" \
    setsid "${ROOT}/run_evaluate_minor_revision_generalization.sh" --horizons 60 \
    > "/tmp/goal_eval_${tag}.log" 2>&1
  "$PY" - "${ROOT}" "${tag}" <<'PY'
import json, sys
root, tag = sys.argv[1], sys.argv[2]
d = json.load(open(f"{root}/eval_results/gen_{tag}/minor_revision_generalization_summary.json"))
for r in d["summaries"]:
    ra = r["root_ade_cm"]
    print(f"  {tag:22s} {r['setting']:32s} acc={float(r['target_style_acc_pct']):6.2f}  rootADE={float(ra) if ra==ra else float('nan'):7.3f}")
PY
}

# Screening round (25 epochs each, ~2 h per run): which retarget configuration scales best?
run "retarget_p05_s25" --epochs 25 --save-every 25 --decouple-prob 0.5 --decouple-latent retarget
run "retarget_p07_s25" --epochs 25 --save-every 25 --decouple-prob 0.7 --decouple-latent retarget
run "retarget_p05_noise06_s25" --epochs 25 --save-every 25 --decouple-prob 0.5 --decouple-latent retarget \
  --prev-latent-noise-std 0.6 --prev-motion-noise-std 0.6
# Long run on the screening winner is launched separately after reading the table above.
echo "[Done] goal queue complete"
