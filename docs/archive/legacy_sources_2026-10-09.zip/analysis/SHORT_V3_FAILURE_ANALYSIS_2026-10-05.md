# 5-epoch v3 短训练失败分析与恢复入口

本次分析 `checkpoints/flowmatch_style_v3_short/A/best.pt`（epoch5）。另有 `flowmatch_style_v3_20ep/A` 在运行；没有中断、修改其checkpoint或启动新的真实训练。新诊断只用validation、CPU、FP32，既有test报告仅作为用户已有结果记录，不用test选择新配置。

结论：目前最大的已测差距在闭环反馈。单步目标及style prior拟合已有较好结果，但A只在GT previous-motion/latent上训练，没有自回归展开或cross-style目标支持。增加A训练时长不能直接验证这两类问题是否解决。修订提供从已有权重进入展开微调的独立入口，保留网络、损失种类、固定VQ和FP32。

## 已有训练与报告事实

A使用seq_len2/unroll1、decouple=0、recon=.1、prior=.02、entropy=.003、raw prototype、prior初始化、target/normalized、Euler8、batch512。每epoch约5,712,896训练样本；5个完整epoch，cosine horizon也是5。LR从5e-4到第5epoch结束后的1e-5；这是一轮完整的短cosine训练，不是原50-epoch schedule的前5epoch。

train flow loss从.0801降到.0308，val flow从.0768到.0474；train/val prior KL约.0275/.0276，top-1约.583，selector entropy约1.072。它们不支持“prior没学会/近似单码塌缩”的解释。CE约4.838包含target entropy约4.810；乘.02后的约.096常数下界不能作为梯度支配证据。

全validation的270个60帧窗口：MPJPE11.823cm、local jitter1.858cm、matched accuracy20.74%、cross accuracy0.93%，Root ADE3.899/4.334cm。已有test报告matched18.60%、cross1.40%，GT reference96.40%。`constraints_passed=true`只表示既定ADE gate通过，不表示论文联合验收通过；此checkpoint的J≈16.94。

## 分路径诊断

固定seed42，从32个未镜像、独立原始validation clips各取一个60帧窗口。同一case在controller各路径及label干预中使用同一Gaussian noise；不做decode smoothing。结果是小规模诊断，没有bootstrap CI，不代替完整验证/论文报告。

| 路径 | MPJPE cm | Root ADE cm | Local jitter cm | Source style accuracy |
|---|---:|---:|---:|---:|
| Real motion | ≈0 | ≈0 | .196 | 90.63% |
| Continuous AE | 1.262 | .333 | .238 | 90.63% |
| Quantized AE | 1.280 | .262 | .589 | 90.63% |
| Teacher-forced continuous | 1.572 | .735 | .710 | 90.63% |
| Teacher-forced quantized | 1.594 | .705 | .956 | 90.63% |
| Rollout continuous | 14.097 | 5.580 | 2.455 | 6.25% |
| Rollout quantized | 12.281 | 4.353 | 1.903 | 18.75% |

Quantized rollout累计MPJPE在10/20/40/60帧为2.379/4.669/8.966/12.281cm；teacher-forced对应1.150/1.266/1.396/1.594cm。反馈误差快速累积是当前证据最强的解释。

改变请求label、保留同一source/noise后，两条rollout的平均joint-position距离约10.75cm。style token的均值norm约.676、中心化norm约1.139。这说明模型响应label且token存在变化，不能把低accuracy直接解释成token完全被忽略；也没有证明响应具有正确的cross-style语义。

量化AE已经比continuous AE增加明显jitter，但保留了同一style accuracy。量化是jitter的一个来源，却不能解释teacher-forced→rollout的巨大accuracy下降。当前continuous rollout更差，恢复入口保留quantized主反馈；两条路径继续独立记录。固定VQ下的剩余量化噪声仍未解决，不宣称联合指标必然可达。

原始诊断：[32源JSON](short_v3_diagnosis_val32.json)、[8源初始诊断](short_v3_diagnosis_val8.json)。`accuracy`明确按source label计算；wrong-label路径额外记录`requested_accuracy`，不能把source accuracy当成cross目标accuracy。

## 实施的改进

1. **直接继承已训练权重进入展开。** 新`analysis/run_rollout_recovery.py`默认只打印一个命令，使用给定compatible target checkpoint和其DB/VQ/norm/cache/prior/架构设置。默认seq_len5/unroll4、lr1e-4、最多5epoch；每epoch固定rollout validation。没有新增网络、损失或classifier优化。原A/B/C入口保留。
2. **固定VQ解码的GT前状态增强。** `--train-feedback-context`在训练窗口起点用`D(q_GT_prev)`作为observed previous motion，previous latent仍为对应`q_GT_prev`。后续展开依旧使用自身预测、detach反馈。GT trajectory、recon target、target latent和matched_root donor构造保持原语义；decoder全部冻结。这让一部分训练条件接近实际rendered feedback分布，是需要实验验证的条件增强，默认trainer关闭，恢复入口显式开启；`--no-feedback-context`生成仅展开的对照命令。
3. **停止epoch与cosine horizon分开。** `--lr-schedule-epochs 50`允许5epoch短运行保留50epoch退火周期，不在第5epoch把lr压到min。默认0继续按`--epochs`，原训练行为保持。scheduler horizon纳入严格resume；不能直接把旧短run原地改为新schedule。
4. **cross独立阶段。** 恢复入口默认decouple0，先确认matched闭环是否恢复。显式`--cross`启用既有matched_root .3/root L1 .1，从恢复后的validation best初始化。A从未接触source A+target B组合；prior regularizer不是cross监督的替代。

反馈增强记录training_objective_version4；旧v3通过`--init-ckpt`只继承权重，重置optimizer/scheduler/RNG。旧模型仍可读，默认训练继续原GT条件路径；旧状态不能在不同feedback flag/horizon下直接resume。全程FP32/highest/TF32=False，VQ及classifier冻结，style consistency=0、recipe训练增强=0。

## 手动使用与验收

```bash
cd /home/shinn/桌面/multimedia/revision/NewCode
conda activate mcc

# 只打印恢复命令，没有训练副作用
python analysis/run_rollout_recovery.py \
  --init-ckpt checkpoints/flowmatch_style_v3_short/A/best.pt

# 由使用者显式执行，最多5epoch，独立目录/B
python analysis/run_rollout_recovery.py \
  --init-ckpt checkpoints/flowmatch_style_v3_short/A/best.pt --execute

# matched稳定后才启用既有cross监督；独立目录/C
python analysis/run_rollout_recovery.py \
  --init-ckpt checkpoints/flowmatch_rollout_recovery/B/best.pt --cross
```

最后一条同样只打印，实际运行需`--execute`。可用2/4/8步、microbatch512/256/128，但不自动sweep、降batch或加epoch。4步的实际GPU显存/速度尚未测量，不能引用先前2步性能探针作承诺。5epoch恢复不是效果保证，也不自动追加到完整150epoch计划；使用者需计入自己的总训练预算。

检查每epoch相同validation cases的rollout MPJPE/jitter/accuracy和ADE，特别是10→60帧误差增长是否减缓；不要仅看teacher-forced loss。确认matched闭环改善后，单独检查cross accuracy、actual decoupled fraction和root约束。没有改善则先比较仅展开与反馈增强的差异，不继续盲目追加A epoch或提高prior权重。

新增回归覆盖真实tiny-DB CLI的4步训练、slow cosine prefix、GT监督保留、input/target不串改、VQ权重/梯度不变、validation保留GT条件以及同配置epoch resume数值一致。全套轻量测试：164 passed、2 CUDA tests skipped、5 subtests passed（10.88秒）。本次未做GPU smoke或真实恢复训练；效果改进尚未验收。
