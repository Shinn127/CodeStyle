"""Final verification table: our metrics vs the paper's MotionVQ numbers.

Sources (all on the paper's exact test protocol: 90-style test split, 60-frame windows,
stride 30 = 19,988 windows, shared metric code):
  * official eval summary  -> raw AE-path CIs (FID/heading/vel-dir/rootADE too)
  * full_compare_100k_6metric.json -> raw / 3-tap / 5-tap AE-path six metrics on the full set
  * fid_filtered_100k.json -> FID for raw and 3-tap
"""

from __future__ import annotations

import json
from pathlib import Path

NEWCODE = Path(__file__).resolve().parents[1]
PAPER = {
    "MPJPE (cm)": 3.653,
    "FID": 3.060,
    "F.S. (cm)": 0.277,
    "Jitter (cm)": 0.252,
    "rootADE (cm)": 2.840,
    "Heading (deg)": 3.024,
    "Vel dir (deg)": 3.923,
}
FLOOR = {"Jitter (cm)": 0.2014, "F.S. (cm)": 0.2134}


def main() -> None:
    official = json.loads((NEWCODE / "eval_results/vqvae_100k_root3/motion_eval_summary.json").read_text())[
        "results"
    ][0]
    six = json.loads(Path("/tmp/full_compare_100k_6metric.json").read_text())["summary"]
    fid = json.loads(Path("/tmp/fid_filtered_100k.json").read_text())

    rows = {
        "raw (paper protocol)": {
            "MPJPE (cm)": (official["mpjpe_cm"], official["mpjpe_cm_ci95"]),
            "FID": (fid["raw"], fid["raw_ci95"]),
            "F.S. (cm)": (official["foot_sliding_cm"], official["foot_sliding_cm_ci95"]),
            "Jitter (cm)": (official["jitteriness_cm"], official["jitteriness_cm_ci95"]),
            "rootADE (cm)": (official["root_ade_cm"], official["root_ade_cm_ci95"]),
            "Heading (deg)": (official["heading_error_deg"], official["heading_error_deg_ci95"]),
            "Vel dir (deg)": (official["velocity_dir_error_deg"], official["velocity_dir_error_deg_ci95"]),
        },
        "+ 3-tap filter": {
            "MPJPE (cm)": (six["ae_smooth3"]["mpjpe"], six["ae_smooth3"]["mpjpe_ci95"]),
            "FID": (fid["filt"], fid["filt_ci95"]),
            "F.S. (cm)": (six["ae_smooth3"]["foot"], six["ae_smooth3"]["foot_ci95"]),
            "Jitter (cm)": (six["ae_smooth3"]["jitter"], six["ae_smooth3"]["jitter_ci95"]),
            "rootADE (cm)": (six["ae_smooth3"]["root_ade"], six["ae_smooth3"]["root_ade_ci95"]),
            "Heading (deg)": (six["ae_smooth3"]["heading"], six["ae_smooth3"]["heading_ci95"]),
            "Vel dir (deg)": (six["ae_smooth3"]["vel_dir"], six["ae_smooth3"]["vel_dir_ci95"]),
        },
        "+ 5-tap filter": {
            "MPJPE (cm)": (six["ae_smooth5"]["mpjpe"], six["ae_smooth5"]["mpjpe_ci95"]),
            "FID": (float("nan"), float("nan")),  # not measured; see filtered-FID script
            "F.S. (cm)": (six["ae_smooth5"]["foot"], six["ae_smooth5"]["foot_ci95"]),
            "Jitter (cm)": (six["ae_smooth5"]["jitter"], six["ae_smooth5"]["jitter_ci95"]),
            "rootADE (cm)": (six["ae_smooth5"]["root_ade"], six["ae_smooth5"]["root_ade_ci95"]),
            "Heading (deg)": (six["ae_smooth5"]["heading"], six["ae_smooth5"]["heading_ci95"]),
            "Vel dir (deg)": (six["ae_smooth5"]["vel_dir"], six["ae_smooth5"]["vel_dir_ci95"]),
        },
    }

    header = f"{'metric':14s} {'paper':>9s} " + " ".join(f"{k:>22s}" for k in rows)
    print(header)
    print("-" * len(header))
    verdicts = {k: [] for k in rows}
    for metric, paper_value in PAPER.items():
        cells = []
        for name, values in rows.items():
            value, ci = values[metric]
            if value != value:  # nan
                cells.append(f"{'n/a':>22s}")
                verdicts[name].append(f"{metric}: n/a")
                continue
            ok = value < paper_value
            verdicts[name].append(f"{metric}: {'PASS' if ok else 'FAIL'}")
            cells.append(f"{value:10.4f}±{ci:5.4f} {'OK' if ok else 'NO'}")
        floor = FLOOR.get(metric)
        floor_text = f" (floor {floor})" if floor else ""
        print(f"{metric:14s} {paper_value:9.3f} " + " ".join(f"{c:>22s}" for c in cells) + floor_text)

    print()
    for name in rows:
        passed = verdicts[name]
        n_ok = sum(1 for v in passed if v.endswith("PASS"))
        total = sum(1 for v in passed if not v.endswith("n/a"))
        print(f"{name:22s} {n_ok}/{total} metrics better than the paper")
        for v in passed:
            if v.endswith("FAIL"):
                print(f"    FAILED: {v}")


if __name__ == "__main__":
    main()
