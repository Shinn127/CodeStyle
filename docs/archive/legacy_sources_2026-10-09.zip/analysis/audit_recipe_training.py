"""CPU-only recipe construction timing and one disposable real-model gradient/update check."""
from pathlib import Path
import json
import sys
import time

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Utils.motion_eval import load_motion_model
from Utils.runtime import load_norm_stats, configure_torch_runtime
from Utils.style_code_prior import TrainStyleRecipePool
from Utils.vq_target_cache import VQTargetCache
from Utils.reproducibility import state_fingerprint, file_sha256
from dataset import norm_stats_fingerprint


def main():
    torch.set_num_threads(2)
    configure_torch_runtime(device=torch.device('cpu'), tf32=False,
        cudnn_benchmark=False, matmul_precision='highest')
    torch.manual_seed(42)
    path = ROOT/'checkpoints/flowmatch_tf150_staged_noise/best.pt'
    model = load_motion_model(model_name='flowmatch_target', ckpt_path=path, num_styles=90)
    model.conditioning_mode = 'recipe'
    model.style_selector.style_embedding.requires_grad_(False)
    model.style_selector.to_logits.requires_grad_(False)
    norm = ROOT/'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/norm_stats.npz'
    mean, std = load_norm_stats(norm)
    assert norm_stats_fingerprint(mean,std) == model.eval_fingerprints['norm_fingerprint']
    cache = VQTargetCache(ROOT/'cache/vq_targets_vq150ep_repair_v2')
    cache.validate(fingerprints=model.eval_fingerprints, vqvae=model.vqvae)
    db = ROOT/'database_100sty_375_memmap'
    segments = json.loads((db/'segments.json').read_text())
    train = [s for s in segments if s['split']=='train' and not s.get('mirror')]
    rng = np.random.default_rng(42)
    rows = [train[i] for i in rng.integers(len(train),size=512)]
    labels = torch.tensor([r['label'] for r in rows])
    kwargs = dict(probability=1., per_sample_exclusions=[{r['source_entry_id']} for r in rows], require_all=True)
    times = {}
    bank = None
    for size in (0,64):
        pool = TrainStyleRecipePool(db=db,model=model,cache=cache,mean=mean,std=std,
            frames=240,exemplar_choices=[1,3,5],bank_size=size,seed=42)
        passes = []
        for _ in range(2):
            durations, hits = [], []
            for seed in range(100,105):
                torch.manual_seed(seed)
                begin = time.perf_counter()
                probs,fraction = pool.sample(labels,**kwargs)
                durations.append(time.perf_counter()-begin)
                hits.append(pool.last_sample_stats['bank_hit_fraction'])
                assert fraction==1 and pool.last_sample_stats['shortfall_fraction']==0
            passes.append(dict(seconds=durations,median_sec=float(np.median(durations)),hit_fractions=hits))
        times[str(size)] = dict(first_pass=passes[0],replayed_pass=passes[1],cached_variants=len(pool.bank))
        if size: bank = pool
    torch.manual_seed(104)
    probs,_ = bank.sample(labels,**kwargs)
    meta = json.loads((db/'meta.json').read_text())
    raw = np.memmap(db/'X.f32',mode='r',dtype=np.float32,shape=(meta['num_frames'],375))
    starts = [int(row['frame_start'])+1 for row in rows[:2]]
    x = torch.from_numpy((np.stack([raw[start:start+2] for start in starts])-mean)/std)
    frame_ids = torch.tensor([[start,start+1] for start in starts])
    latents = cache.lookup_latents(frame_ids.flatten(),vqvae=model.vqvae,device=torch.device('cpu')).reshape(2,2,-1)
    before_vq = state_fingerprint(model.vqvae.state_dict())
    before_selector = state_fingerprint(model.style_selector.to_logits.state_dict())
    before_projection = model.style_selector.proto_to_style[0].weight.detach().clone()
    before_field = model.field.out.weight.detach().clone()
    def forbidden(*args, **kwargs):
        raise AssertionError('Cached pure-recipe FM used a label, online encoder, decoder, or Euler path')
    model.style_selector.style_embedding.forward = forbidden
    model.style_selector.to_logits.forward = forbidden
    model.frame_latent = forbidden
    model.vqvae.decode = forbidden
    model._integrate = forbidden
    model.train()
    torch.manual_seed(42)
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params,lr=1e-4,weight_decay=1e-4)
    result = model.compute_loss(x_curr=x[:,0],x_next=x[:,1],style_label=None,
        manual_style_probs=probs[:2],prev_latent=latents[:,0],target_latent=latents[:,1])
    result['loss'].backward()
    def norm(parameters):
        return float(torch.stack([p.grad.square().sum() for p in parameters if p.grad is not None]).sum().sqrt())
    gradients = dict(flow=norm(model.field.parameters()),projection=norm(model.style_selector.proto_to_style.parameters()))
    assert all(value>0 and np.isfinite(value) for value in gradients.values())
    assert all(p.grad is None for p in model.vqvae.parameters())
    assert all(p.dtype==torch.float32 for p in params)
    torch.nn.utils.clip_grad_norm_(params,1.,error_if_nonfinite=True)
    optimizer.step()
    assert before_vq==state_fingerprint(model.vqvae.state_dict())
    assert before_selector==state_fingerprint(model.style_selector.to_logits.state_dict())
    assert not torch.equal(before_projection,model.style_selector.proto_to_style[0].weight)
    assert not torch.equal(before_field,model.field.out.weight)
    report = dict(device='cpu',seed=42,threads=2,checkpoint_sha256=file_sha256(path),
        vq_unchanged=True,unused_selector_unchanged=True,precision='FP32/highest/TF32=False',
        real_model_batch=2,disposable_optimizer_updates=1,latent_shape=list(latents.shape),
        recipe_shape=list(probs.shape),gradient_norms=gradients,loss=float(result['loss'].detach()),
        decoder_or_euler_calls=0,label_condition_calls=0,source_ids=[r['source_entry_id'] for r in rows[:2]],
        recipe_cpu_timing=times,
        limits='CPU construction timing uses 512 sampled original train clips. Warm timings replay fixed inputs; not GPU epoch throughput. No checkpoint is saved, no rollout or style accuracy evaluation.')
    output = ROOT/'analysis/recipe_training_audit_2026-10-06.json'
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
