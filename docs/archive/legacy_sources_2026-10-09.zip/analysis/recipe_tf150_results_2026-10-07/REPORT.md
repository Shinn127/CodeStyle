# Recipe / clip TF150 训练结果分析

分析日期：2026-10-07。完整评估使用 epoch_0150.pt；核对了训练配置、150 个 epoch 的日志、验证快照、test/OOD 逐样本结果及 checkpoint 内容指纹。本轮只做结果分析和小规模 CPU FP32 诊断，没有追加训练或 autoregressive rollout，也没有修改训练实现。

后续方案推导见 [Clip / recipe 重新推导](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/CLIP_RECIPE_REDERIVATION.md)。该文保留本报告的实验事实，但修订了建议优先级：TopK 质量和 oracle history 不能作为充分因果证据；output-distribution KL、额外维持任务和非线性码本聚合不再作为默认第一步。

## 1. 结论与评估边界

**150 epoch 已完成；teacher-forced matched 达标，cross 未达标，unseen recipe 泛化基本失效。** 未发现 recipe 输入遗漏或 OOD 标签映射错误；训练曲线也不足以支持“只需继续加 epoch”的判断。下面的诊断把主要疑点定位到跨风格条件的有效性、训练配对覆盖，以及 recipe 将分布压缩为低维均值所丢失的信息。

| epoch150 test | cases | Style accuracy | 按 source clip 聚类的 95% CI | Root ADE，4 秒 |
|---|---:|---:|---:|---:|
| Matched recipe | 1,000 | 98.60% | 97.23–99.52% | 4.139 cm |
| Cross recipe | 5,000 | 50.40% | 48.62–52.12% | 9.500 cm |
| Unseen recipe | 5,000 | 0.16% | 0.057–0.288% | 7.824 cm |

用户目标是 matched ≥85%、cross ≥80%、unseen 接近 cross。因此 matched 满足当前 TF 指标，cross 还差 29.60 个百分点，OOD 不能作为可用能力交付。

这里均为 **60fps、240 个生成帧、teacher-forced**：每帧输入 source 的真实历史 motion/latent，使用 Euler 8 steps、noise std=1、clip→re-quantize→decode。不是生成状态反馈的 rollout。当前 matched 的高分不能证明 rollout 稳定，也不能单独证明模型能够靠 recipe 引入新风格，因为 matched 历史本身已经包含目标风格。

OOD 指 generator 没训练过的 10 个风格；报告分类器包含全部 100 类，使用 CAMDM all-clips 训练口径。真实 seen motion 准确率 99.9%，31 个独立 OOD reference 准确率 100%，所以不能把 OOD 0.16% 归因于分类器不包含这些类别。但这些数字不是分类器自身 held-out 泛化评测。

本次没有新的 MPJPE、Jitter、foot skating、FID 或长序列 rollout 结果，不能宣称论文联合指标复现成功。4 秒 ADE 也不能直接与历史 60 帧的 ADE 阈值比较。

## 2. 训练是否正常，以及继续加 epoch 的价值

实际训练从头开始，纯 recipe conditioning 100%，没有 label fallback；1/3/5 个独立 240 帧 exemplar，bank size=64。batch/microbatch 都为 512，stride=1、seq_len=2、unroll=1；target prediction、normalized latent MSE；reconstruction/root/prior/entropy/classifier loss 均为 0。VQ 冻结、FP32/highest/no TF32；前 50 epoch 干净历史，之后以 0.3 概率加入历史噪声。

150 epoch 共 1,673,700 次 optimizer update，训练约 7.07 小时，日志累计约 7.49 小时，中位 epoch 179.85 秒。没有 recipe exemplar shortfall；缓存 bank 热启动后命中率接近 100%。请求 cross 比例 0.3，实际合格配对平均 **22.95%**。

train loss 从 0.22888 降至 0.10166；matched validation loss 从 0.10332 降至 0.04743，最低值是 epoch120 的 0.04635。训练含 cross/历史噪声而 validation 是干净 matched，不能用二者差距直接断言过拟合。

| epoch | validation matched | validation cross | cross Root ADE |
|---:|---:|---:|---:|
| 5 | 91.11% | 26.74% | 12.821 cm |
| 25 | 92.96% | 40.15% | 12.115 cm |
| 50 | 92.22% | 46.52% | 10.197 cm |
| 100 | 91.85% | 48.67% | 8.415 cm |
| 150 | 91.11% | 50.22% | 8.192 cm |

相同 validation cases 的聚类 paired bootstrap：epoch50→150 cross 增加 **3.70 pp**，95% CI 为 [2.21, 5.21]；N1→N5 exemplar 增加 **4.07 pp**，CI 为 [2.80, 5.49]。两者都有收益，但没有证据能靠原配置再堆训练量弥补约 30 pp。

`best.pt` 实际是 epoch120 的 matched loss best，不是 cross/style best；epoch150 与 epoch120 相比 cross 增加 0.59 pp，CI [-0.37, 1.58]，差异不明确，ADE 则改善 0.433 cm。现有已评估验证快照中 epoch150 是合理候选，但后续选择依据应包含固定 cross validation；不能反复根据 test/OOD 选模型。

## 3. Cross 为什么失败：不是简单复制 source

5000 个 cross cases 中，预测为 source style 的比例仅 **3.04%**。多数错误被分类为 Robot、FairySteps、BentKnees、Penguin 等其他风格，而不是保留原标签。结合部分目标风格稳定成功的结果，更符合“条件控制不充分”的现象；不能简单归因为整个 recipe 接口没有运行。

15 个目标风格 cross 准确率为 0%，包括 BigSteps、March、Skip、Morris、Punch、SpinClock；12 个风格为 100%，包括 Teapot、OnPhoneLeft、ShieldedLeft/Right、ArmsAboveHead。这一结构支持“明显姿态较易控制，步态/时序变化较难”的假设，但不是所有成功风格都能简单归类为静态。

### 历史状态和 recipe 的分工

使用相同 noise、同一模型，对 16 个固定 validation cases 做 CPU TF 控制实验。4 个失败动态风格是 BigSteps/March/Skip/Morris，2 个 OOD 是 WildArms/Zombie。

| 小诊断设置 | 动态 cross，4例 | 明显姿态 cross，2例 | OOD，2例 |
|---|---:|---:|---:|
| source GT history，continuous | 0/4 | 2/2 | 0/2 |
| source GT history，clip→quantize | 0/4 | 2/2 | 0/2 |
| 每帧提供目标风格 GT history，clip→quantize | 3/4 | 2/2 | 1/2 |

目标 GT history 是 oracle 信息，**不是合法的 OOD 成功结果**。它用于说明：模型能维持一些正确的目标风格状态，而单靠 recipe 从 source 状态引入动态风格更困难。TF 每帧重新注入 source 历史，Gaussian noise 并不等价于消除这种风格冲突。

训练只有单步 cross target；GT donor 的前后状态没有作为一个连贯的目标风格运动过程参与当前 cross 条件。可以优先保留 TF、分别训练“从 source 状态转换”和“维持目标状态”，而不是立即使用昂贵 rollout。

### 配对覆盖的实测限制

当前 donor 仅来自当前 batch，必须满足同 action suffix、不同 style、root 速度和 yaw 门限。64×512 个训练帧的抽样诊断得到实际期望 cross 比例 22.96%，与日志一致；在选中的 target style 内，**94.02% 的样本只有 1 个合格 donor**，平均 1.069 个。

因此“最近脚位置的 argmin 导致失败，改成随机 donor 就能修好”不成立：最近与均匀选择的脚间距、抬脚高度、slot entropy 几乎没有差异。首先应增加候选覆盖，而不是只修改这一行 argmin。

部分失败目标曝光不足：BigSteps/Skip 的 cross 曝光相对其原始训练份额约为 0.62/0.65；但 March、Punch 接近 1，仍失败，所以采样不平衡也不是完整解释。test 的 61.8% target-action 组合在训练中不存在，不过已有/缺失组合的 cross accuracy 仅为 51.26%/49.87%，不能用 action 缺失解释全部差距。

## 4. Recipe / style prior 为什么不足以支撑 unseen

当前纯 recipe 路径是：

```text
clip → frozen VQ code frequency ρ[m,k]
     → 每个选定 slot 的 TopK4，重新归一化
     → μ[m] = Σk ρ[m,k] e[k]，8×4D = 32D
     → 已训练 projection → 64D style feature → 一个 style token
```

它不调用 label embedding，也不把 recipe 转成 seen label。其合理性是用码本上的概率分布表达风格；限制是 **8 个 marginal histogram 不包含完整的 slot 联合结构或时间次序，weighted mean 又进一步丢失分布形状**。直方图对时间重排不变，不能完整指定 cadence、周期或旋转过程。

实际 TopK4 平均仅保留 exemplar 原始频率的 **31.78%**，范围 16.92–44.26%。cross 为 0 的 15 类平均保留 25.35%，100% 的 12 类平均保留 36.31%；保留质量与 cross accuracy 的 Spearman 相关约 0.56。这是相关证据，不证明提高 TopK 一定有效。

只在 train 数据拟合的闭集线性诊断：8-slot weighted mean 的 validation style accuracy 为 53.33%，当前已训练 projection 为 74.44%，说明 projection 改善了线性可分性；这不是原始 prototype 的信息上限，也不是生成 accuracy。简单增加 variance/lag 并未提高该诊断结果，因此不建议把“追加方差就能恢复 unseen”作为确定修复。

OOD style feature 的范数都在 seen 范数范围内，没发现简单数值爆炸。5000 个 OOD case 只有 8 个正确，Robot/FairySteps 占所有预测的 39.38%，表明未知组合仍被映射成常见的已知运动形态。完全不对齐 label feature 是合理的边界，但它本身不能保证模型学习到可组合的 OOD 生成规律。

冻结 VQ 对 31 个 OOD reference 的 quantized AE accuracy 是 77.42%，95% CI [61.29, 90.32]；多数风格至少在这些样本中可表达，所以不能把生成 0.16% 全部归因于 VQ。不过 WhirlArms 的 4 个 quantized AE reference 全部失败，它有额外的表示问题。样本很少，AE accuracy 也不是 generator 的严格上限。

## 5. 对应解决方案与优先级

以下是待验证的实现/方法建议，没有把它们描述为已获得实验提升。继续保留 frozen VQ、FP32、现有 flow backbone，不重新加入 reconstruction/classifier loss，也不做 label feature 对齐。

### 优先项 A：修正 cross 训练任务与监督覆盖

1. 增加独立 donor bank，按 target style/action/root 组织，从 train-only motion 中检索；保持 source root/yaw 门限、velocity correction 和 source/exemplar 隔离。目标均衡采样并记录实际 source→target/action 计数，不能把请求概率当作实际 cross 量。
2. 在 TF 中混合两个任务：现有 source-history→retargeted donor-next 的转换任务，以及 retargeted donor-history→donor-next 的维持任务。后一支对 donor 前后 motion 同步做 root/velocity 修正，并重新编码对应 latent，保持 history motion/latent 一致；前一支必须保留，否则会放弃 source-history cross 的评估目标。
3. 部分 cross 转换样本对 history motion 与 latent **共同** mask/降低权重，保留 source trajectory/root 信息，防止模型绕过 recipe；不能只扰动其中一条输入。先用固定的小 validation 集观察条件敏感性、运动连续性与 root 误差，再决定比例。
4. 分别记录 matched/cross FM loss，新增固定 seen-cross validation 选择依据。当前 matched-only loss 无法判断 cross 能力是否改善。

这组变化不需要训练时执行 Euler rollout 或 decoder，但 donor 在线编码的吞吐仍须用短 smoke 测量。

### 优先项 B：保留 recipe 分布信息，并让输出承担风格约束

1. 先验证较高 TopK / 完整分布是否保留更多可区分信息；**不要直接更改旧模型推理 TopK 并假定兼容**。新表示需要重新训练或明确初始化新 projection。
2. 保留“概率选码→style token”核心路径，在求和前加入小型共享码本特征映射：`Σk ρ[m,k] φ(e[k])`，而非仅 `Σk ρ[m,k] e[k]`。它有机会区分均值相同、支持集不同的 recipe，并仍输出单个 style token，维持 6-token backbone。φ 的维度/非线性需要小诊断，不预设必然收益。
3. 当前 pure recipe 的 prior/entropy loss=0是正确行为：输入 recipe 已固定，对它计算 CE 不能约束 flow 输出。若需要 style prior 约束，应作用在 **predicted target latent 的 soft code assignment** 上，再按连贯窗口/兼容样本组汇总，与 exemplar 分布对比；VQ/codebook 固定，梯度只回到 controller。先检查 GT retargeted targets 与该 prior 是否一致，避免 source root/action 不同造成新的监督冲突。
4. 不把逐帧 latent 强行拉到 recipe mean，这会损失动态变化。对真正依赖节奏/时序的 unseen，仅 marginal histogram 存在信息限制；需要时序 recipe 扩展时应明确作为后续方法改动，不能声称当前概率表已经表达完整动态风格。

该分支避免 decoder/classifier 训练开销。是否足以接近 cross 80% / OOD near-cross 仍需实验，不能由当前分析保证。

### 优先项 C：单独处理 root 与 VQ 表示问题

4 秒 test Root ADE matched=4.14 cm、cross=9.50 cm；FR source 的 cross ADE 约 12.59 cm，SW 约 3.81 cm。Root latent MSE 下降不等于 decoded root 无偏。

小控制中 continuous 与 quantized 的 style 成败完全相同，quantization 只带来部分 root 误差变化。因此关掉 re-quantization 不能作为 OOD 修复方案。source GT next-latent 的 quantized AE 在这些小组中的 ADE 约 0.5–1.2 cm，flow 更高，支持进一步定位 controller 的速度/yaw 偏差；这是 source AE 基线，不是 cross target AE。

保持无 reconstruction loss：先分 action 统计 decoded root vx/vz/yaw 的误差均值。若需要训练约束，可以在 train-only latent 上拟合并冻结一个轻量 root probe，经验证足以近似 frozen decoder 的 root 输出后，对 FM predicted target 施加小权重 root loss；若 probe 不准就不采用。不能直接推理后覆盖 root，否则 latent/motion 状态不再一致。

WhirlArms 单独补查 pre-VQ continuous AE 与 quantized AE，区分量化和 decoder 表示限制；当前 VQ 冻结边界下，不承诺所有 unseen 都能达到 80%。

## 6. 建议的下一步顺序

先完成 A 的 donor coverage、条件敏感性和分项日志，再测试 B 的 richer code feature / output distribution consistency。用同一小 validation manifest 和 noise 比较，不混用不同 reference 或 mirror 设置。机制得到支持后，再安排独立目录的有界训练；目标或表示变化用 init-ckpt，不能当作同目标 resume。

不建议原配置再续跑 150 epoch，不建议先做昂贵 rollout，也不建议用 label 对齐或 seen-label 最近邻来代替真正的 unseen 生成。历史 label 模型与此次 recipe 结果的 case/mirror/reference 不完全一致，不能直接用两份数字做公平消融。

## 7. 可复核记录

- [完整 test 摘要](/home/shinn/桌面/multimedia/revision/NewCode/eval_results/recipe_tf150_test_e0150_n5/minor_revision_generalization_summary.json)
- [完整 unseen 摘要](/home/shinn/桌面/multimedia/revision/NewCode/eval_results/unseen_tf240_recipe_ep150/summary.json)
- [统计审计](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/audit.json)
- [小样本条件诊断](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/condition_probe.json)
- [donor 候选诊断](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/donor_bias.json)
- [逐目标诊断](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/per_target_diagnostics.csv)
- [训练与风格图](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/training_and_style.png)

epoch150 SHA256：`a9f42797608f15bd8a17e09ffa272d7e7c10c1574620f7f7efce9725d430c6b3`。OOD 与 test 核对为同一模型；冻结 VQ 内容指纹一致，诊断前后 VQ 权重未变。小控制只有 16 例、donor 曝光为抽样代理、表示诊断为闭集线性测试；均用于定位机制，不能替代完整生成 benchmark。
