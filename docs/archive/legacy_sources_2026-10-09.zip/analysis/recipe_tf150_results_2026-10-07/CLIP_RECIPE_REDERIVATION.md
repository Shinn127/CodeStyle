# Clip / recipe 模型：重新推导与修订方案

2026-10-07。依据当前实现、TF150 结果和已接收论文 Eq.1–8 / Algorithm 2–4 推导。本文修订上一份结果报告中的方案优先级；未修改训练模型、未启动训练或 rollout。

最新实施决策：用户已要求从零训练，原文中的继承epoch150建议不再用于当前训练入口。最终配置见 [从零训练计划](/home/shinn/桌面/multimedia/revision/NewCode/CLIP_RECIPE_REVISION_PLAN.md)。

## 1. 应先区分三个不同的概率分布

设冻结 VQ 的码本为 E={e_k}，所选 8 个 slots 为 Ω。

- **统计先验** p̄[s,j,k]：从训练 motion 的 VQ assignment 计数得到，用于识别风格相关 slots 和监督 selector。
- **学习得到的控制分布** π[j,k]：selector 根据 clip 等条件选择哪些 code atoms，服务于最终生成任务。
- **手工/导出的 recipe** ρ[j,k]：用户直接指定的控制分布，可替代 π。

论文的核心关系是：

```text
clip → E_s → G → π → Σk π[j,k] e_k → P → style token → flow
recipe ρ ─────────────→ Σk ρ[j,k] e_k → P → style token → flow
```

统计先验 p̄ 约束 selector，**并不意味着最频繁的 code 必然就是最好的控制 code**。最终 π 会同时受到 flow 任务的训练信号影响。

当前独立 recipe 模型实际上是：

```text
clip → VQ assignments → empirical histogram r → TopK4 → ρ
recipe ρ → weighted code mean → P → flow
```

`TrainStyleRecipePool` / `sparse_code_histogram` 直接取频率最高的 4 个 code；pure-recipe 模式不调用 learned logits 分支。因此 clip 和 recipe 在接口上已经统一，但统一成了“用统计频率直接指定控制码”。当前可学习的是 P 和 flow，没有学习“从 clip 统计中选择对生成更有用的码”。这是相对论文 clip 分支的重要实现差异；不是单纯忘记给某个 loss 设置权重。

## 2. 为什么已有结果不能支持上一轮所有建议

TF150 的 matched/cross/OOD accuracy 为 98.60% / 50.40% / 0.16%。以下解释需要保持边界：

1. **TopK4 保留 31.78% 的频率质量不是失败的充分原因。** 少数低频 code 也可能很有风格区分力，高频 code 反而可能是共同步态。增加 K 既可能增加信息，也可能重新引入 action/root 干扰。当前相关性只能提示检查，不能作为直接改大 K 的证明。
2. **32D prototype 不是必然无法表达 90 种风格。** 对任意 dense ρ，映射 μ=ρE 一般非单射；但在特定的稀疏支持集/训练分布上仍可区分很多风格。线性 probe 的准确率也不是信息上限。上一轮提出的 Σρφ(e) 会改变原文的 Eq.5，应放在证实当前聚合不足之后作为扩展，而不是默认修复。
3. **Oracle history 的改善不足以证明应增加维持风格训练。** 它每一帧提供了目标风格本身。现有训练已有约 77% matched 样本，已经包含大量同风格 GT-history→GT-next；额外增加相似任务可能继续稀释 cross。维持任务只应在检查缺口后加入。
4. **当前 evidence 没有证明 re-quantization 是主要原因。** 小样本 continuous 与 quantized 路径的风格成败一致；不能据此推广成所有 cases 都不受量化影响。

## 3. 统计先验不能直接等同于输出分布

一个 clip 的 code 直方图可写成：

    r[j,k] ≈ Σa ∫ p(k | style, action=a, phase=φ) p(a,φ | exemplar) dφ

它同时依赖 style、action、phase coverage、root 特征及 VQ 表示。不同动作组成的同风格 clips 不必得到相同 r。选出的 style-sensitive slots 也只是统计相关，并不是已证明独立于 content 的纯 style slots。

当前 histogram 丢失的是**已编码 token 的顺序**；motion291 本身包含 joint velocity，所以不能说它完全没有动态信息。只有在两个不同目标 clip 产生同一 r 时，任何确定性的 histogram-only 编码器都无法将它们区分。

因此，训练时直接要求输出窗口的 code frequency 等于 exemplar r，暗含二者具有相同 action/root/phase 采样的假设；当前 cross protocol 并不保证这一点。将目标直接设为 TopK4 r，还可能排斥真实运动需要的其余 code。

此外，对于当前 target-prediction MSE：

    z_τ = (1−τ) ε + τ z_1
    L_FM = E ||Fθ(z_τ, τ, history, trajectory, style) − z_1||²

给定输入的最优回归函数是：

    F*(·) = E[z_1 | z_τ, τ, history, trajectory, style]

这**不代表完整 flow 采样只能生成均值**；在适当条件下速度场可以描述多模态分布。但训练中某个 τ 的 predicted target 是条件均值估计，其 soft code histogram 不必等于真实 endpoint 分布。因此上一轮提出的 output-distribution KL 不能未经验证直接加入主目标，它会引入新的偏差。

pure recipe 输入固定时，原 selector prior CE 对 flow/P 没有梯度；保持其权重为 0 是正确的。只有恢复 learned selector 后，原文的 prior/entropy 监督才重新具有明确的可优化对象。

## 4. Cross 配对需要先变得连贯

当前配对保持 source root、同 action suffix，但大多数目标风格在 batch 内只有一个合格 donor。它不能保证 donor 与 source 的运动 phase 相容。

补充抽样：seed42，16×512 个 train frames，得到 1,960 个 cross 配对。相邻 root-local 描述中的平均关节位移如下：

| 配对 | mean | median |
|---|---:|---:|
| source GT previous→next | 0.474 cm | 0.421 cm |
| donor GT previous→next | 0.469 cm | 0.418 cm |
| source GT previous→donor next | 15.626 cm | 13.290 cm |

这是姿态差诊断，不是 world-space 速度；风格转换本来就可以改变姿态，所以它不能单独证明 cross target 错误。但现有 loss 同时处理“自然下一帧”和“立即换成另一个风格的姿态”，二者的任务差异很大。只提高 cross 比例不能保证有效。

建议使用 **train-only donor bank + 连续窗口内的固定对应关系**：

- 保持既有 action/root/yaw 条件，先扩大可用 donor，再检查接触状态、左右脚相位和局部运动方向。
- 以窗口确定 donor clip 和时间偏移，在窗口内使用其连续后续帧。训练仍可抽单个 GT-history→target pair，不必做生成反馈。
- 相位匹配避免直接压低目标风格的步幅、抬腿幅度；不要把“与 source 所有脚位置最接近”当作唯一标准。
- source root/trajectory 与 donor pose/rotation/velocity correction 的规则继续保持一致，最终 target 重新编码为同一 VQ latent。
- 独立 exemplar 不得来自监督 source/donor；没有相容 donor 时安全回退并计数。
- 先保持请求 cross probability=0.3，以便判断配对变化的效果；不预先把实际比例提升到 50% 作为默认补救。

对于 source-history TF，每一帧都会重新输入 source 风格。这是一个持续的条件冲突，不能把 target-history oracle 分数替代正式 cross 分数。可以在一部分 cross 样本中对 motion 和 latent 使用共同的 history mask，保留 root/trajectory；具体比例需要小验证，不能与配对和编码器全部同时改动后再归因。

## 5. 首选的条件方案：学习 clip 的选码，recipe 直接执行选码结果

推荐一个共享 flow/P 的 clip+recipe 模型，统一点放在**最终控制分布 π/ρ**，不放在 label feature。

```text
240f clip(s)
  → 冻结 VQ，读取完整 code histogram r
  → 轻量、无 label 输入的 learned selector Aψ
  → dense probability → TopK4 → π
                                     ┐
导出的/手工指定的 recipe ρ ────────────┤
                                     ↓
                         u[j] = Σk ρ[j,k] e_k
                         e_style = P(concat(u))
                                     ↓
                          现有 6-token flow controller
```

clip 入口使用 ρ=π；recipe 入口直接使用输入 ρ。对某个 clip 导出 π 后，两种入口应得到同一 style token，并在相同 history/noise 下生成一致结果。这里没有学习 90 类 label embedding，也没有向 label controller feature 对齐。

考虑此前不补建 learned clip encoder、优先训练效率的约定，这里首先提出的 Aψ **只读取缓存的完整 code 统计**，不读取长 motion 序列。它可以使用共享码本几何特征和 slot 信息进行轻量重评分，避免一个独立的 90 类查表。它仍然是新增的可学习选码环节，会改变此前固定的 histogram 直通方案，应明确记录为下一版实现变更，不能当作原有流程已经具备的功能或一个小 bug 修复。

一个便于从现有模型初始化的候选参数化是：

    a[j,k] = log(max(r[j,k], ε)) + gψ(r, e_k, j)
    π_dense[j] = softmax(a[j] / temperature)
    π[j] = normalized TopK4(π_dense[j])

初始 residual gψ=0、temperature=1，在非零 TopK 支持上可以接近当前 histogram 选码行为。之后生成任务能调整“哪些 code 更适合作为控制信号”。这是候选实现，仍需检查 gradient、TopK 支持变化和数值一致性；不能预先断言它会学到 OOD 组合规律。

可以从当前 epoch150 继承兼容的 P/flow 权重，给新 residual 独立零初始化，重新建立 optimizer/scheduler；这属于新目标的初始化。若用原模型已训练过的 90 个风格再划出部分风格做验证，也不能把它们称为 generator 的 pseudo-unseen。

训练目标保持：

    L = L_FM + λ_prior L_prior(π_dense) + λ_ent H(π_TopK)

prior 使用 train-only offline prior，作用于 learned selector 的 dense logits，避免 dense prior 对 sparse π 的无限 KL。style labels 只用于组建独立同风格 exemplar/target、查询训练先验，不作为 generator 的风格输入。λ 的选择需检查 flow/prior 的实际梯度；prior CE 的常数 entropy 下界不能用来判断梯度支配。

VQ 全部冻结；reconstruction/classifier loss 继续关闭；保持 FP32、6-token backbone、8 slots、TopK4、原始 weighted-code aggregation。这样优先恢复“可学习选码”这一层，不同时改变聚合公式、slot 数和输出 loss。

**训练和导出必须遵守同一语义：** 新的 clip-derived recipe 导出 learned π，而不是重新绕过 Aψ 导出 raw TopK histogram。已有 raw histogram recipe 仍然是合法的码概率，但不能把它与新版 selector 导出的控制配方混为同一生成协议。应记录 recipe 来源、selector/checkpoint 指纹和码本/slot 指纹。

动态训练时不能永久缓存 learned π 并继续更新 selector；可以缓存完整 histogram/VQ indices，forward 时重新计算 π。用于 manual-input parity 的 π 可在当次 forward 导出或 detach；无需同一数据再跑一次 flow 计算重复 loss。selector 冻结后才可长期缓存其输出。

## 6. 这条方案能解决什么，不能证明什么

- 能恢复原文中“统计先验监督 learned selection”的角色，并保留明确的概率选码接口。
- 能保证同一导出配方的 clip/recipe **接口一致性**，避免两条路径暗中使用不同 style feature。
- 能让有限 GPU 预算优先用于正确的监督与可学习的选码，而不是增加训练 epoch 或 decoder 反传。
- **不能保证**任意手工混合、未见 code 组合或 OOD style 达到 80%。概率插值也不等于感知风格按同样百分比线性混合。
- histogram-based Aψ 仍不能恢复原始统计中已经丢失的时间次序。如果小诊断确认这个限制是关键，下一步才是恢复论文的 temporal clip encoder；这比当前“clip→histogram”的实现更接近原文，但超出之前明确约定的实现边界，需要作为单独的方案变更讨论。

也不要把随机混合 recipe 与一个原有 style target 强行配对训练；没有相应监督目标时，这会再次制造条件与 target 冲突。

## 7. 最小验证顺序与停止条件

1. **不训练的 contract 检查：** selector 零 residual 初始化；clip→exported π→recipe 的 token/生成一致；FP32；VQ 不变；manual-only 不访问 label。旧 checkpoint/旧 recipe 保持可读并标明来源，新结构只能 init，不能伪装成旧目标 resume。
2. **配对诊断：** 新旧 bank 同 source/style/root 条件，报告合格比例、候选数、接触/相位差、source→target 姿态差和 action 覆盖。不能只报告 loss 下降。
3. **条件使用诊断：** 相同 source/noise 下换正确、错误、uniform recipe，检查预测变化和目标误差；按 flow 时间 τ 分箱，尤其看低 τ。高 τ 的 z_τ 已含大量 target 信息，recipe 敏感度低不等于完全忽略条件。
4. **有限训练验证：** 先分别验证配对修正和 learned selector，使用固定 seen validation cases；只有出现可重复的 cross 改善、matched 保持和 root 不恶化，才合并。新增 selector 的 FP32 吞吐需实测，缓存 raw histogram 保持轻量。
5. **选型：** 使用 matched/cross validation joint criteria，不再仅按 matched loss 保存 best；锁定后再用同一 manifest 报告 test/OOD。维持 240f/60fps、相同 Gaussian noise 与 clip→quantize→decode。

若步骤 3–4 没有显示条件使用或 cross 改善，就不能用再跑完整 150 epoch 代替诊断。root probe、output-distribution KL、更多 slots、更大 TopK、非线性码本聚合和 temporal clip encoder 均作为有独立证据后再考虑的分支。

## 8. 依据

- [已接收论文，Eq.1–8 / Algorithm 2–4](</home/shinn/桌面/multimedia/MM-2025-11-0162/4 - accept/MM-2025-11-0162.R2_Ma.pdf>)
- [Selector 与 prototype 实现](/home/shinn/桌面/multimedia/revision/NewCode/arch/flowmatch_vqvae_controller.py:71)
- [Clip histogram / train recipe pool](/home/shinn/桌面/multimedia/revision/NewCode/Utils/style_code_prior.py:17)
- [当前 cross target 构造](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:106)
- [TF150 结果与上一轮诊断](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/REPORT.md)
- [本轮 cross pose-gap 抽样](/home/shinn/桌面/multimedia/revision/NewCode/analysis/recipe_tf150_results_2026-10-07/cross_pair_pose_gap.json)
