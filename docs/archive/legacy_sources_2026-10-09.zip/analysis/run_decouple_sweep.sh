#!/usr/bin/env bash
# Content/style decoupling sweep (20 epochs per config) + a style-consistency-loss run.
#
#   ./analysis/run_decouple_sweep.sh
#
# Every run: 90-style DB, frozen 150ep VQ, dense style prior, 20 epochs, save-every 10.
# Afterwards each checkpoint is scored with the generalization evaluation (h=60) so cross-style
# accuracy can be compared against the paired-training baseline (~8% diagnostic / 10.4% eval).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-}"
if [[ -z "${PY}" ]]; then
  if [[ -x /home/shinn/miniforge3/envs/mcc/bin/python ]]; then PY=/home/shinn/miniforge3/envs/mcc/bin/python; else PY=python; fi
fi
VQ="${ROOT}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt"
CACHE="${ROOT}/cache/vq_targets_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep"
PRIOR="${ROOT}/cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz"
FRAME_CLF="${ROOT}/checkpoints/fid_feature_extractor_camdm100_mirror_frame/100style_position_classifier.pth"

train_and_eval() {
  local tag="$1"; shift
  local out="${ROOT}/checkpoints/flowmatch_vqvae_controller_${tag}"
  echo "=============================================================="; echo "[Run] ${tag}"
  PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
    VQ_CKPT="${VQ}" VQ_TARGET_CACHE="${CACHE}" STYLE_CODE_PRIOR="${PRIOR}" \
    STYLE_PRIOR_LOSS=dense STYLE_ENTROPY_WEIGHT=0.02 OUT="${out}" \
    setsid "${ROOT}/run_train_flowmatch_vqvae_controller.sh" --epochs 20 --save-every 10 "$@" \
    > "/tmp/decouple_${tag}.log" 2>&1
  echo "[Done] training ${tag}"
  PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
    FLOW_CKPT="${out}/best.pt" OUT="${ROOT}/eval_results/gen_${tag}" \
    setsid "${ROOT}/run_evaluate_minor_revision_generalization.sh" --horizons 60 \
    > "/tmp/decouple_eval_${tag}.log" 2>&1
  echo "[Done] evaluation ${tag}"
  "$PY" - "${ROOT}" "${tag}" <<'PY'
import json, sys
root, tag = sys.argv[1], sys.argv[2]
d = json.load(open(f"{root}/eval_results/gen_{tag}/minor_revision_generalization_summary.json"))
for r in d["summaries"]:
    print(f"  {tag:18s} {r['setting']:34s} acc={float(r['target_style_acc_pct']):6.2f}  rootADE={float(r['root_ade_cm']):7.3f}")
PY
}

train_and_eval "decouple_p02"        --decouple-prob 0.2
train_and_eval "decouple_p03"        --decouple-prob 0.3
train_and_eval "decouple_p05"        --decouple-prob 0.5
train_and_eval "decouple_p03_sc003"  --decouple-prob 0.3 --style-consistency-weight 0.03 \
                                     --style-classifier-ckpt "${FRAME_CLF}"
echo "[Done] decouple sweep complete"
