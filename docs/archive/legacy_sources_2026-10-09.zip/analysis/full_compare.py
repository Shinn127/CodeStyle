"""Definitive comparison on the paper's exact test window set.

Runs the paper's eval enumeration (all test segments, 60-frame windows, stride 30 = 19,988
windows) through both decode paths and through temporal-filtered variants, with a bootstrap
CI over windows so differences of a few percent can be read as significant or not.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

NEWCODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEWCODE))

from Utils.motion_eval import MotionEvalConfig, compute_sequence_metric_sums  # noqa: E402
from Utils.model_loading import build_vqvae_from_checkpoint  # noqa: E402

DB = NEWCODE / "database_100sty_375_memmap"
CFG = MotionEvalConfig()
WINDOW, STRIDE = 60, 30  # overridden by --window/--stride
K3 = torch.tensor([0.25, 0.5, 0.25])
K5 = torch.tensor([1.0, 4.0, 6.0, 4.0, 1.0]) / 16.0
K7 = torch.tensor([1.0, 6.0, 15.0, 20.0, 15.0, 6.0, 1.0]) / 64.0
K9 = torch.tensor([1.0, 8.0, 28.0, 56.0, 70.0, 56.0, 28.0, 8.0, 1.0]) / 256.0


def smooth_time(x: torch.Tensor, kernel: torch.Tensor) -> torch.Tensor:
    pad = kernel.numel() // 2
    xt = x.transpose(1, 2)
    xt = F.pad(xt, (pad, pad), mode="replicate")
    weight = kernel.to(device=x.device, dtype=x.dtype).view(1, 1, -1).expand(x.size(-1), 1, -1)
    return F.conv1d(xt, weight, groups=x.size(-1)).transpose(1, 2)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=Path, required=True)
    ap.add_argument("--batch-frames", type=int, default=64)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--max-windows", type=int, default=0, help="0 = all")
    ap.add_argument("--window", type=int, default=WINDOW, help="Frames per evaluated sequence")
    ap.add_argument("--stride", type=int, default=STRIDE, help="Window stride across each segment")
    args = ap.parse_args()
    window, stride = int(args.window), int(args.stride)

    device = torch.device(args.device)
    model = build_vqvae_from_checkpoint(args.ckpt, map_location="cpu").to(device).eval()
    norm = np.load(args.ckpt.parent / "norm_stats.npz")
    mean, std = norm["mean"], norm["std"]

    meta = json.loads((DB / "meta.json").read_text())
    segs = json.loads((DB / "segments.json").read_text())
    x = np.memmap(DB / "X.f32", dtype=np.float32, mode="r", shape=(meta["num_frames"], 375))

    spans = []
    for seg in segs:
        if seg.get("split") != "test":
            continue
        last = seg["frame_start"] + seg["num_frames"] - window
        spans.extend((s, window) for s in range(seg["frame_start"], last + 1, stride))
    if args.max_windows:
        spans = spans[: args.max_windows]
    print(f"windows: {len(spans):,}", flush=True)

    variants = ("ae", "ae_smooth3", "vq_raw")
    metric_names = ("mpjpe", "jitter", "foot", "root_ade", "heading", "vel_dir")
    per_window: dict[str, dict[str, list[tuple[float, int]]]] = {
        v: {m: [] for m in metric_names} for v in variants
    }
    per_window["reference"] = {m: [] for m in metric_names}

    for begin in range(0, len(spans), args.batch_frames):
        chunk = spans[begin : begin + args.batch_frames]
        raw = np.stack([np.array(x[s : s + w], dtype=np.float32) for s, w in chunk])
        batch = torch.from_numpy(((raw - mean) / std).astype(np.float32)).to(device)
        with torch.no_grad():
            z_e = model.encode_pre_vq(batch)
            ae = model.decode(z_e, from_indices=False)
            z_q, _, _ = model.encode(batch)
            vq = model.decode(z_q, from_indices=False)
            preds = {
                "ae": ae,
                "ae_smooth3": smooth_time(ae, K3),
                "vq_raw": vq,
            }
        for tag, motion in preds.items():
            pred = batch.clone()
            pred[..., 84:] = motion
            pred_raw = (pred.detach().cpu().numpy() * std + mean).astype(np.float32)
            for i in range(len(chunk)):
                s = compute_sequence_metric_sums(reference_375=raw[i], prediction_375=pred_raw[i], cfg=CFG)
                per_window[tag]["mpjpe"].append((s.mpjpe_sum_cm, s.mpjpe_count))
                per_window[tag]["jitter"].append((s.jitter_sum_cm, s.jitter_count))
                per_window[tag]["foot"].append((s.foot_sliding_sum_cm, s.foot_sliding_count))
                per_window[tag]["root_ade"].append((s.root_ade_sum_cm, s.root_ade_count))
                per_window[tag]["heading"].append((s.heading_error_sum_deg, s.heading_error_count))
                per_window[tag]["vel_dir"].append((s.velocity_dir_error_sum_deg, s.velocity_dir_error_count))
        for i in range(len(chunk)):
            s = compute_sequence_metric_sums(reference_375=raw[i], prediction_375=raw[i], cfg=CFG)
            per_window["reference"]["mpjpe"].append((s.mpjpe_sum_cm, s.mpjpe_count))
            per_window["reference"]["jitter"].append((s.jitter_sum_cm, s.jitter_count))
            per_window["reference"]["foot"].append((s.foot_sliding_sum_cm, s.foot_sliding_count))
            per_window["reference"]["root_ade"].append((s.root_ade_sum_cm, s.root_ade_count))
            per_window["reference"]["heading"].append((s.heading_error_sum_deg, s.heading_error_count))
            per_window["reference"]["vel_dir"].append((s.velocity_dir_error_sum_deg, s.velocity_dir_error_count))
        if begin % (args.batch_frames * 20) == 0:
            print(f"  {begin + len(chunk):,}/{len(spans):,}", flush=True)

    def ratio(pairs: list[tuple[float, int]]) -> float:
        total = sum(v for v, _ in pairs)
        count = sum(c for _, c in pairs)
        return total / count if count else float("nan")

    rng = np.random.default_rng(0)
    summary: dict[str, dict[str, float]] = {}
    for tag, metrics in per_window.items():
        entry: dict[str, float] = {}
        for name in metric_names:
            pairs = metrics[name]
            entry[name] = ratio(pairs)
            boots = []
            n = len(pairs)
            for _ in range(100):
                idx = rng.integers(0, n, size=n)
                total = sum(pairs[int(i)][0] for i in idx)
                count = sum(pairs[int(i)][1] for i in idx)
                boots.append(total / count if count else float("nan"))
            arr = np.array([b for b in boots if b == b])
            entry[name + "_ci95"] = float(1.96 * arr.std()) if arr.size else float("nan")
        summary[tag] = entry

    paper = {"mpjpe": (3.653, 0.187), "jitter": (0.252, 0.006), "foot": (0.277, 0.026),
             "root_ade": (2.840, 0.172), "heading": (3.024, 0.168), "vel_dir": (3.923, 0.174)}
    print(f"\n{'variant':16s} {'MPJPE':>16s} {'jitter':>16s} {'F.S.':>16s}")
    for tag, entry in summary.items():
        cells = []
        for name in metric_names:
            v, ci = entry[name], entry[name + "_ci95"]
            cells.append(f"{v:8.4f}±{ci:6.4f}")
        print(f"{tag:16s} " + " ".join(f"{c:>16s}" for c in cells))
    print(f"{'paper':16s} " + " ".join(f"{paper[n][0]:8.3f}±{paper[n][1]:6.3f}" for n in metric_names))

    args.out.write_text(json.dumps({"windows": len(spans), "summary": summary}, indent=2))
    print(f"\nwrote {args.out}")


if __name__ == "__main__":
    main()
