# 修复版 v2 验证记录

状态：代码修改与轻量 CPU 验证通过；真实缓存/GPU smoke/正式训练/test 未运行。没有论文复现结果。

- 环境：mcc Python 3.13 / Torch 2.13，CPU fixture，OMP/MKL threads=1。
- 全套轻量测试：141 passed，5 subtests passed。随后 recipe 数值边界及 metadata 校验的小改动，相关测试重跑 55 passed。
- 新增 `tests/test_controller_repair.py`：31 个 parametrized 测试实例。覆盖 reconstruction 对 flow/selector 的梯度、冻结 VQ 参数与 EMA、不同比例 reconstruction 梯度、target/velocity、1/2/3 步真实 epoch、三个 tiny-DB CLI 入口、目标/反馈索引、step=1 退化、regularizer 权重、matched_root root/velocity/不可变 donor/cache 开关、recipe 广播/pure/OOD/数值非法值、style-consistency stats/name mapping/梯度、train-only stats、缓存内容替换与路径迁移、实际 CLI epoch resume 与连续训练逐 tensor 一致（num_workers=0）、worker/shuffle 独立 RNG、best/latest 保存、旧模型与 VQ override、world F.S./零 contact、已有 BVH 导出。
- 17 个实现文件 AST 解析、8 个 CLI `--help`、训练 wrapper `bash -n`、pipeline `--mode all --dry-run --microbatch-size 128`、修改文件 `git diff --check` 通过。
- 所有 fixture 使用 pytest 临时目录、小模型和合成数据；没有改写历史 checkpoint、数据库、cache 或已有结果。

这份记录只说明实现检查通过。GPU 吞吐/显存、跨设备最近邻 margin、真实 90-style 展开稳定性、OOD 准确率及九项联合数值标准仍需按 `REPAIR_RUNBOOK.md` 手动执行实验验证。
