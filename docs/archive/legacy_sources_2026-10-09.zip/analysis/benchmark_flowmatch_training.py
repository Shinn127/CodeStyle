"""Bounded FP32 synthetic entry benchmark; never writes model weights or touches real training runs."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Utils.model_loading import build_vqvae_from_checkpoint
from Utils.reproducibility import state_fingerprint
from Utils.vq_target_cache import VQTargetCache
from Utils.motion_eval import reconstruct_motion_batch
from arch.flowmatch_vqvae_controller import build_flowmatch_controller_from_config
from train_flowmatch_vqvae_controller import _run_epoch


class Batches(list):
    dataset = SimpleNamespace(segments=[{'suffix': 'walk', 'source_entry_id': 0}])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--updates', type=int, default=8)
    parser.add_argument('--warmup', type=int, default=2)
    parser.add_argument('--microbatch-size', type=int, choices=[128, 256, 512], default=128)
    parser.add_argument('--profile', action='store_true')
    parser.add_argument('--fused-adamw', action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument('--rollout', action='store_true', help='Also compare fixed-style 64×60-frame inference with/without style token reuse')
    args = parser.parse_args()
    if not 1 <= args.updates <= 20 or not 1 <= args.warmup <= 5:
        raise ValueError('Benchmark is bounded to 1–20 updates and 1–5 warmup updates/config')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA required; no full-training fallback')
    torch.set_num_threads(4)
    torch.manual_seed(42)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    vq = build_vqvae_from_checkpoint(ROOT / 'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt').cuda()
    model = build_flowmatch_controller_from_config(dict(prediction_mode='target', flow_loss_space='normalized',
        use_style_code_selector=True, style_slot_indices=[4, 9, 10, 17, 18, 20, 23, 24],
        style_proto_normalization='none', style_dim=64, style_selector_hidden_dim=128,
        style_selector_topk=4, flow_hidden_dim=256, flow_layers=2, flow_ffn_dim=1024,
        inference_requantize=True, inference_latent_clip=True, dropout=0.), vqvae=vq, num_styles=90).cuda()
    model.set_latent_prior_stats(torch.zeros(128), torch.ones(128), data_min=torch.full((128,), -5.), data_max=torch.full((128,), 5.))
    prior = torch.rand(90, 32, 2048) + .001
    model.set_style_code_prior(prior)
    before = state_fingerprint(model.vqvae.state_dict())
    x = torch.randn(512, 3, 375) * .1
    labels = torch.arange(512) % 90
    cache = VQTargetCache.__new__(VQTargetCache)
    cache.meta = SimpleNamespace(num_frames=1536, num_codebooks=32)
    cache.indices_dtype = np.dtype(np.uint16)
    cache.indices = np.random.default_rng(42).integers(0, 2048, (1536, 32), dtype=np.uint16)
    batch = {'x': x.pin_memory(), 'label': labels.pin_memory(),
             'start': (torch.arange(512) * 3).pin_memory(), 'segment_id': torch.zeros(512, dtype=torch.long)}
    common = dict(model=model, device=torch.device('cuda'), prediction_mode='target', recon_weight=.1,
        style_hist_weight=.02, style_entropy_weight=.003, noise_std=1., prev_latent_noise_std=.3,
        prev_motion_noise_std=.3, prev_latent_dropout=0., prev_motion_dropout=0., solver_steps=8,
        vq_target_cache=cache, cache_vqvae=model.vqvae, grad_clip=1., log_interval=100,
        epoch=1, total_epochs=1, split='benchmark', microbatch_size=args.microbatch_size,
        norm_mean=np.zeros(375, np.float32), norm_std=np.ones(375, np.float32))
    report = {'gpu': torch.cuda.get_device_name(), 'torch': torch.__version__, 'precision': 'FP32',
              'tf32': False, 'matmul_precision': 'highest', 'batch_size': 512,
              'microbatch_size': args.microbatch_size, 'synthetic': True, 'fused_adamw': args.fused_adamw, 'configs': []}
    for label, steps, prob in [('A', 1, 0.), ('B', 2, 0.), ('C', 2, .3)]:
        current = {**batch, 'x': batch['x'][:, :steps + 1].contiguous().pin_memory()}
        optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=1e-4, fused=args.fused_adamw)
        kwargs = dict(common, optimizer=optimizer, unroll_steps=steps, decouple_prob=prob,
                      root_recon_weight=.1 if prob else 0.)
        _run_epoch(**kwargs, loader=Batches([current] * args.warmup))
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
        begin = time.perf_counter()
        metrics = _run_epoch(**kwargs, loader=Batches([current] * args.updates))
        torch.cuda.synchronize(); elapsed = time.perf_counter() - begin
        row = {'stage': label, 'updates': args.updates, 'seconds_per_update': elapsed / args.updates,
               'samples_per_second': 512 * args.updates / elapsed,
               'peak_gpu_gib': torch.cuda.max_memory_allocated() / 1024**3,
               'decoupled_fraction': metrics['decoupled_fraction']}
        if args.profile and label == 'B':
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA]) as profile:
                _run_epoch(**kwargs, loader=Batches([current]))
            row['profile'] = profile.key_averages().table(sort_by='self_cuda_time_total', row_limit=12)
            row['scalar_sync_calls'] = sum(event.count for event in profile.key_averages() if event.key == 'aten::_local_scalar_dense')
        report['configs'].append(row)
        print(json.dumps({k: v for k, v in row.items() if k != 'profile'}), flush=True)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    if args.rollout:
        model.eval()
        sequence = torch.randn(64, 60, 375, device='cuda') * .1
        label = torch.arange(64, device='cuda') % 90
        noise = torch.randn(64, 59, 128, device='cuda')
        original = model.sample_latent
        def no_style_cache(**kwargs):
            kwargs.pop('style_feature', None)
            return original(**kwargs)
        timings, predictions = {}, []
        for name, sample in [('uncached_style', no_style_cache), ('cached_style', original)]:
            model.sample_latent = sample
            kwargs = dict(model_name='flowmatch_target', model=model, x=sequence,
                          style_label=label, noise_plan=noise, flow_ode_steps=8)
            reconstruct_motion_batch(**kwargs)
            torch.cuda.synchronize()
            begin = time.perf_counter()
            for _ in range(3):
                prediction = reconstruct_motion_batch(**kwargs)
            torch.cuda.synchronize()
            timings[name + '_seconds'] = (time.perf_counter() - begin) / 3
            predictions.append(prediction)
        model.sample_latent = original
        torch.testing.assert_close(*predictions, rtol=0, atol=0)
        report['rollout'] = {**timings, 'batch_size': 64, 'frames': 60, 'same_output': True}
        args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2))
        print(json.dumps(report['rollout']), flush=True)
    if before != state_fingerprint(model.vqvae.state_dict()):
        raise RuntimeError('Frozen VQ state changed')


if __name__ == '__main__':
    main()
