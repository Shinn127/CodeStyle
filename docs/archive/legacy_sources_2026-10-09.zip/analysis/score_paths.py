"""Score a VQ-VAE checkpoint over the 100STYLE test split on both reconstruction paths.

The paper's `evaluate_motion_375to291.py` scores `basic_vqvae` through
`encode_pre_vq -> decode`, i.e. it decodes the pre-quantization latent and never touches the
codebook. This script runs that path *and* the quantized path on the very same 60-frame
windows, so the two are directly comparable, and also reports how often the code assignment
changes between adjacent frames -- the mechanism behind the jitter difference.

Usage:
  score_paths.py --ckpt <path> --windows-per-seg 20 [--json out.json]
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

NEWCODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEWCODE))

from Utils.motion_eval import MotionEvalConfig, compute_sequence_metric_sums  # noqa: E402
from Utils.model_loading import build_vqvae_from_checkpoint  # noqa: E402

DB = NEWCODE / "database_100sty_375_memmap"
CFG = MotionEvalConfig()
WINDOW = 60
STRIDE = 30


class Accum:
    def __init__(self) -> None:
        self.sums: dict[str, float] = defaultdict(float)
        self.counts: dict[str, int] = defaultdict(int)

    def add(self, sums) -> None:
        for key, value in (
            ("mpjpe", sums.mpjpe_sum_cm),
            ("root_ade", sums.root_ade_sum_cm),
            ("heading", sums.heading_error_sum_deg),
            ("vel_dir", sums.velocity_dir_error_sum_deg),
            ("foot", sums.foot_sliding_sum_cm),
            ("jitter", sums.jitter_sum_cm),
        ):
            self.sums[key] += value
            self.counts[key] += {
                "mpjpe": sums.mpjpe_count,
                "root_ade": sums.root_ade_count,
                "heading": sums.heading_error_count,
                "vel_dir": sums.velocity_dir_error_count,
                "foot": sums.foot_sliding_count,
                "jitter": sums.jitter_count,
            }[key]

    def metrics(self) -> dict[str, float]:
        return {
            key: (self.sums[key] / self.counts[key] if self.counts[key] else float("nan"))
            for key in self.sums
        }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", type=Path, required=True)
    parser.add_argument("--windows-per-seg", type=int, default=4, help="Windows sampled per test segment")
    parser.add_argument("--batch-frames", type=int, default=64, help="Windows per forward pass")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--styles", type=str, default="", help="Comma-separated style names to keep (empty = all)")
    parser.add_argument("--json", type=Path, default=None)
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    model = build_vqvae_from_checkpoint(args.ckpt, map_location="cpu")
    model = model.to(device).eval()
    norm = np.load(Path(args.ckpt).parent / "norm_stats.npz")
    mean, std = norm["mean"], norm["std"]

    meta = json.loads((DB / "meta.json").read_text())
    segs = json.loads((DB / "segments.json").read_text())
    x = np.memmap(DB / "X.f32", dtype=np.float32, mode="r", shape=(meta["num_frames"], 375))

    keep = {s.strip() for s in args.styles.split(",") if s.strip()}
    rng = np.random.default_rng(0)
    spans: list[tuple[int, int, str]] = []
    for seg in segs:
        if seg.get("split") != "test":
            continue
        if keep and seg["style_name"] not in keep:
            continue
        last = seg["frame_start"] + seg["num_frames"] - WINDOW
        starts = list(range(seg["frame_start"], last + 1, STRIDE))
        if not starts:
            continue
        pick = rng.choice(len(starts), size=min(args.windows_per_seg, len(starts)), replace=False)
        for k in sorted(pick):
            spans.append((starts[int(k)], WINDOW, seg["style_name"]))
    print(f"windows: {len(spans):,} over {len({s[2] for s in spans})} styles")

    accum = {"ae": Accum(), "vq": Accum()}
    per_style = {"ae": defaultdict(Accum), "vq": defaultdict(Accum)}
    code_flips = 0
    code_slots = 0

    for begin in range(0, len(spans), args.batch_frames):
        chunk = spans[begin : begin + args.batch_frames]
        raw = np.stack([np.array(x[s : s + w], dtype=np.float32) for s, w, _ in chunk])
        batch = torch.from_numpy(((raw - mean) / std).astype(np.float32)).to(device)
        with torch.no_grad():
            z_e = model.encode_pre_vq(batch)
            motion_ae = model.decode(z_e, from_indices=False)
            z_q, indices, _ = model.encode(batch)
            motion_vq = model.decode(z_q, from_indices=False)

        indices = indices.detach().cpu().numpy()  # [B, T, heads]
        if indices.ndim == 3 and indices.shape[1] > 1:
            code_flips += int((indices[:, 1:] != indices[:, :-1]).any(axis=-1).sum())
            code_slots += int(indices.shape[0] * (indices.shape[1] - 1))

        for tag, motion in (("ae", motion_ae), ("vq", motion_vq)):
            pred = batch.clone()
            pred[..., 84:] = motion
            # metrics expect denormalized (raw) units, exactly as the offline eval does
            pred_raw = pred.detach().cpu().numpy() * std + mean
            for i, (_, _, style) in enumerate(chunk):
                sums = compute_sequence_metric_sums(
                    reference_375=raw[i],
                    prediction_375=pred_raw[i],
                    cfg=CFG,
                )
                accum[tag].add(sums)
                per_style[tag][style].add(sums)

    reference_floor = Accum()
    for begin in range(0, len(spans), args.batch_frames):
        chunk = spans[begin : begin + args.batch_frames]
        raw = np.stack([np.array(x[s : s + w], dtype=np.float32) for s, w, _ in chunk])
        for i, (_, _, style) in enumerate(chunk):
            sums = compute_sequence_metric_sums(
                reference_375=raw[i], prediction_375=raw[i], cfg=CFG
            )
            reference_floor.add(sums)

    print(f"\ncode change between adjacent frames: {100 * code_flips / max(code_slots, 1):.1f}% of steps")
    header = f"{'metric':10s} {'AE path':>10s} {'VQ path':>10s} {'reference':>10s} {'paper':>9s}"
    print("\n" + header)
    paper = {
        "mpjpe": 3.653,
        "root_ade": 2.840,
        "heading": 3.024,
        "vel_dir": 3.923,
        "foot": 0.277,
        "jitter": 0.252,
    }
    ae = accum["ae"].metrics()
    vq = accum["vq"].metrics()
    floor = reference_floor.metrics()
    for key in ("mpjpe", "root_ade", "heading", "vel_dir", "foot", "jitter"):
        print(
            f"{key:10s} {ae[key]:10.4f} {vq[key]:10.4f} {floor.get(key, float('nan')):10.4f} {paper[key]:9.3f}"
        )

    if args.json is not None:
        payload = {
            "ckpt": str(args.ckpt),
            "windows": len(spans),
            "code_flip_rate": code_flips / max(code_slots, 1),
            "ae": ae,
            "vq": vq,
            "reference": floor,
            "per_style": {
                tag: {style: acc.metrics() for style, acc in per_style[tag].items()} for tag in ("ae", "vq")
            },
        }
        args.json.write_text(json.dumps(payload, indent=2))
        print(f"\nwrote {args.json}")


if __name__ == "__main__":
    main()
