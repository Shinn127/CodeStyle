#!/usr/bin/env bash
# Self-driving pipeline toward matched >= 85 / cross >= 80:
#   1) wait for the screening round to finish (3 x 25 epochs, retarget variants)
#   2) pick the best screening config by (matched + cross)
#   3) 150-epoch long run with that config + evaluation
#   4) if the goal is still not met, 60-epoch run with autoregressive unrolled training (k=2)
#      on top of the winning config + evaluation
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-}"
if [[ -z "${PY}" ]]; then
  if [[ -x /home/shinn/miniforge3/envs/mcc/bin/python ]]; then PY=/home/shinn/miniforge3/envs/mcc/bin/python; else PY=python; fi
fi
VQ="${ROOT}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt"
CACHE="${ROOT}/cache/vq_targets_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep"
PRIOR="${ROOT}/cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz"

train() {  # train <tag> <extra args...>
  local tag="$1"; shift
  PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
    VQ_CKPT="${VQ}" VQ_TARGET_CACHE="${CACHE}" STYLE_CODE_PRIOR="${PRIOR}" \
    STYLE_PRIOR_LOSS=dense STYLE_ENTROPY_WEIGHT=0.02 OUT="${ROOT}/checkpoints/flowmatch_vqvae_controller_${tag}" \
    setsid "${ROOT}/run_train_flowmatch_vqvae_controller.sh" "$@" > "/tmp/goal_${tag}.log" 2>&1
  echo "[pipeline] trained ${tag}"
}

evaluate() {  # evaluate <tag> -> echoes "matched cross"
  local tag="$1"
  PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
    FLOW_CKPT="${ROOT}/checkpoints/flowmatch_vqvae_controller_${tag}/best.pt" \
    OUT="${ROOT}/eval_results/gen_${tag}" \
    setsid "${ROOT}/run_evaluate_minor_revision_generalization.sh" --horizons 60 \
    > "/tmp/goal_eval_${tag}.log" 2>&1
  "${PY}" - "${ROOT}" "${tag}" <<'PY'
import json, sys
root, tag = sys.argv[1], sys.argv[2]
d = json.load(open(f"{root}/eval_results/gen_{tag}/minor_revision_generalization_summary.json"))
res = {}
for r in d["summaries"]:
    if r["setting"].startswith("matched_style_rollout"):
        res["matched"] = float(r["target_style_acc_pct"])
    if r["setting"].startswith("cross_style_transfer_h60"):
        res["cross"] = float(r["target_style_acc_pct"])
    ra = r.get("root_ade_cm")
    if r["setting"].startswith("matched_style_rollout") and ra == ra:
        res["matched_rootade"] = float(ra)
print(f"[pipeline] {tag}: matched={res.get('matched', float('nan')):.2f} cross={res.get('cross', float('nan')):.2f} "
      f"rootADE={res.get('matched_rootade', float('nan')):.3f}")
print(json.dumps({"tag": tag, **res}))
PY
}

# ---------------------------------------------------------------- 1) wait for screening
while ! grep -q "goal queue complete" /tmp/goal_queue.log 2>/dev/null; do sleep 60; done
echo "[pipeline] screening round finished $(date)"

# ---------------------------------------------------------------- 2) pick the winner
BEST=$("${PY}" - "${ROOT}" <<'PY'
import json, sys
from pathlib import Path
root = Path(sys.argv[1])
cands = {
    "retarget_p05_s25": ["--decouple-prob", "0.5", "--decouple-latent", "retarget"],
    "retarget_p07_s25": ["--decouple-prob", "0.7", "--decouple-latent", "retarget"],
    "retarget_p05_noise06_s25": ["--decouple-prob", "0.5", "--decouple-latent", "retarget",
                                 "--prev-latent-noise-std", "0.6", "--prev-motion-noise-std", "0.6"],
}
best, best_score = None, -1.0
for tag, flags in cands.items():
    path = root / "eval_results" / f"gen_{tag}" / "minor_revision_generalization_summary.json"
    if not path.exists():
        print(f"[pipeline] WARNING missing {path}", file=sys.stderr)
        continue
    d = json.load(open(path))
    matched = cross = float("nan")
    for r in d["summaries"]:
        if r["setting"].startswith("matched_style_rollout"):
            matched = float(r["target_style_acc_pct"])
        if r["setting"].startswith("cross_style_transfer_h60"):
            cross = float(r["target_style_acc_pct"])
    rootade = float("nan")
    for r in d["summaries"]:
        if r["setting"].startswith("matched_style_rollout"):
            ra = r.get("root_ade_cm")
            if ra == ra:
                rootade = float(ra)
    # style accuracy is the goal, but a config that cannot follow the requested path is not a
    # usable controller: keep a soft trajectory guard (RootADE <= 8 cm) when picking the winner.
    viable = not (rootade == rootade and rootade > 8.0)
    score = matched + cross
    if not viable:
        score -= 100.0
    print(f"[pipeline] candidate {tag}: matched={matched:.2f} cross={cross:.2f} "
          f"rootADE={rootade:.2f} viable={viable} score={score:.2f}", file=sys.stderr)
    if score > best_score:
        best, best_score = (tag, flags, matched, cross), score
if best is None:
    raise SystemExit("no screening results found")
print("|".join([best[0], str(best[1]), str(best[2]), ",".join(best[1])]))
PY
)
IFS='|' read -r TAG WIN_FLAGS_LIST MATCHED_SELECTED FLAGS_CSV <<< "${BEST}"
IFS=',' read -r -a WIN_FLAGS <<< "${FLAGS_CSV}"
echo "[pipeline] winner: ${TAG} (matched ${MATCHED_SELECTED}, cross ${WIN_FLAGS_LIST}) flags: ${WIN_FLAGS[*]}"

# ---------------------------------------------------------------- 3) long run (150 epochs)
train "goal_long_${TAG}" --epochs 150 --save-every 25 "${WIN_FLAGS[@]}"
M=$(evaluate "goal_long_${TAG}" | tail -1)
echo "[pipeline] long-run evaluation: ${M}"

# ---------------------------------------------------------------- 4) unrolled training if still short
SHORT=$("${PY}" - "$M" <<'PY'
import json, sys
d = json.loads(sys.argv[1])
ok = d.get("matched", 0) >= 85.0 and d.get("cross", 0) >= 80.0
print("0" if ok else "1")
PY
)
if [[ "${SHORT}" == "1" ]]; then
  echo "[pipeline] goal not met by the long run; starting unrolled training (k=2, seq_len=3)"
  train "goal_unroll_${TAG}" --epochs 60 --save-every 20 --seq-len 3 --unroll-steps 2 "${WIN_FLAGS[@]}"
  evaluate "goal_unroll_${TAG}" | tail -1
fi
echo "[pipeline] done $(date)"
