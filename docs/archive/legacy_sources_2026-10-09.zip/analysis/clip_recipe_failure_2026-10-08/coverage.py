"""Audit the existing donor gate on fixed test starts. No models or updates."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from Utils.style_donor_bank import StyleDonorBank


def main():
    torch.set_num_threads(2)
    bank=StyleDonorBank(ROOT/'database_100sty_375_memmap',window=16,windows_per_clip=16,device='cuda')
    rows=pd.read_csv(ROOT/'eval_results/clip_recipe_revision_test/minor_revision_generalization_per_sample.csv')
    rows=rows[rows.setting.str.startswith('cross')].copy().reset_index(drop=True)
    by_entry={s['source_entry_id']:s for s in bank.segments if not s['mirror']}
    suffix=np.array([bank.suffix_map[by_entry[int(i)]['suffix']] for i in rows.source_entry_id])
    anchors=[]
    for entry,start in zip(rows.source_entry_id,rows.source_start):
        s=by_entry[int(entry)];local=int(start)-s['frame_start']
        anchors.append(s['frame_start']+min(local//16*16,s['num_frames']-17))
    unique,inverse=np.unique(anchors,return_inverse=True)
    roots=torch.from_numpy(np.array(bank.source[unique[:,None]+np.arange(1,17)[None],84:87])).cuda()
    has_action=np.zeros(len(rows),bool);qualified=np.zeros(len(rows),bool)
    labels=bank.labels.cpu().numpy()
    for target in rows.target_style.unique():
        for action,indices in bank.groups.items():
            query=np.flatnonzero((rows.target_style.to_numpy()==target)&(suffix==action))
            donor=indices[torch.as_tensor(labels[indices.cpu().numpy()]==target,device='cuda')]
            if not len(query) or not len(donor):continue
            has_action[query]=True
            for begin in range(0,len(query),64):
                selected=query[begin:begin+64]
                q=roots[torch.as_tensor(inverse[selected],device='cuda')]
                d=bank.roots[donor]
                dv=(q[:,None,:,[0,2]]-d[None,:,:,[0,2]]).norm(dim=-1)
                dy=(q[:,None,:,1]-d[None,:,:,1]).abs()
                limit=(q[...,[0,2]].norm(dim=-1)*.2).clamp_min(.25)
                good=((dv<=limit[:,None]).all(-1)&(dy<=30).all(-1)).any(1)
                qualified[selected]=good.cpu().numpy()
    rows['target_action_in_bank']=has_action;rows['start_anchor_qualified']=qualified
    rows['correct']=rows.pred_style==rows.target_style
    result=dict(cases=len(rows),target_action_in_bank_pct=float(100*has_action.mean()),
        start_anchor_qualified_pct=float(100*qualified.mean()),
        groups=[dict(action_in_bank=bool(a),start_qualified=bool(q),count=len(g),
            accuracy_pct=float(100*g.correct.mean()),source_retention_pct=float(100*(g.pred_style==g.source_style).mean()))
            for (a,q),g in rows.groupby(['target_action_in_bank','start_anchor_qualified'])],
        limitation='Uses the training gate at each test case first source anchor only; phase proximity is not an extra rejection gate. Later anchors may be qualified even if the first fails. This is coverage analysis, not a changed evaluation subset.')
    (Path(__file__).parent/'coverage.json').write_text(json.dumps(result,indent=2))
    rows.to_csv(Path(__file__).parent/'coverage_cases.csv',index=False)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
