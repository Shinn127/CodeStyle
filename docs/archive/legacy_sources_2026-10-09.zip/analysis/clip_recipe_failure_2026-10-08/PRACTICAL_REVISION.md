# Clip/recipe：保留核心方法的可执行修订

**2026-10-09评估更正**：训练保持teacher-forced，正式matched/cross/unseen及后续checkpoint选型统一为autoregressive rollout。此前TF结果保留为诊断，不能作为正式效果结论。已有本轮best.pt是按TF选出的epoch35，尚不能称为rollout best；先在固定validation cases上重选，再锁定checkpoint跑test。统一入口见下文。

2026-10-08。代码已修改，最小验证通过；正式训练与风格效果尚未验证。目标仍是 matched≥85%、cross≥80%、unseen接近cross，不把通过代码测试或checkpoint选型门限当作达到目标。

## 为什么修改训练任务

上一轮test matched=98.40%、cross=39.26%、unseen=0.36%。目标recipe存在，但上一帧motion/latent提供了很强的源风格信息；训练中可用的严格cross监督只有约20%。训练配对的目标域也明显窄于随机cross评估域。详见 [原始失败审计](SOLUTION.md)，这些事实支持“先检查模型是否真正利用recipe”，尚不能证明所有错误都来自历史泄漏。

补充的16-case冻结模型诊断尝试增强目标风格场：以source-style recipe构造反向参考，scale=1/2/3。4个动态cross、2个OOD在三个scale下均为0命中；dynamic RootADE约8.54/10.29/14.54cm。scale=1与原采样逐值一致，VQ不变。这个小诊断不支持只增大推理强度；它额外使用了source-style reference，不是正式pure target-recipe评估协议，也不能用于调test结果。记录见 `guidance.json`。

## 保留的核心

```text
独立train reference clips → frozen VQ indices → 完整histogram
                        → 现有learned selector → TopK4 π
                        → codebook weighted means → P → 六token flow

导出的recipe π ───────────────────────→ 同一个weighted means / P / flow
预测latent → clip → re-quantize → frozen VQ decode
```

VQ、normalization、style prior统计公式、8slots/TopK4、P、256 hidden/2 layers/FFN1024不变。label只用于统计prior和选择独立exemplars，不进入clip_recipe的生成条件。无需对齐label feature，也不强制新增temporal clip encoder。训练仍是normalized target-prediction FM，GT latent作endpoint；没有decoder梯度、reconstruction、root reconstruction、classifier loss或rollout训练。

Histogram仍丢失时间顺序，bounded selector仍可能有非零prior-KL下界。当前修订先处理训练条件依赖，没有宣称已经解决这些表达能力限制或实现任意content/style解耦。

## 已实现：真实目标不变，增强历史条件

对一条真实GT转移，令下一帧latent为z_GT，目标recipe为r_GT。三种训练任务共同监督同一个真实endpoint：

| 任务 | 上一帧条件 | 下一帧监督 / recipe | 满强度比例 |
|---|---|---|---:|
| clean history | 原GT motion与latent | 原GT / 原GT style | 50% |
| mixed-style history | 同action、另一train style的历史body，经root修正后重新编码 | 原GT / 原GT style | 30% |
| masked history | 同时mask body与normalized previous latent | 原GT / 原GT style | 20% |

三种任务用同一个gate划分，互斥。前5 epoch线性升到上述比例：epoch1约90/6/4，epoch5起约50/30/20。日志使用实际比例；无另一style的同action donor时，该请求回退为masked任务。

Mixed任务从train-only bank检索另一style，先在有候选的styles中均匀选style，再按脚部相位描述和root/yaw软距离取最近历史帧。保留GT trajectory84及normalized root3，使用donor pose/rotation；joint velocity按原有root平移/yaw修正，整帧重新经过冻结VQ获得与motion匹配的previous latent。读取原始不可变bank，不读取validation/test。独立recipe排除GT监督clip及历史donor clip，保留1/3/5个独立240帧exemplar的原采样方式。

这与旧`matched_root`目标替换有明确区别：**不改target latent、target motion或target style**，只扰动观察到的历史。历史检索没有旧的硬root/yaw目标有效性门限；root差仅作为检索成本，因为它是denoising增强，不把候选称为物理正确的跨风格转移。大幅历史差异仍可能影响连续性，要用验证结果判断。

Masked任务保留trajectory和root，将normalized motion的body `[3:]` 与normalized previous latent同时置零；mask在Gaussian/dropout之后执行，防止某条历史通道仍泄漏body。训练得到非零FM-only selector梯度已通过检查。它提供风格条件学习信号，但会增加相位不确定性；不能直接假设mask比例越高越好。推理保持原输入，没有默认mask推理开关。

原structured Gaussian参数保留：从epoch51开始，概率.3，latent=.3，pose/velocity=.2，root=.05，rotation不加噪。当前短训练只跑50 epoch，因此不会启用这项额外Gaussian噪声；前述mixed/masked历史任务仍从epoch1开始、epoch5升至满强度。这次缩短预算不同时改变其他增强强度。

## 已实现：低flow-time训练

Uniform[0,1]的训练时间中，接近1的z_t已经含有大量真实endpoint信息。为加强接近噪声端时对recipe/command的利用，使用：

```text
t ~ 0.5 × Uniform[0,0.2] + 0.5 × Uniform[0,1]
z_t = (1-t) z_0 + t z_GT
L_FM = MSE(target_pred, normalized z_GT)
```

因此约60%训练t≤.2，而非仅50%；全区间仍有正密度。没有inverse-density补权，实际改变了训练时间的权重，这是需要实验检验的修订。每个t下的条件FM形式仍相同，不改变ODE转换或推理solver。validation loss保持uniform t，无历史增强。关闭新参数时保留原有一次torch.rand的RNG行为。

总loss仍为 `L_FM + .02 L_prior_CE + .003 H(selector)`。不因CE包含常数entropy floor就判断它支配梯度；额外关注KL、实际选码及各任务FM loss。

## 训练配置与有界入口

| 项目 | 设置 |
|---|---|
| 初始化 | 从零controller；不继承旧controller/optimizer/scheduler |
| VQ / stats | 固定VQ150ep best；原normalization；新目录train-only latent stats |
| Cache / prior | 原修复版cache/prior，GT endpoints及来源未变，无需重建 |
| 总预算 | 完整50 epoch；默认不提前停止、不自动追加 |
| Scheduler | cosine horizon=50，lr=5e-4→1e-5；中断恢复不重置 |
| 数据 / batch | seq_len=2、stride=1、unroll=1，有效512，microbatch默认512 |
| 精度 | FP32、highest、TF32=False |
| Seed | 42 |
| 目标替换 | decouple_prob=0 |
| 历史任务 | style=.3、joint mask=.2、warmup=5 epochs |
| Flow time | low_t_probability=.5、low_t_max=.2 |
| 推理 / 风格验证 | Euler8、std1、clip→quantize→decode；240f/60fps autoregressive rollout |

后续训练每5 epoch及停止边界执行固定810-case rollout validation（270 matched/540 cross）；Gaussian seeds、targets、exemplars由manifest固定，只在初始帧使用GT motion/latent，随后反馈生成结果。best排序仍先检查matched≥85%、matched/cross ADE≤5/10cm，再比较cross acc、matched acc、normalized ADE；不自动放宽原门限。**此选型约束没有cross≥80%门限**，诊断best可能远未达到最终目标。

代码保留历史参数名`--tf-val-every`控制此验证间隔，新增`--style-val-mode rollout`明确运行路径；日志与checkpoint分别写`rollout_style_val`和`protocol=rollout_240f`，manifest写`rollout_style_validation_cases.json`。`--style-val-mode reconstruct`仅供显式TF诊断。普通held-out flow loss仍检查单步训练目标，不作为正式运动/风格效果。

```bash
# 只查看完整命令。
DRY_RUN=1 bash run_evaluate_style_rollout.sh

# 当前clip/recipe：固定cases，matched/cross/OOD均rollout，写独立新目录。
bash run_evaluate_style_rollout.sh

# Label模型在同一seen case manifest上复评；只报告label matched/cross。
FLOW_CKPT=checkpoints/flowmatch_tf150_staged_noise/best.pt \
  OUT_ROOT=eval_results/label_shared_cases_rollout EVAL_UNSEEN=0 \
  bash run_evaluate_style_rollout.sh
```

入口不会自动训练或扫描checkpoint，不覆盖历史TF结果。本次未启动以上完整评估。其默认当前best.pt的复评只衡量该checkpoint，不替代rollout validation重选。更改validation模式时不允许直接混用旧best/selection状态resume；下一次训练请设独立RUN_ROOT。

口径修订的轻量验证：34 passed、2个CUDA测试跳过，覆盖label与clip/recipe的240帧style validation、实际OOD入口、manifest共用、rollout日志/选型标记，以及改变未来GT motion不改变rollout输出。Python编译、shell语法和修改的tracked代码diff检查通过。[测试记录](../clip_recipe_failure_2026-10-09/rollout_eval_tests.txt)。没有执行完整test/OOD评估。

默认输出 `checkpoints/clip_recipe_gt_history50`，objective version=8。这个分支的resume严格检查目标、数据、增强、推理参数和scheduler周期；旧v7及此前150周期的训练状态不能直接用于此50周期run续训。保留已有checkpoint与历史结果。`stop_after_epoch`默认为0，可显式设置一个更早停止位置，再恢复至本轮50 epoch上限；到达停止位置后再次RESUME且不改STOP_AFTER_EPOCH不会多跑一个epoch。`selected_checkpoint.json`区分completed_epochs与training_complete。

```bash
cd /home/shinn/桌面/multimedia/revision/NewCode

# 先检查命令。
DRY_RUN=1 bash run_train_clip_recipe_practical.sh

# 从零开始，完整训练50 epoch；本次尚未代用户执行。
bash run_train_clip_recipe_practical.sh

# 本轮意外中断后恢复，最大累计50 epoch。
RESUME=1 bash run_train_clip_recipe_practical.sh
```

支持原入口的RUN_ROOT、DEVICE、NUM_WORKERS、MICROBATCH_SIZE、RECIPE_BANK_MAX_ENTRIES；显存不足可在启动前选256×2或128×4。历史检索与任务划分仍基于完整512有效batch。正式resume不能偷偷改变microbatch等被检查参数。

## 先检查什么，再决定继续

每5 epoch检查固定validation的cross、matched、ADE和actual task fractions，同时比较三类FM loss；第5/10 epoch作为早期观察点，第50 epoch完成本轮验证。训练日志的`cross_flow_loss/cross_samples`在此分支指不同style历史增强样本，**不是cross style accuracy**；masked任务计入单独日志。`gt_target_fraction`应始终为1，`decoupled_fraction`应为0。

若clean FM很低而mixed/masked持续高、validation cross无改善，先按同一validation协议检查source-style retention与recipe敏感性，判断该分支是否学会使用目标条件。若仍忽略recipe，再考虑改style注入强度或selector容量；若seen cross已有明显改善而OOD仍接近0，再审查histogram/TopK的OOD信息损失，temporal encoder只是一种候选。50 epoch后不自动延长；每项后续训练变更需要重新解释其效果，不自动sweep。

50 epoch用于快速检验本次修订，不能预先保证收敛或达标。最终达标仍须同一个checkpoint、同一主推理设置下评估matched/cross/unseen，保持现有全体cases和原source-entry聚类CI，不能按donor是否可配对筛选test。

## 最小验证与成本

CPU全套：**224 passed、4个CUDA测试跳过、5项subtests通过**；宿主GPU环境相关回归：**35 passed**，其中包括实际CUDA历史替换、mask/梯度及Euler分支。35项与CPU全套有重叠，不应直接相加当作独立测试数。结果见 [CPU日志](practical_cpu_tests.txt)、[宿主日志](practical_host_tests.txt)。覆盖真实训练/validation/保存、GT endpoint保持、不同style历史与root保留、两通道joint mask、FM-only selector梯度、冻结VQ及epoch边界精确续训。Python编译、shell语法与修改的tracked代码diff检查通过。

真实RTX5070Ti/16GB短测：新随机controller，实际GT cache、train-only donor bank、recipe pool，有效batch512、FP32/highest/noTF32。第一个smoke运行100updates（32预热+68计时）；进一步全命中计时运行256updates（128预热+128计时）。所有临时模型丢弃，未写正式checkpoint/history；没有完整epoch、style accuracy实验或rollout。

| 短测 | recipe命中率 | 计时ms/update | peak allocated memory |
|---|---:|---:|---:|
| 初次100-update smoke，68步计时 | 55.55% | 59.16 | 1084.19 MiB |
| 128预热后，相同128步计时 | 100% | 25.94 | 1084.19 MiB |

全命中测量的实际clean/mixed/masked=49.93%/29.80%/20.27%，t均值.3004，recipe_fraction=1、shortfall=0，GT target fraction=1，decoder/Euler调用被显式禁止，VQ指纹不变。短测可复现命令：

```bash
/home/shinn/miniforge3/envs/mcc/bin/python analysis/training_speed_2026-10-07/profile_training.py \
  --practical --name practical_history_warm128 --warmup-batches 128 --batches 128
```

该诊断复用旧checkpoint内的固定latent统计/prior和架构配置，**没有加载其trainable controller weights或optimizer**。正式入口在新目录生成train-only统计。原始日志见 `../training_speed_2026-10-07/practical_history_smoke.json`、`practical_history_warm128.json`。

按11158updates/epoch作warm短测外推，训练主体约4.82min/epoch，50epoch约4.02GPU小时；这些不是完整epoch实测，不含cache冷启动、正式I/O/保存和240f验证，必须以首个完整epoch校正。没有基于这个估计自动放宽50epoch预算。
