# Clip/recipe 150 epoch失败分析与下一版方案

**当前实施方案（2026-10-08）**：[GT监督与历史条件增强](PRACTICAL_REVISION.md)。以下保留修改前的失败审计；第3节的 temporal encoder、重采样和三任务配对是候选研究路线，不再作为必须实现的组件。按用户最新要求，优先保留原有选码、code aggregation、P、flow与冻结VQ，修正训练时的条件依赖；相关代码已修改，未启动新一轮正式训练。

2026-10-08。结论：这轮训练没有达到cross/unseen目标。继续原配置加epoch缺少依据。上一版恢复了可学习选码、增加了donor bank，并改善了root误差，但没有解决跨风格监督覆盖和历史状态依赖；histogram仍不是论文中的temporal clip encoder。本次只做现有结果审计和小规模冻结模型诊断，没有改变训练主程序、更新模型或启动新训练。

## 1. 已确认的结果

同一test source/target manifest、FP32、240帧/60fps、teacher-forced、Euler8、clip→re-quantize→decode。分类输入排除GT初始帧。当前选中的best是epoch145；`constraints_passed=true`只检查matched accuracy≥85%及matched/cross ADE≤5/10cm，**没有检查cross≥80%或unseen接近cross**，不能作为最终目标验收通过。

| 指标 | 旧recipe150 | 新clip_recipe150 |
|---|---:|---:|
| Test matched accuracy（1000 cases） | 98.60% | 98.40% |
| Test cross accuracy（5000 cases） | 50.40% | 39.26% |
| Test matched ADE，4秒 | 4.139 cm | 4.193 cm |
| Test cross ADE，4秒 | 9.500 cm | 7.664 cm |
| Unseen accuracy（5000 cases） | 0.16% | 0.36% |
| Unseen ADE，4秒 | 7.824 cm | 6.566 cm |

Cross paired cluster bootstrap按90个source_entry_id聚类、1000次重采样：accuracy变化−11.14pp，95% CI [−13.24,−8.99]；ADE变化−1.836cm，CI [−2.731,−0.942]。风格退步与轨迹改善都超出了此次bootstrap的不确定区间。两轮同时改变selector、loss和配对，不能把差异单独归因于某个模块。

新模型150epoch完成1,673,700次optimizer updates，训练累计11.265小时。epoch100→150 validation cross约42.0%→42.4%，epoch145最高43.15%。Matched约93.7%。train cross FM loss=0.2054，matched=0.02575；两者目标难度不同，不能把8倍差距直接解释为梯度或采样bug。已有结果不支持原配置再训练150epoch。

## 2. 根因及证据强度

### 历史状态依赖与转换任务不足

Test cross被分类为source style的比例由3.04%升至20.38%；OOD为43.82%。这支持源历史对新模型影响增大，但错误仍包括其他seen styles，不能全部称为复制source。

当前TF训练和评估每帧使用source GT motion与source GT latent。约80%训练样本为matched，目标可从历史预测；cross只把下一帧target换成retargeted donor，没有独立训练“目标风格历史→目标风格下一帧”的维持任务。现有history noise不消除style：70%样本完全干净，rotation144维不加噪，另一条latent输入仍携带源风格。0.3噪声概率并不等于遮掉30%的历史。

16个固定post-hoc validation小诊断，同case/noise：

| 设置 | matched | 动态cross：BigSteps/March/Skip/Morris | 姿态cross：Teapot/OnPhoneLeft | OOD：WildArms/Zombie |
|---|---:|---:|---:|---:|
| source history + quantized | 8/8 | 0/4 | 1/2 | 0/2 |
| source history + continuous | 8/8 | 0/4 | 2/2 | 0/2 |
| raw TopK绕过learned selector | 8/8 | 0/4 | 1/2 | 0/2 |
| target GT history AE | 8/8 | 3/4 | 2/2 | 2/2 |
| target GT history + controller | 8/8 | 3/4 | 2/2 | 2/2 |
| 当前模型直接mask两条历史 | 1/8 | 0/4 | 0/2 | 0/2 |

Oracle目标历史是诊断，不能作为cross/OOD结果。4个动态oracle中只有1个有相同action，其他改变了历史的内容/动力学；因此这不能唯一证明“style泄漏”是全部原因，也不能证明root约束下已经可以转换。Oracle的dynamic RootADE约12.72cm，原source-history为8.54cm，显示style与root仍需联合检查。

当前模型没有接受完整历史mask训练，推理时直接mask导致约34–72cm RootADE，**不能直接部署这个推理开关**；这个失败也不等于经过mask训练一定无效。

### Cross监督域比评估域窄得多

当前bank从合格target styles中挑一个，而不是先均匀请求全部target styles。实际cross仅约19.86%，其中某些style/action/root组合可能从未成为target。增加到17,568个bank窗口不等于获得任意cross训练覆盖。

对5000个固定test cross cases审计：

| 起点训练检索覆盖 | cases | accuracy | source retention |
|---|---:|---:|---:|
| Target action在bank中不存在 | 3090 | 38.09% | 21.07% |
| Action存在、但起点root/yaw不合格 | 1872 | 40.22% | 19.55% |
| Action存在且起点root/yaw合格 | 38 | 86.84% | 5.26% |

仅38.2%请求具有相同action；仅0.76%起点anchor能按训练规则检索到donor。这只是首个anchor，后续anchor可能合格；38个合格cases很少且存在选择偏差，86.84%不是新的全体成绩或模型上限。但数据说明“随机target评估”与“极少数合格target训练”有明显覆盖差距。

只把bank密度16改成32不能解决缺失action或根本不同的root状态；不能筛掉不合格test cases后宣称达到80%。

### Histogram条件与论文实现有实质差异

论文第5–6页是 `clip→temporal Es→Gj→TopK→weighted code aggregation→P→flow`，clip Es为2层transformer。当前是 `clip→unordered histogram→bounded geometric residual→TopK→同一P/flow`。

Histogram对code时间顺序不敏感；其中速度信息可能间接携带节奏，但不能恢复已经丢失的时间依赖。当前100份seen/OOD canonical profiles的TopK原始质量约30.93%，learned选择保留29.44%，TopK support重合约88.59%。Learned selector没有把这条路径变成temporal编码器。

Residual为`4*tanh(score/4)`，logits被绑在`log(r+eps)`附近。统计中73.3%的code logits接近残差边界；分母包括未出现codes，这不是活跃码梯度饱和的完整估计。此前prior可达性诊断已证明存在非零KL下界，因此KL≈5不是单独的“实现错误”证据。

3个实际训练target batch的selector梯度：加权prior/FM范数比0.434、0.397、0.662；cosine为−0.178、+0.133、−0.070。FM梯度有效，prior没有在这些batch中全面支配FM。**不要因为prior CE占total约75%就加大prior或删掉FM；也没有足够证据把全部退步归于prior。**

### Teacher-forced结果与真实自回归控制须分别报告

TF每帧重新注入source相位，生成的目标相位不能积累。对恒定轨迹和周期性source历史，输出条件分布也随source周期重复；它难以表达需要独立相位演化的目标节奏。这是限制，不是39.26%的已证明上限，也不能说明所有失败都来自评估。

可以继续用便宜TF训练，但将来应另报240帧autoregressive推理结果，不能用它替换当前TF成绩。**Rollout评估不要求rollout训练**。本次没有执行rollout。

## 3. 推荐下一版：保持论文核心，修正条件与监督

### A. 修正cross目标覆盖与任务

1. 增加target-first的平衡采样及source→target/action/root区间实际计数，防止稀有可配对style被忽略。没有可用配对时明确记录失败，不把target换回source后计成cross。
2. 对同action moving donors，研究受限时间重采样来适配source速度与相位，再检验原root/yaw门限。重采样须连续插值pose、用SO(3)方法插值rotation，按新时间重算velocity；禁止只改root数值而保留不匹配的脚运动。不能处理的stationary/moving、动作或turn组合仍标不可用，不直接放宽阈值。
3. 若时间倍率为alpha，root-frame速度修正应使用 `v'_j=alpha*v_j+(v_source-alpha*v_donor)+(omega_source-alpha*omega_donor)×p_j`；角速度用rad/s。须用实际feature生成约定、有限差分和world-foot/contact检查验证，不能仅凭公式认定物理正确。
4. 缺失action不能用任意不同action换pose再贴target标签解决；需要真实内容匹配/经过验证的retarget，或作为待验证的跨action泛化域单独报告。保持原全体评估清单。
5. 同一优化batch混合三类TF任务，建议起始目标份额：matched40%、source-history转换30%、retargeted target-history维持30%。比例按有效样本实现；不足时记录实际比例。维持样本的前后motion都做一致retarget，重新编码previous/target latent，motion/latent必须一致。三类FM loss分别记录，不能让maintenance伪装成转换成功。

仍不使用生成feedback、decoder训练、Euler展开或报告classifier loss。只缓存冻结VQ输入/indices和配对元数据，不预生成全部source×target笛卡尔积的巨型缓存。

### B. 恢复temporal clip encoder与真正的learned selection

推荐恢复论文已定义的2层temporal clip encoder；保持现有VQ、8slots、TopK4、weighted code aggregation、P、6-token flow backbone。完整pipeline：

```text
reference clips → frozen VQ frame sequence → temporal Es → slot Gj logits
                 → softmax / TopK4 → control π → weighted code means → P → flow
exported/manual recipe ρ ────────────────────────────────┘
```

冻结VQ序列作为Es输入是节省成本的实现选择，需在文档中说明；Es必须保留位置/时间信息。可以将240帧内部降到60tokens并记录采样间隔，对每个独立clip编码后聚合1/3/5 exemplar，不拼成虚假的单条长动作。

Gj可以在全码本上预测，不再强制`log(hist)+bounded residual`；保留train-only dense prior CE与TopK entropy，先保持现有权重以免同时把效果归因于调参。Label仍只用于采样/prior监督，不进入flow条件，也不对齐label feature。Manual recipe直接提供最终概率，不再经过Es/Gj。Clip导出π与manual输入的style feature和采样结果必须一致；recipe指纹必须包含新的Es/Gj。

只缓存冻结VQ和原始clip信息，不能在Es/Gj更新时缓存其输出。按batch去重clip、微批编码、保持有效batch512与FP32；先测吞吐，不承诺与histogram版本相同GPU小时。

**边界说明：这调整了此前“不新增learned clip encoder”的实现约束，但恢复的是定稿论文已有路径，不修改论文。它仍不能保证OOD≥80%；新frontend必须经过held-style验证。** 若坚持该旧约束，则仅实施A/C作为低成本试验，并明确保留histogram的局限，不能声称已经恢复论文clip实现。

### C. 让训练必须使用style条件，同时保持历史有效

1. 在训练中对少量转换/维持样本联合mask历史motion中的pose/rotation/velocity与previous latent；保留trajectory及root条件。起始候选转换25%、维持10%、matched0%，前5epoch逐步升到该比例。不能只mask一条历史，也不在未训练模型上直接开启推理mask。
2. 增加低flow-time训练覆盖，候选 `t~0.5*U(0,0.2)+0.5*U(0,1)`，60%样本落在t≤0.2。所有t仍有支持；对仅依赖t的正采样密度，理想条件MSE最优预测器不变，但有限模型优化会更重视从Gaussian起点依靠条件生成。它是待验证的优化方案。
3. 原history Gaussian noise仍可作为鲁棒性增强保留；它与去除style捷径是不同目的。记录low-t matched/transfer/maintenance FM、recipe swap敏感性、latent/motion反馈一致性和root误差。
4. 推理保持正常历史、clip→quantize→decode；不直接覆盖root，不强行覆盖输出style slots。

## 4. 控制下一轮成本与验收

不立即照旧重跑150。推荐新目录、从零初始化的单一pilot；optimizer/scheduler从零，不兼容旧controller训练状态，VQ/cache/normalization继续固定。训练由用户启动。

- 先构建小的train-only paired fixture，检查root、rotation、velocity、contact以及actual cross覆盖；做100-update FP32 smoke，记录新Es与配对成本。若物理检查或同源exemplar隔离失败，先停在数据/代码层。
- 用controller-held-style validation检查泛化：例如在90个IND styles中固定9个不进入本轮controller的target、donor、recipe pool或prior监督，训练81个；保持冻结VQ。须声明VQ原本见过这90类，故这是controller-held-style诊断，不是完全未知于整个系统的OOD。
- 从零pilot10epoch，cosine horizon预先设150。跨风格晋级目标建议：cross≥40%（旧版本epoch10验证为30.74%），matched≥85%，root不比旧epoch10的8.53/13.31cm上浮超过15%；同时held-style cross应明显超过标签随机机会和source-history基线。这些是节省预算的筛选条件，不是最终80%验收。
- 10epoch未出现更强条件敏感性、有效配对覆盖及cross/held-style进步，就停止检查，不默认继续140epoch。达到条件后才由用户决定在同一新run中连续训练到总150；不另从头加150，也不默认sweep。
- 训练与选型用固定validation source/target/noise。`trajectory_constraints_passed`与`style_goal_passed`分开；最佳诊断模型仍可保存，不能用true标志掩盖cross<80%。
- 最终锁定checkpoint后，同一个设置分别报告TF与AR的matched/cross/OOD；保留原240f分类器、re-quantize及聚类CI。过去10个OOD styles已被观察用于失败诊断，这种探索应在最终报告中注明，不能假称完全未参与方法判断。

联合目标仍是同一checkpoint matched≥85%、cross≥80%、unseen接近cross，同时检查root、world-foot滑动及contact覆盖。当前证据不足以承诺一个版本必然达到这些数字；新方案针对的是已观察到的训练域缺口、历史依赖和clip信息缺失。

## 5. 本次产物与限制

`audit.json`/`target_style_comparison.csv`：相同test cases的聚类差值与逐style退步。`coverage.json`/`coverage_cases.csv`：原规则的起点覆盖，不修改评估子集。`probe.json`/`probe.py`：16例冻结GPU FP32对照、3批selector梯度、VQ状态未变。`validation_curve.csv`：本轮固定TF验证曲线。

诊断脚本语法检查通过；没有运行新训练或修改生产模型。小诊断不是benchmark、oracle不是成功结果、推理mask/raw-recipe对照不是重训效果，新增时间重采样/temporal encoder/history mask/low-t目标都仍需独立验证。
