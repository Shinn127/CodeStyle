"""60 vs 120 frame comparison for the delivered checkpoint, including the data floor."""

from __future__ import annotations

import json
from pathlib import Path

NEWCODE = Path(__file__).resolve().parents[1]
PAPER_60 = {"mpjpe": 3.653, "jitter": 0.252, "foot": 0.277, "root_ade": 2.840, "heading": 3.024, "vel_dir": 3.923}
NAMES = {
    "mpjpe": "MPJPE (cm)",
    "jitter": "Jitter (cm)",
    "foot": "F.S. (cm)",
    "root_ade": "rootADE (cm)",
    "heading": "Heading (deg)",
    "vel_dir": "Vel dir (deg)",
}


def load(path: Path, key: str) -> dict[str, float]:
    data = json.loads(path.read_text())["summary"][key]
    return data


def main() -> None:
    sixty = json.loads(Path("/tmp/full_compare_100k_6metric.json").read_text())["summary"]
    hundredtwenty = json.loads(Path("/tmp/full_compare_120.json").read_text())["summary"]

    print(f"{'metric':14s} {'paper(60f)':>11s} {'ours 60f':>16s} {'ours 120f':>16s} {'floor 60f':>10s} {'floor 120f':>11s} {'change':>9s}")
    for key, label in NAMES.items():
        p = PAPER_60[key]
        a, b = sixty["ae"][key], hundredtwenty["ae"][key]
        fa, fb = sixty["reference"][key], hundredtwenty["reference"][key]
        ratio = b / a if a else float("nan")
        print(
            f"{label:14s} {p:11.3f} {a:10.4f}±{sixty['ae'][key + '_ci95']:5.4f} "
            f"{b:10.4f}±{hundredtwenty['ae'][key + '_ci95']:5.4f} {fa:10.4f} {fb:11.4f} {ratio:8.2f}x"
        )
    print()
    for tag in ("ae", "ae_smooth3", "vq_raw"):
        if tag in hundredtwenty:
            e = hundredtwenty[tag]
            print(
                f"120f {tag:12s} mpjpe={e['mpjpe']:.4f} jitter={e['jitter']:.4f} f.s.={e['foot']:.4f} "
                f"rootADE={e['root_ade']:.4f} heading={e['heading']:.4f} vel_dir={e['vel_dir']:.4f}"
            )


if __name__ == "__main__":
    main()
