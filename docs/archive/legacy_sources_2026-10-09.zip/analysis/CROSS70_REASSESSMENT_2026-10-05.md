# 历史 cross 接近70%的复核与后续训练建议

本次仅读取已有配置、checkpoint与评估结果，并在10个train batch上抽查donor选择覆盖率；没有训练、生成评估或rollout。本文件更新此前 `TF5_STYLE_FAILURE_ANALYSIS_2026-10-05.md` 的建议优先级：**受约束cross目标监督优先，source-condition masking和噪声增强作为辅助假设。**

## 历史结果确实有cross响应，但伴随轨迹损失

以下均为历史60fps/60帧classifier协议，不能当成新的240帧结果。除最后一行，表中生成路径均为autoregressive rollout；当前TF与历史rollout的差距不能直接解释为单个超参数的因果效应。

| 模型/训练任务 | epoch | Matched acc % | Cross acc % | Matched ADE cm | Cross ADE cm |
|---|---:|---:|---:|---:|---:|
| 旧matched-only，p=0 | 50 | 64.90 | 10.44 | 1.348 | 1.790 |
| donor cross p=.2 | 20 | 67.80 | 57.14 | 3.930 | 9.292 |
| donor cross p=.3 | 20 | 72.20 | 66.62 | 4.104 | 9.406 |
| retarget cross p=.5，previous noise=.3 | 25 | 73.70 | 69.34 | 6.296 | 11.388 |
| retarget cross p=.5，previous noise=.6 | 25 | 73.40 | 71.98 | 7.382 | 13.517 |
| 同上checkpoint，eval re-quantization | 25 | 72.60 | 70.74 | 8.034 | 13.970 |
| 当前matched-only，rollout | 5 | 37.10 | 3.22 | 4.239 | 4.398 |
| 当前matched-only，teacher-forced | 5 | 91.30 | 0.06 | 1.446 | 1.556 |

继续增加旧retarget比例到p=.7，cross为69.76%，matched为71.10%，cross ADE升到20.45cm；没有支持“越高cross比例越好”的证据。

复核结果：

- 历史p=.5/noise=.6、其re-quantization版本、当前TF/rollout及donor p=.2/.3的5000个 `(source_start,target_style)` cross keys完全相同，全部target不同于source，来自1000个source windows。
- 历史p=.5/noise=.6与当前TF的真实motion预测一致，reference accuracy均为96.4%。历史目标style macro accuracy为71.76%，量化版70.50%，不是少数容易target支撑的总体高分。
- 历史与当前controller内嵌完整VQ state的内容指纹相同：`402c1c5c1d14ce4390e592e9a64d94bad84ffa1b9bc0e345597fd25e6cdd7bd8`。没有证据要求重训VQ才能恢复seen cross。
- 历史p=.5/noise=.6的cross source-style retention仅0.46%，当前TF为87.58%。旧模型确实明显响应请求style；当前TF主要维持source style。
- 按DB原始source_entry_id重新聚类，90个source clusters、seed42/1000次bootstrap，旧71.98%的95%CI为[70.66%,73.20%]，量化70.74%的CI为[69.40%,72.16%]。这不同于旧报告把相关windows当独立样本的CI。

历史报告没有完整classifier内容指纹与逐case噪声manifest；训练同时存在epoch、velocity/target、旧loss weighting、selector/prototype及cache统计等差异。因此它们支持训练任务的重要性，不是严格单变量消融，也不能证明target prediction更差。

主要原始报告：

- `eval_results/gen_decouple_p03/minor_revision_generalization_summary.csv`
- `eval_results/gen_retarget_p05_s25/minor_revision_generalization_summary.csv`
- `eval_results/gen_retarget_p05_noise06_s25/minor_revision_generalization_summary.csv`
- `eval_results/gen_retarget_p05_noise06_s25_req/minor_revision_generalization_summary.csv`
- `eval_results/gen_tf50_short5_tf/minor_revision_generalization_summary.csv`
- `eval_results/gen_tf50_short5_rollout/minor_revision_generalization_summary.csv`

## 最有依据的解释：训练过请求冲突，同时牺牲源运动约束

matched-only只观察 `previous A + request A -> next A`。完整previous motion与latent已经携带A的风格；flow绕过style token也能拟合目标。dense style prior约束selector分布，并不直接训练 `previous A + request B -> next B`。

历史donor/retarget明确把一部分request改成B，并用B的motion作监督。它提供了要求使用style条件的训练样本，和p=0到p=.2/.3的cross提升一致。旧matched-only训练50epoch仍只有10.44% cross，也不支持仅把当前matched-only从5延长到50就能达到80%的预期。

但旧 `apply_style_decoupling()` 会移植donor的整个motion291，包含root vx/yaw/vz；source trajectory84仍不变。retarget重新编码 `[source trajectory, donor motion]`，并未保留source GT root motion。重新编码修正了encoder的trajectory输入，却留下source控制与donor root目标冲突。未匹配动作/相位的随机donor也可能带来大的pose跳变。这是代码确定的目标冲突；它是ADE恶化的合理解释，尚未通过单变量实验完全量化。

因此旧70%是“风格跟随较强但路径较差”的结果，不是同时达到matched85/cross80/源轨迹保持的证据。旧noise从.3到.6的报告差异仅为cross+2.64个百分点，却伴随cross ADE+2.13cm；不同run使其不能当成纯noise因果效应。关闭re-quantization也不是主要收益来源：开启后仍70.74%。

## 下一阶段建议：保持高效latent训练，先恢复质量可控的cross监督

1. **从当前target模型初始化一个独立微调目录。** 使用 `--init-ckpt` 只继承兼容权重，重新初始化optimizer/scheduler/RNG；改变任务不能直接resume。建议lr=1e-4，seed42；维持target/normalized、seq_len2、unroll1、stride1、FP32/highest/noTF32、冻结VQ、recon/root/style-consistency=0、prior=.02、entropy=.003。不要同时换回velocity、旧prototype或更换VQ，以免失去问题定位能力。5epoch旧训练与新微调分别记账；若仍以总50epoch为上限，新阶段最多45epoch。
2. **优先matched_root p=.3，而不是旧随机retarget。** 保留source trajectory及GT root，donor pose/rotation和修正后的joint velocity重编码为target latent；GT previous条件仍是source，属于teacher-forced。网络和style-prior核心保持原样，补足冲突条件组合的监督；合成cross配对属于方法修正，应透明记录。
3. **启用前补充配对质量检查。** 当前函数只对 `x_window[:,1:]` 的目标帧匹配root/feet，seq_len2时实际只检查一个target frame。建议把动作、root兼容和contact/步态相位检查扩展到两帧配对；不要直接用全body pose距离压掉目标style差异。还需抽查合成target经冻结VQ的quantized encode/decode后是否保持源root、目标style及合理joint velocity。VQ被冻结并不意味着能无误表达每种合成输入；检查未通过时先修配对，不急于长训练。
4. **记录实际cross比例和style/action覆盖。** 本次seed42、10个512样本train batch、seq_len2/stride1的抽查，当前规则eligible约76.1%，p=.3的实际cross约22.9%（batch范围19.9%–27.5%）。结果保存于 `matched_root_train_coverage_2026-10-05.json`。这里只执行donor选择，latent callback用零值代替；不是质量、编码耗时或训练效果测量。更严格的相位限制会改变覆盖率，不能照搬22.9%作为修订后比例，也不建议为增加覆盖直接放宽root约束。
5. **先看5epoch阶段检查，再决定剩余预算。** 使用固定validation TF cases，同时看matched/cross target acc、cross source retention、target confidence、macro acc与Root ADE。source retention下降只有在target acc同时上升时才有意义。不能只按matched flow loss挑模型，也不按test结果挑checkpoint。独立TF style validation/选择接口尚待实现，现有rollout选择器不能替代；当前通用generalization主入口仍用于test。
6. **噪声与masking后置。** 若显式cross监督仍严重依赖source，才研究窗口级style-slot遮挡或局部previous-pose条件增强；不得直接清空推理条件。初次保留noise=.3，不将旧noise=.6和cross、mask、recipe同时叠加。既有mask干预只减少source retention，没有稳定提高目标accuracy，不足以支持mask优先于cross监督。
7. **seen cross成立后再改善recipe/OOD。** 用train-only、独立seen exemplars构造与label一致的recipe条件，尝试10%–20%条件增强并统一slots、TopK及指纹；先验证seen label与recipe差距。OOD只走pure recipe，不进入90类generator训练、不查OOD embedding；exemplar与real参考clips分开。此建议未验证能让unseen接近cross。

recon/root均关闭时，cross合成目标需要冻结VQ encoder在线前向，但不要求decoder参与训练或梯度，也不运行Euler训练积分。它会比全缓存matched-only多一部分编码成本；不能沿用matched-only的1.78 GPU小时直接预测新阶段耗时。应从用户短训练日志测量实际成本，必要时再讨论配对缓存，不能为提速改变target语义。

## 4秒classifier与结论边界

新classifier为60fps/240帧，训练完成并冻结后，应把旧70%模型与当前模型放在同一240帧TF validation manifest下比较；每case仅分类生成240帧，排除GT context。没有这次评估，不能把旧60帧70%换算成4秒accuracy，也不能断言时长增加一定提高生成accuracy。参考GT和quantized AE需使用同一协议。

先固定4秒style指标，同时保留独立60帧root诊断用于历史对照；不能把历史1秒ADE阈值静默套到4秒。240帧teacher-forced可以批量独立time points生成，无需反馈或rollout。本阶段仍不做rollout。

当前TF matched91.3%已超过85%，但这不是闭环matched85%的证明。若最终目标指实际autoregressive控制器，TF cross修复后仍需单独解决反馈稳定性；本次未执行该阶段。上述建议均是有证据的下一步研究选择，不是达到cross80/OOD接近cross的承诺。
