# Style prior 的统计依据、优化目标与控制可行性

本文是 v2 实现的分析快照，历史统计不随后续修订改写。基于本文的 v3 实现选择及验证范围见 [`STYLE_REFINEMENT_RUNBOOK.md`](../STYLE_REFINEMENT_RUNBOOK.md)；新默认 projection 使用原始 prototype，recipe 训练增强保持关闭。

本文基于接受稿第 4–5 页 Eq. (1)–(8)、Algorithm 2–4，以及修复后的当前代码。只读取既有 prior/codebook/诊断结果，计算静态统计与几何量；没有训练、生成评估或修改模型实现。历史结果不代表修复版的结果。

结论：style prior 可以作为风格条件的统计锚点和共享码本接口，有明确的概率解释；slot saliency、稀疏 selector 和 flow conditioning 各有额外假设。它们组合起来不自动形成纯风格表示，也不能单独保证 cross-style 或 OOD 控制。

## 1. 估计的随机变量与贝叶斯解释

设 style 标签为 S，动作/速度/相位等内容为 C，冻结编码器与量化器产生第 j 个 slot 的码索引 K_j。当前 prior 估计的是 p(K_j=k | S=s)，不是完整的 p(z_next | C,S)，也不是 flow 的 Gaussian source prior。

对 style s 的训练帧，计数 n_(s,j,k)，总帧数 N_s。对类别概率向量采用对称 Dirichlet(alpha,...,alpha) 工作模型：

\[
p_{s,j}\mid n\sim\operatorname{Dir}(n_{s,j,1}+\alpha,\ldots,n_{s,j,K}+\alpha),
\qquad
\bar p_{s,j,k}=\frac{n_{s,j,k}+\alpha}{N_s+K\alpha}.
\]

这正是 Eq. (1)，也是后验均值/下一次类别观测的预测概率。它不是 alpha=1 时的 MAP。重写为

\[
\bar p=(1-\eta_s)\hat p+\eta_s U_K,
\quad \eta_s=\frac{K\alpha}{N_s+K\alpha}
\]

可见 smoothing 是向 uniform 收缩。冻结 VQ 与 normalization 使这些统计具有稳定参照系；换 codebook 后旧索引概率不再具有原语义。

历史 VQ150ep prior 中，90 styles 的 N_s 最小/中位/最大为 31,188 / 58,268 / 126,830，K=2048、alpha=1，uniform 收缩质量约 6.16% / 3.40% / 1.59%。因此 alpha=1 在这里温和，但不是完全可以忽略。后验不确定性不能把帧当作独立样本：连续帧、重叠窗口、镜像都有关联，需按原始 clips 衡量稳定性。对于某个码的 indicator，自相关近似给出 N_eff ≈ N/(1+2 sum_lag rho_lag)；实际值需要估计，本文没有给出假设数值。

## 2. Slot saliency 为什么合理，以及它没有证明什么

若使用同一个 style 权重 w_s 和对应混合分布 p_j=sum_s w_s p_(s,j)，则

\[
I(S;K_j)=\sum_s w_s\operatorname{KL}(p_{s,j}\Vert p_j).
\]

这是 slot 对 style 标签的统计信息量。当前使用 D_j=mean_s JS(p_(s,j),p_global,j)。JS 有界且对零频次稳定，是可用的风格关联评分；它不等于 mutual information，也不保证与 MI 有相同排序。当前 global prior 按帧计数汇总，saliency 按 style 等权平均，style 长度不平衡和两级 smoothing 也会影响参考分布。

关键区别是

\[
p(K_j\mid S)=\int p(K_j\mid S,C)p(C\mid S)\,dC.
\]

差异既可能来自 style，也可能来自不同的动作构成、root speed、yaw、phase、clip 长度。更贴合“同内容换风格”目标的证据是 I(S;K_j | C)，或在同 suffix/相近 root 条件下比较分布。这是诊断方向，不是当前已验证结论。

选择 top-8 slots 也不等于 VQ 已被分成 8 个纯 style slots 和 24 个纯 content slots。训练 VQ 时没有这样的独立性约束；当前 flow 仍预测全部 latent slots，Omega 只定义 style token 的检索接口。

## 3. Dense prior supervision 的数学目标

令 q=softmax(a/tau)，r=T_m(q) 为 top-m 保留后重新归一化的概率；当前 m=4。Laplace-positive prior p 与有零元素的 r 做 forward KL 时：

\[
\operatorname{KL}(p\Vert r)=+\infty\quad(m<K).
\]

因此接受稿 Eq. (7) 按 hard-top-k 的字面定义不能直接作为有限目标。clamp 只是数值替代，top-k 外的监督对 logits 不提供相应有效梯度。

修复版监督 dense q：

\[
L_{prior}=\operatorname{CE}(p,q)=H(p)+\operatorname{KL}(p\Vert q),
\qquad
\frac{\partial L_{prior}}{\partial a_k}=\frac{q_k-p_k}{\tau}.
\]

式中省略 batch/slot 平均系数。p 冻结时 CE 和 KL 的训练梯度完全相同，H(p) 是常数，不能从 CE 占总 loss 的比例推断梯度支配。当前 loss/日志分开记录 CE、真实 KL 和 target entropy 是必要的。

历史 selected prior 的平均 H(p)=4.83416 nats，几何平均 perplexity=exp(mean H)=125.73；历史控制器的 dense KL≈0.3642。两者说明宽分布及其拟合程度，不能直接推出稀疏 token 是否足够好。

## 4. Top-k 是合理的稀疏投影，但对应另一个方向的 KL

固定支持集 A，令 a=p(A)，p_A=p(k|k in A)。对支持在 A 的 r：

\[
\operatorname{KL}(r\Vert p)=\operatorname{KL}(r\Vert p_A)-\log a.
\]

故最优 r=p_A。再在 |A|≤m 的支持集中优化，选概率最大的 m 个码最大化 a，因此

\[
T_m(p)=\arg\min_{r:\|r\|_0\le m}\operatorname{KL}(r\Vert p).
\]

这证明 top-k+归一化作为 mode-seeking 稀疏近似有数学依据。当前 T_m(q) 精确对应对 dense selector q 的这种投影，而 dense prior loss 使用 KL(p||q)；这是两阶段机制，不是 KL(p||T_m(q)) 的等价实现。它也没有证明最高频码就是最有辨识力的风格码。辨识力更接近 log[p_(s,j,k)/p_(global,j,k)]，高频但所有 styles 共用的码可能风格 lift 很低。

历史 selected slots 的 top-4 平均质量为 19.2566%，去掉 smoothing 后为 19.9043%；宽支持主要来自真实占用，不能归因于 alpha=1。720 个 style-slot 对的最小/最大 top-4 mass 为 2.1849% / 96.0751%，固定 top-4 的压缩强度并不均匀。这些是概率质量，不等于保留/损失了相同比例的风格信息。

## 5. Dense prior 与 sparse entropy 的耦合

对 dense q 的同一支持 A，a=p(A)、b=q(A)。KL 的链式分解为

\[
\operatorname{KL}(p\Vert q)=
\operatorname{KL}(\operatorname{Ber}(a)\Vert\operatorname{Ber}(b))
+a\operatorname{KL}(p_A\Vert q_A)
+(1-a)\operatorname{KL}(p_{A^c}\Vert q_{A^c}).
\]

所以全分布 KL 较小与 q_A 很尖可以同时成立：选中支持的偏差只乘以 a。固定支持及其质量时，内部 r=q_A 的相关目标是

\[
\lambda_{prior}a\operatorname{CE}(p_A,r)+\lambda_{ent}H(r).
\]

相对条件 prior 的有效 entropy 比例为 lambda_ent/(lambda_prior*a)。以 prior 自身 top-4 的平均 a≈0.1926 作尺度说明，两个权重同为 .02 时该比例约 5.19；真实 learned support 的 a 必须另测，不能直接代入这一平均值作为每个 slot 的真实系数。

历史 prior top-4 条件分布的 mean top-1=0.3253、entropy=1.3481 nats，而历史 label selector diagnostic 的 mean top-1≈0.9140。它们来自不同路径/汇总，不能作为严格 paired 差值或修复版性能结论，但足以提醒：label token 和 exemplar recipe token 的形态可能明显不同，训练并未自动对齐这两种输入。

在支持不变时，r_k=exp(a_k/tau)/sum_(l in A) exp(a_l/tau)，top-k 外 logits 对 r 的梯度为零；只有 dense prior 对全部 logits 提供监督。H(r) 的作用是 sharpen，而不是让四个码都充分参与。因此 top-k=4 实际也可能近似单码检索。

## 6. Probability prior 到 style token 的信息压缩

当前 prototype 是 u_(s,j)=sum_k r_(s,j,k)e_k，e_s=P(LayerNorm(concat_j u_(s,j)))。K=2048、每个码 e_k∈R^4、M=8，因此进入 projection 前只有 32 个标量。它是 code distribution 的一阶矩，而非完整分布；projection 再宽也不能恢复此前丢掉的维度。

令 E 为 2048×4 的码本矩阵，分布差 delta 满足 delta E=0、sum delta=0 时，两个不同分布有同一个 prototype。增广矩阵 [1,E] 的 rank≤5，存在很大的概率方向 null space；小扰动可保持非负，说明映射非单射。最简单的例子是各 50% 的 -1/+1 与全部位于 0，两者均值相同但占用/方差不同。

对 prior top-k 支持 A：

\[
\mu_{full}=a\mu_A+(1-a)\mu_{A^c},
\quad
\mu_A-\mu_{full}=(1-a)(\mu_A-\mu_{A^c}).
\]

因此 tail mass 大不必然导致 prototype 误差大；如果 tail 与保留码的质心相近，几何误差可以很小。本次读取历史 prior 与 VQ150ep codebook，计算 8 个 slot 拼接后的静态几何量：full→top4 prototype 误差中位数 1.0699；full prototype 最近另一 style 距离中位数 0.7562；逐 style 的误差/最近 style 距离比中位数 1.5493。这些是 projection/LayerNorm 之前的原始 latent 单位，不能直接解释成分类或生成失败；它说明频率截断的几何扰动值得单独检查。

码本 affine rank 实测为 4。任意 dense 平均可由最多 5 个码的凸组合表示：若支持超过 5，增广向量在 R^5 中线性相关，可沿保持均值/总质量的方向调权，直至至少一个权重变零，重复即可。这是对“存在某个五码组合”的论证，不是“最高频五码”能精确保持均值。top-4 可以是实用折中，但没有通用的一阶矩精确保留保证。

此外，直方图丢失时间顺序和跨 slot 联合关系。交替 1/2 与先一段 1 再一段 2 的边际直方图相同；两 slots 的正相关/负相关也可能有相同单 slot marginals。若 style 区别主要在节律、相位耦合或 joint coordination，当前 prior/recipe 无法完整描述。若 style 主要由相位稳定的姿态倾向、幅度与常用局部形态表征，边际统计可能已经足够有效。这是可行性的条件。

## 7. 对 flow matching 与 cross-style 的作用边界

冻结条件映射、仅看平方 flow target loss，理想总体最优函数为

\[
F^*(z_t,t,C,e_s)=\mathbb E[z_1\mid z_t,t,C,e_s].
\]

把不同 styles 映射到可区分的 e_s，有助于区分条件目标；prior 给 selector 的概率提供数据锚点。这是与 conditional generation 相容的设计。但当前 prior loss 只约束 selector，不约束生成 latent 的码占用等于 prior，也不把生成的 selected slots 强制写成检索码。实际生成仍由 flow 决定。

matched-only 数据中，previous motion 与 style condition 同源。训练支持没有“source A + target B”的组合，则依赖 previous motion 的函数与服从 target style 的函数，可以在 matched 训练支持上给出相同结果，而在 cross 条件上任意不同。对 selector 加 KL 无法排除这种解。这是 cross-style 的识别问题，不是把 prior loss 再乘一个更大权重就能解决的问题。

matched_root 提供 root/suffix 匹配的 cross 条件与显式合成目标，修复直接监督冲突并扩大训练支持，因而与 prior 互补。它仍不能保证 donor phase 连续、完全内容/风格分离或所有目标 styles 都可在所有 root controls 下成立。若风格定义本身依赖速度/转向，“完全保持 root + 完整复制该风格”可能没有数据支持或物理上不可兼得的区域。

独立的表征解耦文献也强调额外监督与 inductive bias 的作用。其无监督不可能性结果不能直接套用到这里的有 style label 方案；这里的具体限制来自上面的条件训练支持和边际信息丢失。

## 8. OOD recipe 的可行性条件与最优先验证

冻结词典允许 new-style exemplars 通过 histogram→recipe→prototype 进入同一接口，无需新 label embedding。这在工程上成立，是 exemplar-conditioned unseen-style control；并非没有参考信息的无条件 zero-shot。

每个 u_j 落在 conv(E)，但这不能保证整体 prototype 在 seen-style 训练点的邻域，更不能保证非线性 P 映射后的 token 在已学习条件分布中。训练使用 learned label selector，OOD 使用经验 top-4 recipe；除了 style 本身未见，输入构造也发生改变。支持 OOD 所需的证据包括：VQ 保留 unseen motion 的必要信息；recipe 对 exemplar/suffix/speed 稳定；seen label 与 seen recipe 条件已对齐；flow 在目标 style 与 source content 冲突时仍能跟随 style；控制约束下存在可实现的目标风格。

最优先的后续检查应按下面的因果链拆分，而不直接增加训练 epoch：

1. 同 suffix/相近 root 条件、原始 source clips 为重采样单位，确认 saliency 与 histogram 是 style 关联而非内容混合。
2. 固定同一 case/noise，比 seen label、seen exemplar recipe、learned token、prior top-4 token。seen recipe 若已明显下降，先解决 conditioning 对齐再归因于 unseen style。
3. 比 raw histogram、top-4 distribution、32-d prototype、projected token 的 style 可分性及同 style 跨 clip 波动，定位信息在哪一步丢失。
4. cross donor 的 actual fraction、动作/root 覆盖与 matched/cross 差距分开报告；不能从 token 干预有效推出条件解耦充分。

可研究但本文没有执行的方法方向：对齐 seen recipe 与 label token；内容分层/均衡 histogram；加入简单 temporal/co-occurrence 统计；对 sparse prototype 做几何保持而非仅按频率截断；用支持内 prior mass 校准 entropy 的相对作用。它们会改变研究方法，应在修复基线确认后单独比较，不作为本次分析的自动代码修改。

## 来源与证据边界

- 接受稿：`/home/shinn/桌面/multimedia/MM-2025-11-0162/4 - accept/MM-2025-11-0162.R2_Ma.pdf`，第 4–5 页公式与算法，相关页已完整视觉核对。
- 实现：`precompute_style_code_prior.py`；`Utils/style_code_prior.py:16`；`arch/flowmatch_vqvae_controller.py` 的 `StyleCodeSelector`、`encode_conditions`、`compute_loss`；`build_zeroshot_style_recipe.py`。
- 静态统计：`cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz` 与对应 VQ150ep best；历史 selector 结果 `eval_results/style_token_diagnostic.json` 与 `analysis/IMPLEMENTATION_AUDIT_2026-10-05.md`。新修复版 cache/训练结果尚未生成。
- [Neural Discrete Representation Learning](https://arxiv.org/abs/1711.00937)：离散词典与后续 prior 建模的基础背景，不作为纯 style 解耦的证明。
- [Flow Matching for Generative Modeling](https://arxiv.org/html/2210.02747v2)：条件概率路径/向量场回归的基础背景。本文的 target-MSE 条件均值及支持域论证由当前目标直接推导。
- [Challenging Common Assumptions in the Unsupervised Learning of Disentangled Representations](https://arxiv.org/abs/1811.12359)：监督/归纳偏置的边界背景；不把其无监督定理误用于当前带标签模型。
