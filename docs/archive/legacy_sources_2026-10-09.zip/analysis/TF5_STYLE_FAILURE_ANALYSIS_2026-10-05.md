# 5 epoch TF / no-reconstruction 训练的风格问题分析

2026-10-05历史结果复核更新：见 [`CROSS70_REASSESSMENT_2026-10-05.md`](CROSS70_REASSESSMENT_2026-10-05.md)。历史同VQ、同cases的显式cross训练可达约70%，同时伴随显著Root ADE恶化。因此下一阶段优先考虑质量可控的cross监督，masking/噪声增强后置；下文保留最初诊断与建议记录。

分析对象：`checkpoints/flowmatch_tf50_short5/best.pt`，epoch5。读取用户已有TF和rollout test报告；额外诊断只使用16个未镜像、独立原始validation clips，CPU、FP32、teacher-forced。没有启动训练、新rollout或OOD评估，没有修改训练代码或用户checkpoint。已有test结果用于解释现象；后续配置比较与选择应回到固定validation cases。

结论：teacher-forced matched已经超过85%，但cross几乎仍是source风格；自回归又有独立的反馈稳定性问题。当前最强证据指向source-style依赖和缺少对冲突条件组合的约束，不能仅凭延长matched-only训练、增加prior权重或关闭re-quantization预期cross达到80%。OOD本轮尚无结果。

## 用户已有完整评估

两套CSV的source_start / target_style / setting case keys完全相同。每套matched1000、cross5000，均对应90个原始source_entry_id clusters，classifier使用100类ybot15/60帧版本，前90个class names与generator style names严格一致。

| 路径 | Matched target acc | Cross target acc | Matched Root ADE cm | Cross Root ADE cm |
|---|---:|---:|---:|---:|
| Teacher-forced | 91.30% | 0.06%（3/5000） | 1.446 | 1.556 |
| Autoregressive rollout | 37.10% | 3.22% | 4.239 | 4.398 |

TF matched的聚类bootstrap 95%CI为[87.12%,94.66%]，cross为[0%,0.127%]。Rollout matched为[31.06%,43.00%]，cross为[2.73%,3.76%]。同cases真实motion accuracy为96.40%。TF cross有87.58%仍被判为source style，目标style平均confidence仅0.0913%。Rollout cross source retention为12.58%，目标accuracy仍只有3.22%；source retention下降不能作为成功换风格的证据。

TF summary的`flow_eval_mode=reconstruct`，但行名仍是`matched_style_rollout_h60`，属于报告命名问题。当前60行评估会保留第1行GT，classifier实际看到1行GT+59行生成；应在独立新协议读取61行context、只分类60行生成。不能静默重写已有报告。TF目录未找到case manifest，rollout目录有manifest；虽然CSV case identities一致，TF历史噪声来源的完整审计仍欠缺。

逐style结果也需解释参考上界：TF Tiptoe为22.22%（9窗口），真实motion为100%；Robot和Rushed生成均0%，但真实motion也分别只有36.36%和33.33%。这些小分组不是新的模型选择依据，说明全局matched91.3%同时包含生成损失和classifier自身的类别混淆。

原始结果：

- [TF summary](/home/shinn/桌面/multimedia/revision/NewCode/eval_results/gen_tf50_short5_tf/minor_revision_generalization_summary.json)
- [Rollout summary](/home/shinn/桌面/multimedia/revision/NewCode/eval_results/gen_tf50_short5_rollout/minor_revision_generalization_summary.json)
- [TF逐样本CSV](/home/shinn/桌面/multimedia/revision/NewCode/eval_results/gen_tf50_short5_tf/minor_revision_generalization_per_sample.csv)

## 为什么prior收敛、cross仍失败

本次完整配置为target/normalized、seq_len2、stride1、unroll1、decouple0、recipe_prob0、recon/root/style-consistency0、prior.02、entropy.003、prior initialization、8 slots/TopK4、FP32/highest/TF32关闭。训练所有目标都来自同style GT相邻帧；模型同时收到完整previous motion291和完整previous quantized latent128，两个条件都携带source style。previous noise.3不能被视为已消除style信息。

训练只观测“previous A + request A → target A”。如果F主要依赖previous state与插值latent z_t来预测next latent，也能取得很低的flow loss；训练没有充分约束“previous A + request B → target B”的行为。prior CE约束selector的码本分布，无法单独保证flow field使用style token。这里是基于训练支持集和已有干预结果的代码推断，不是已经完成因果分解的定论。

train flow从.08018降到.03549，val从.07692到.05369，说明matched预测仍在改善；不是NaN或全局不收敛。epoch5 train/val prior KL为.02689/.02677，top1约.577，entropy约1.083。prior CE约4.837中，target entropy约4.810为常数；prior加权约.09675，其中可优化KL仅约.000538。total loss中prior占71%不能证明它主导梯度。16-source诊断检查全部90个style token：90个不同prototype、feature有限、中心化feature平均norm1.805；没有支持“所有style token已塌成同一个”的证据。

style敏感slot由style marginal histogram的JS选择；相关性不等同于style/content完全分离。P把每slot的分布压缩为4维码本均值，prior拟合成功也不等于生成语义必然正确。应先检查flow对条件组合的响应，避免继续把所有问题归到prior统计或VQ质量上。

## Re-quantization：本次eval已启用

读取best.pt和latest.pt确认：`inference_requantize=True`、`inference_latent_clip=True`、`solver_steps=8`、`noise_std=1`。eval report中的`flow_requantize_z=null`与`flow_latent_clip=null`表示没有CLI override；加载后分别继承checkpoint的True。`flow_ode_steps=0`和`flow_noise_std=-1`同样是继承默认值的哨兵，实际为8步和std1。

默认输出路径是continuous sampled latent → clip →最近邻re-quantization→decode。TF也执行这一输出处理，但每步条件重新取source GT；rollout则把最终quantized latent和对应decoded motion反馈到下一步。量化后不会再裁剪code vector。

[配置继承位置](/home/shinn/桌面/multimedia/revision/NewCode/Utils/motion_eval.py:655)、[状态处理函数](/home/shinn/桌面/multimedia/revision/NewCode/arch/flowmatch_vqvae_controller.py:718)。若做明确continuous对照，参数是`--no-flow-requantize-z`；不能把nullable字段误读成False。

## 新增的小规模validation检查

seed42、16个独立未镜像validation clips，各61行GT→60行生成；classifier排除GT首行。targets固定为(source_label+37)%90，各路径复用同一Gaussian。独立time points批量采样，不把生成结果反馈，保持GT previous latent与motion。没有bootstrap CI；这些数字只定位机制，不替代1000/5000完整报告。

| 路径 | Requested accuracy | Source retention | 对source pose的距离 cm |
|---|---:|---:|---:|
| GT | 87.50% | 87.50% | ≈0 |
| Quantized AE | 87.50% | 87.50% | 1.149 |
| TF matched continuous | 87.50% | 87.50% | 1.661 |
| TF matched quantized | 87.50% | 87.50% | 1.719 |
| TF cross continuous | 0% | 75.00% | 1.970 |
| TF cross quantized | 0% | 81.25% | 2.065 |
| Cross：previous latent受控style slots置为train mean，quantized | 6.25% | 6.25% | 6.718 |
| Cross：previous motion置normalized zero，quantized | 0% | 6.25% | 13.163 |
| Cross：两种previous条件均置normalized zero，quantized | 0% | 0% | 13.475 |

关掉quantization未恢复cross；它可能影响抖动和边界，但没有表现出当前cross崩溃主因的迹象。遮源style slots能明显减少source retention，却没有可靠提高requested accuracy；slots也承载内容，且本模型没训练这些mask条件。突然在推理清空条件不构成修复。cross对source pose的距离在这里仅用于量化干预大小，不是目标风格质量指标。

额外把请求B的训练prior作为pure recipe，分别使用dense和TopK4输入，cross仍为0%。这是seen prior接口对照，不是exemplar recipe或OOD结果。它支持“更换style输入接口不足以绕过当前flow条件依赖”，不能据此判断OOD上限。

[完整诊断JSON](/home/shinn/桌面/multimedia/revision/NewCode/analysis/tf5_style_diagnosis_val16.json)

## 面向85+/80+/unseen接近cross的建议

1. **先把验收路径固定。** 若目标指TF，matched已超过85%；若指最终控制器rollout，matched仍只有37.1%。同一checkpoint、同一输出策略分别记录TF/rollout matched/cross，不以TF matched替代闭环结果。OOD目标可明确为与cross差距≤5个百分点，作为研究目标而非已证明可达的标准。定稿Table4为matched84.40/cross71.02/unseen67.17；80+ cross比论文更高，不能承诺单次修改达成。
2. **下一次短验证优先改变训练中的source-style依赖。** 保持网络、冻结VQ、target latent flow loss、recon0、FP32与stride1。可研究20%–30%样本上的受控style-slot masking，并配套previous pose条件的窗口级扰动/部分dropout；GT next目标与request style一致，保留trajectory/root条件。逐窗口决策，记录实际比例。不能把现有逐元素F.dropout当成整条件dropout，也不建议在未适应模型上直接把推理条件清零。它只是低成本训练假设，validation需同时看matched accuracy、cross accuracy/source retention及Root ADE。
3. **若仍缺少正确cross响应，加入质量可控的cross配对监督。** 现有matched_root可以作为候选，但同suffix+相近root+最近脚位置不能保证相位一致。先加强整个两帧window的接触/步态相位与root方向兼容，避免监督巨大pose跳变；从.1–.2请求比例开始观察实际合格donor比例，保留大量matched样本。明确标为训练方法修正。recon/root weight仍可保持0，使用重新编码的合成target latent；需要decoder的root loss不是默认提效方案。没有可靠配对时不要强开.3并把请求比例当实际覆盖率。
4. **建立seen recipe能力后再要求OOD接近cross。** 当前recipe_prob0；label训练经TopK4，manual recipe可以是dense，可能存在condition分布差异。用独立train-only seen exemplars构造recipe作10%–20%条件增强，target仍为本样本GT style；优先复用code cache，统一slot顺序、TopK/权重约定与指纹。先比较seen label与seen recipe matched/cross；OOD仅以pure recipe (`style_label=None`, strength1)输入，不调用90类embedding或进入generator训练。每OOD style的5个独立240帧exemplars与real classifier参考分离。当前通用generalization脚本的seen recipe开关不等于真正OOD评估，不能通过向90类embedding传90–99来替代OOD路径。
5. **最终rollout85+仍需解决feedback差距。** 等TF cross有正确响应后，再在用户安排的独立阶段使用detach的短展开与clip→quantize→decode一致反馈；单步GT条件训练不足以验收该目标。目前只读取用户已有rollout，未启动这一步。

暂不建议加大prior/entropy权重、直接优化报告classifier、替换VQ、强行覆盖root/style code，或仅增加ODE steps期待0.06%变80%。这些措施没有得到本次证据支持。保持固定validation manifest作有限比较，锁定checkpoint后再进行test。

## 训练效率与续训边界

这5个完整epoch平均train121.08秒、含普通val127.91秒，每epoch11158 updates，stride保持1。按当前速度50epoch约1.78 GPU小时，不包含额外style生成验证、OOD或其他阶段；相对旧recon.1日志约391秒train/epoch，主训练约快3.2倍，比较并非严格同配置性能消融。

本run停止epoch5但cosine horizon50，epoch5结束lr约4.88e-4，没有提前降到1e-5。不能把当前差距归咎于短cosine提前衰减。当前严格resume还比较`epochs`：5→50直接改stop会报配置不一致。如果需要同目标补完剩余45epoch，先增加仅延长stop、保持horizon50和optimizer/RNG的受控resume支持；如果改变condition augmentation或cross监督，则在独立目录用`--init-ckpt`进行明确微调。不要把重置optimizer后额外50epoch称为原run的总50epoch。

本次交付是结果审计、CPU/FP32最小机制检查和实验建议；未验证任何建议已经达到85/80或OOD目标。
