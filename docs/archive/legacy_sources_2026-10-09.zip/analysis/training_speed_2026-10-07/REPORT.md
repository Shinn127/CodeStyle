# Clip/recipe FP32 训练提效记录（2026-10-07）

代码优化已完成；短时速度与数值检查通过。正式训练当前停止，最新完整 checkpoint 为第 8 epoch；尚未恢复第 9 epoch。恢复长期训练的工具请求被自动审批拒绝，等待用户明确授权，或由用户自行续训。

## 实测结果

设备：RTX 5070 Ti 16 GB。相同第 8 epoch checkpoint、seed/RNG、真实 train 数据、batch/microbatch=512、stride=1、FP32、highest、TF32=False，冻结 VQ；没有 reconstruction、rollout 或 classifier 训练损失。

先运行 128 个临时 optimizer updates 预热 recipe bank，再重置诊断自身 RNG 和 loader seed，计时相同 128 个 batch。warm cache hit 均为 1.000。所有诊断模型更新均丢弃，没有写入正式 checkpoint/history。

| 项目 | 优化前 | 优化后 |
|---|---:|---:|
| Warm 128 updates | 5.233 s | 3.739 s |
| Warm ms/update | 40.886 | 29.208 |
| Cold ms/update（前128步，含预热） | 129.194 | 93.591 |
| PyTorch peak allocated memory | 1145.49 MiB | 1095.69 MiB |
| Warm matched/cross samples | 52,558 / 12,978 | 52,558 / 12,978 |
| Warm flow loss | 0.08052464574575424 | 0.08052464574575424 |

Warm 吞吐提升 **1.400×**、每 update 时间下降 **28.56%**。短 benchmark 包含 loader 重置与大 dataset 的 sampler 开销，不能直接当成完整 epoch 时间；完整 epoch 改善和 GPU 利用率仍须续训确认。历史 epoch 8 的 train 时间为396.45 s；按短测比例估计约283 s/epoch，仅为估计，不是已完成的整轮实测。

正式比较使用 `reference128.json` 与 `final128.json`。其他 JSON 是定位过程记录：`baseline.json` 是 cache cold/mixed；`optimized128.json` 与 CPU 全套测试并行，受 CPU 竞争影响，不用于最终速度结论。GPU/CPU profiler range 时间会重叠，不应相加当成 step wall time。

## 改动及训练语义

- Donor matching：仅为请求 cross 且长度合格的样本读取窗口、计算 phase/root/yaw 匹配；仍按完整有效 batch 的 action groups 消耗原来的 RNG 数量与顺序，均匀选 target style 的规则保持一致。
- 冻结 donor bank 的 group roots、phase norms、labels 和 entry codes 复用；in-place 修改 bank tensor 时缓存自动失效。
- 将 donor 行号与索引合并到一次 D2H 传输；日志累积留在 GPU，epoch 末转换为 Python float。固定 normalization 在 epoch 开始时放到 GPU。
- Recipe pool：保留原始 sparse histogram cache及原来的 exemplar/variant/exclusion采样；同一 profile 上传一次，GPU展开到 batch。没有缓存 trainable selector 的输出。
- Full histogram直接归一化 bincount，不再排序全部2048个 code；TopK tie 顺序与选择逻辑保持一致。
- 内部已验证的 train histogram/生成 TopK probability 使用快路径，减少重复 normalization/check/synchronization。外部 histogram、recipe 的形状、非负、有限值、完整 slots 校验保留。
- 单步 seq_len=2 直接使用原窗口，减少一次 stack/copy。

模型容量、loss weights、prior/selector 公式、donor 约束、batch=512、stride=1、FP32、冻结VQ、history noise阶段、scheduler、验证选型协议与150 epoch上限保持一致。没有新增 trainable 参数或改变 checkpoint 的 objective version；现有 objective version 7 的本次运行可以 resume。

Donor 两项日志改为 FP32 GPU 累积，128-step对照的差异约1e-7；这只影响日志末位，不参与优化、donor选择或checkpoint选型。

## 正确性验证

- CPU 全套：**219 passed，2 CUDA-only skipped，5 subtests passed**。
- 宿主 GPU 环境相关测试：**28 passed**，覆盖实际 CUDA loss/gradient 分支、内部 histogram快路径、冻结VQ、实际训练入口与epoch续训。
- 独立真实 GPU 对照：**16 batches × 512 = 8,192 samples**；交替检查 history probability=0 与0.3（latent std=.3、motion std=.2、root std=.05）。优化前后 donor、synthetic target latent/motion、histogram、loss、全部生成器梯度及CPU/CUDA RNG逐值一致；最大loss/gradient差为0。
- Warm 128-step对照的总loss、matched/cross flow loss与样本数量也逐值一致。没有评估风格准确率或运行rollout；本次结果证明训练提效与已检查输入上的数值等价，不能作为新style指标结果。

原始结果：`equivalence.json`、`cpu_tests.txt`、`host_gpu_tests.txt`。`profile_training.py` 可在需要时重做一次性诊断，`before/` 保留本次优化前源文件。诊断默认读取当前latest；未来checkpoint变化时，应固定同一checkpoint再做比较。

## 当前训练状态与续训

运行目录：`checkpoints/clip_recipe_scratch150`。第8 epoch的`latest.pt`含模型、optimizer、scheduler、RNG；已有checkpoint和history保留。当前没有正式训练进程。

如由用户自行恢复，在NewCode目录执行：

```bash
PYTHON_BIN=/home/shinn/miniforge3/envs/mcc/bin/python DEVICE=cuda RESUME=1 bash run_train_clip_recipe_revision.sh
```

这会从第9 epoch恢复既有运行，总上限仍为150（剩余最多142 epoch），不是重新训练150 epoch。重新启动后recipe cache会先重新预热，最初几十步速度不代表warm steady-state。若由代理代为恢复，需要用户针对这条已有训练明确授权；当前未启动长期训练。
