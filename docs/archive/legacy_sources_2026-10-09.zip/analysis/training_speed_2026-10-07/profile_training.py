"""Disposable real-batch benchmark. Never writes training checkpoints/history."""
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import sys
import time

import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import train_flowmatch_vqvae_controller as trainer
from dataset import build_train_val_test_dataloaders
from Utils.model_loading import build_vqvae_from_checkpoint
from Utils.runtime import load_norm_stats, set_seed, configure_torch_runtime
from Utils.style_donor_bank import StyleDonorBank
from Utils.style_code_prior import TrainStyleRecipePool
from Utils.vq_target_cache import VQTargetCache
from Utils.reproducibility import restore_rng_state, rng_state, state_fingerprint


def before(name, filename):
    spec=importlib.util.spec_from_file_location(name, Path(__file__).parent/'before'/filename)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def main():
    global trainer, TrainStyleRecipePool, StyleDonorBank
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', required=True)
    parser.add_argument('--batches', type=int, default=128)
    parser.add_argument('--profile', action='store_true')
    parser.add_argument('--math-attention', action='store_true')
    parser.add_argument('--cpu-threads', type=int, default=0)
    parser.add_argument('--verify', action='store_true')
    parser.add_argument('--reference', action='store_true')
    parser.add_argument('--reference-current', action='store_true')
    parser.add_argument('--practical', action='store_true', help='Fresh GT-target/history-augmentation smoke; no controller weight initialization')
    parser.add_argument('--warmup-batches', type=int, default=32)
    opts = parser.parse_args()
    setup_started = time.perf_counter()
    if opts.cpu_threads:
        torch.set_num_threads(opts.cpu_threads)
    if opts.practical and (opts.reference or opts.verify):
        parser.error('--practical cannot use the legacy/reference comparison')
    if opts.reference:
        trainer = before('reference_trainer','train_flowmatch_vqvae_controller.py')
        trainer.build_flowmatch_controller_from_config = before('arch.reference_controller','flowmatch_vqvae_controller.py').build_flowmatch_controller_from_config
        StyleDonorBank = before('reference_donor','style_donor_bank.py').StyleDonorBank
        TrainStyleRecipePool = before('reference_prior','style_code_prior.py').TrainStyleRecipePool
    if opts.reference_current:
        def current_before(name, filename):
            path = ROOT/'analysis/training_speed_2026-10-09/before'/filename
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            return module
        trainer = current_before('current_reference_trainer', 'train_flowmatch_vqvae_controller.py')
        trainer.build_flowmatch_controller_from_config = current_before('arch.current_reference_controller',
            'flowmatch_vqvae_controller.py').build_flowmatch_controller_from_config
        StyleDonorBank = current_before('current_reference_donor', 'style_donor_bank.py').StyleDonorBank
        TrainStyleRecipePool = current_before('current_reference_prior', 'style_code_prior.py').TrainStyleRecipePool
    state = torch.load(ROOT/'checkpoints/clip_recipe_scratch150/latest.pt', map_location='cpu', weights_only=False)
    args = state['args']
    device = torch.device('cuda')
    configure_torch_runtime(device=device, tf32=False, cudnn_benchmark=args['cudnn_benchmark'], matmul_precision='highest')
    if opts.math_attention:
        args['fp32_math_attention'] = True
    set_seed(args['seed'])
    mean, std = load_norm_stats(args['norm_stats'])
    vq = build_vqvae_from_checkpoint(args['vqvae_ckpt']).to(device)
    model = trainer.build_flowmatch_controller_from_config(args, vqvae=vq, num_styles=args['num_styles']).to(device)
    if opts.practical:
        # These are fixed data statistics, not trainable controller weights.
        model.set_latent_prior_stats(state['model']['latent_offset'], state['model']['latent_scale'],
            transport_std=state['model']['latent_transport_std'],
            data_min=state['model']['latent_data_min'], data_max=state['model']['latent_data_max'])
        model.set_style_code_prior(state['model']['style_prior_probs'])
        def forbidden(*a, **k):
            raise AssertionError('Latent-only teacher forcing must never decode/integrate')
        model.vqvae.decode = forbidden
        model._integrate = forbidden
        frozen_before = state_fingerprint(model.vqvae.state_dict())
    else:
        model.load_state_dict(state['model'])
    cache = VQTargetCache(args['vq_target_cache'])
    bundle = build_train_val_test_dataloaders(db_path=args['db'], seq_len=args['seq_len'], stride=1,
        enforce_same_label=True, val_ratio=args['val_ratio'], test_ratio=args['test_ratio'], seed=args['seed'],
        batch_size=512, num_workers=args['num_workers'], pin_memory=True, drop_last=True,
        load_into_memory=False, normalize=True, norm_mean=mean, norm_std=std,
        persistent_workers=True, prefetch_factor=args['prefetch_factor'])
    bundle.train_loader.collate_fn = trainer.controller_collate
    pool = TrainStyleRecipePool(db=args['db'], model=model, cache=cache, mean=mean, std=std,
        frames=240, exemplars=5, exemplar_choices=[1,3,5], bank_size=64, seed=42, bank_max_entries=131072)
    bank = StyleDonorBank(args['db'], window=16, windows_per_clip=16, device=device)
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
        lr=5e-4 if opts.practical else state['optimizer']['param_groups'][0]['lr'], weight_decay=1e-4, fused=True)
    if not opts.practical:
        optimizer.load_state_dict(state['optimizer'])
        trainer._move_optimizer_state_to_device(optimizer, device)
        restore_rng_state(state['rng_state'])
    kwargs = dict(model=model, loader=bundle.train_loader, device=device, prediction_mode='target',
        recon_weight=0., style_hist_weight=.02, style_entropy_weight=.003, noise_std=1.,
        prev_latent_noise_std=.3, prev_motion_noise_std=.2, prev_latent_dropout=0., prev_motion_dropout=0.,
        solver_steps=8, optimizer=optimizer, vq_target_cache=cache, cache_vqvae=vq, grad_clip=1.,
        log_interval=1000, epoch=4, total_epochs=150, split='profile', decouple_prob=.3,
        norm_mean=mean, norm_std=std, microbatch_size=512, recipe_pool=pool, recipe_probability=1.,
        history_noise_mode='structured', history_noise_probability=.3, history_noise_start_epoch=51,
        donor_bank=bank)
    if opts.practical:
        kwargs.update(epoch=5, decouple_prob=0., history_style_probability=.3, history_mask_probability=.2,
            history_condition_warmup_epochs=5, flow_low_t_probability=.5, flow_low_t_max=.2)
    if opts.verify:
        old_bank=before('reference_donor','style_donor_bank.py').StyleDonorBank(
            args['db'],window=16,windows_per_clip=16,device=device)
        old_model=before('arch.reference_controller','flowmatch_vqvae_controller.py').build_flowmatch_controller_from_config(
            args,vqvae=copy.deepcopy(vq),num_styles=args['num_styles']).to(device)
        old_model.load_state_dict(state['model'])
        old_pool=before('reference_prior','style_code_prior.py').TrainStyleRecipePool(
            db=args['db'],model=old_model,cache=cache,mean=mean,std=std,frames=240,
            exemplars=5,exemplar_choices=[1,3,5],bank_size=64,seed=42,bank_max_entries=131072)
        trainer._seed_loader(bundle.train_loader,seed=42,epoch=4)
        maxima={'loss_max_abs':0.,'gradient_max_abs':0.,'histogram_max_abs':0.}
        for number,batch in enumerate(bundle.train_loader):
            if number==16:break
            start_rng=rng_state()
            x=batch['x'].to(device);labels=batch['label'].to(device)
            ids=batch['start'][:,None]+torch.arange(2)
            latents=cache.lookup_latents(ids.flatten(),vqvae=vq,device=device).reshape(512,2,-1)
            outputs=[]
            for current,current_bank,current_pool in ((old_model,old_bank,old_pool),(model,bank,pool)):
                restore_rng_state(start_rng);current.train();current.zero_grad(set_to_none=True)
                target,latent,recon,changed,entries,stats=current_bank.targets(x_window=x,labels=labels,
                    latents=latents,starts=batch['start'],segment_ids=batch['segment_id'],
                    norm_mean=mean,norm_std=std,frame_latent_fn=current.frame_latent,probability=.3)
                source=[bundle.train_dataset.segments[i]['source_entry_id'] for i in batch['segment_id'].tolist()]
                histogram,_=current_pool.sample(target,probability=1.,require_all=True,
                    per_sample_exclusions=[{a,b} for a,b in zip(source,entries)])
                extra={'clip_histograms_validated':True} if current is model else {}
                loss=current.compute_loss(x_curr=x[:,0],x_next=x[:,1],style_label=None,prior_labels=target,
                    clip_histograms=histogram,prev_latent=latents[:,0],target_latent=latent[:,0],
                    style_hist_weight=.02,style_entropy_weight=.003,recon_weight=0.,
                    history_noise_mode='structured',history_noise_probability=0. if number%2==0 else .3,
                    prev_latent_noise_std=.3,prev_motion_noise_std=.2,history_root_noise_std=.05,**extra)
                loss['loss'].backward()
                outputs.append((target,latent,recon,changed,entries,histogram,loss,rng_state(),
                    {k:p.grad.clone() for k,p in current.named_parameters() if p.grad is not None}))
            a,b=outputs
            for index in (0,1,2,3,5): torch.testing.assert_close(a[index],b[index],atol=0,rtol=0)
            assert a[4]==b[4]
            torch.testing.assert_close(a[7]['torch'],b[7]['torch'],atol=0,rtol=0)
            for u,v in zip(a[7]['cuda'],b[7]['cuda']):torch.testing.assert_close(u,v,atol=0,rtol=0)
            for key in a[6]:
                torch.testing.assert_close(a[6][key],b[6][key],atol=2e-6,rtol=1e-5)
                maxima['loss_max_abs']=max(maxima['loss_max_abs'],(a[6][key]-b[6][key]).abs().max().item())
            for key in a[8]:
                torch.testing.assert_close(a[8][key],b[8][key],atol=2e-6,rtol=1e-5)
                maxima['gradient_max_abs']=max(maxima['gradient_max_abs'],(a[8][key]-b[8][key]).abs().max().item())
        result=dict(real_batches=16,batch_size=512,**maxima, donor_histogram_rng_exact=True)
        (Path(__file__).parent/'equivalence.json').write_text(json.dumps(result,indent=2))
        print(json.dumps(result,indent=2));return
    # Timed region reuses the exact same batches/profile keys: measure warm steady-state,
    # as epoch 2+ have >99.99% recipe cache hits. Profiling steps are discarded afterwards.
    benchmark_rng = rng_state()
    setup_seconds = time.perf_counter() - setup_started
    trainer._seed_loader(bundle.train_loader, seed=42, epoch=kwargs['epoch'])
    cold_t0 = time.perf_counter()
    warmup_batches = opts.warmup_batches if opts.practical else max(64, opts.batches)
    trainer._run_epoch(**kwargs, max_batches=warmup_batches)
    torch.cuda.synchronize()
    cold_seconds = time.perf_counter() - cold_t0
    restore_rng_state(benchmark_rng)
    trainer._seed_loader(bundle.train_loader, seed=42, epoch=kwargs['epoch'])
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    metrics = trainer._run_epoch(**kwargs, max_batches=opts.batches)
    torch.cuda.synchronize()
    result = dict(name=opts.name, batches=opts.batches, seconds=time.perf_counter()-t0,
                  reference_current=opts.reference_current,
                  cpu_threads=torch.get_num_threads(), setup_seconds=setup_seconds,
                  math_attention=opts.math_attention,
                  checkpoint_epoch=None if opts.practical else state['epoch'],
                  initialization='from_scratch' if opts.practical else 'checkpoint',
                  warmup_updates=warmup_batches,
                  device=torch.cuda.get_device_name(), fp32=True, tf32=False,
                  cold_ms_per_update=cold_seconds*1000/warmup_batches,
                  peak_memory_mb=torch.cuda.max_memory_allocated()/2**20, metrics=metrics)
    result['ms_per_update'] = result['seconds']*1000/opts.batches
    if opts.practical:
        assert metrics['gt_target_fraction'] == 1. and metrics['decoupled_fraction'] == 0.
        assert metrics['recipe_fraction'] == 1. and metrics['recipe_shortfall_fraction'] == 0.
        assert sum(metrics[k+'_samples'] for k in ('clean_history', 'mixed_style_history', 'masked_history')) == metrics['num_samples']
        assert all(p.grad is None for p in model.vqvae.parameters())
        assert state_fingerprint(model.vqvae.state_dict()) == frozen_before
        assert all(p.dtype == torch.float32 for p in model.parameters())
        assert not torch.backends.cuda.matmul.allow_tf32
        result['checks'] = dict(gt_targets=True, frozen_vq_unchanged=True, decoder_and_solver_unused=True,
            fp32_parameters=True, full_task_accounting=True, optimizer_updates=warmup_batches+opts.batches)
    if opts.profile:
        originals=[]
        def mark(obj, name, label):
            original=getattr(obj,name); originals.append((obj,name,original))
            def wrapped(*a,**k):
                with torch.profiler.record_function(label): return original(*a,**k)
            setattr(obj,name,wrapped)
        mark(bank,'perturb_history' if opts.practical else 'targets','stage_donor')
        mark(pool,'sample','stage_recipe')
        mark(model,'compute_loss','stage_forward_loss')
        mark(cache,'lookup_latents','stage_cache')
        mark(optimizer,'step','stage_optimizer')
        restore_rng_state(benchmark_rng)
        trainer._seed_loader(bundle.train_loader, seed=42, epoch=kwargs['epoch'])
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
            trainer._run_epoch(**kwargs,max_batches=16)
        for obj,name,original in originals: setattr(obj,name,original)
        (Path(__file__).parent/(opts.name+'_profile.txt')).write_text(
            prof.key_averages().table(sort_by='self_cpu_time_total', row_limit=35)+'\n'+
            prof.key_averages().table(sort_by='self_cuda_time_total', row_limit=35))
        result['stages']={e.key:dict(cpu_ms=e.cpu_time_total/1000, self_cpu_ms=e.self_cpu_time_total/1000,
            cuda_ms=e.device_time_total/1000) for e in prof.key_averages() if e.key.startswith('stage_') and e.cpu_time_total > 0}
        trace = Path('/tmp')/(opts.name+'_trace.json')
        prof.export_chrome_trace(str(trace))
    (Path(__file__).parent/(opts.name+'.json')).write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='metrics'},indent=2), flush=True)


if __name__=='__main__': main()
