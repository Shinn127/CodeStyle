"""Explicit, bounded preparation/training/evaluation entrypoint; never runs on import."""
from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def commands(args):
    vq_dir = ROOT / 'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep'
    vq = vq_dir / 'best.pt'; norm = vq_dir / 'norm_stats.npz'
    cache = ROOT / 'cache/vq_targets_vq150ep_repair_v2'
    prior = ROOT / 'cache/style_code_prior_vq150ep_repair_v2.npz'
    db = ROOT / 'database_100sty_375_memmap'
    def python(script, *parts):
        return [sys.executable, str(ROOT / script), *map(str, parts)]
    preparation = [python('precompute_vq_targets.py', '--db', db, '--vqvae-ckpt', vq,
        '--norm-stats', norm, '--out-dir', cache, '--device', args.device,
        '--matmul-precision', 'highest', '--chunk-rows', 4096),
        python('precompute_style_code_prior.py', '--db', db, '--vq-target-cache', cache,
               '--out', prior, '--split', 'train', '--style-num-slots', 8, '--smoothing', 1)]
    common = ['--db', db, '--vqvae-ckpt', vq, '--norm-stats', norm, '--vq-target-cache', cache,
        '--style-code-prior', prior, '--prediction-mode', 'target', '--flow-loss-space', 'normalized',
        '--epochs', 50, '--batch-size', 512, '--seed', 42, '--device', args.device,
        '--solver-steps', 8, '--noise-std', 1, '--prev-latent-noise-std', .3, '--prev-motion-noise-std', .3,
        '--recon-weight', .1, '--style-hist-weight', .02, '--style-entropy-weight', .02,
        '--style-consistency-weight', 0, '--dropout', 0, '--flow-hidden-dim', 256,
        '--flow-layers', 2, '--flow-ffn-dim', 1024, '--matmul-precision', 'highest', '--no-tf32',
        '--no-cudnn-benchmark', '--style-selector-topk', 4, '--style-selector-temperature', 1,
        '--style-prior-loss', 'dense', '--weight-decay', .0001, '--grad-clip', 1,
        '--style-proto-normalization', 'layernorm', '--style-selector-init', 'random', '--recipe-prob', 0,
        '--min-lr', .00001, '--prev-latent-dropout', 0, '--prev-motion-dropout', 0,
        '--inference-requantize', '--inference-latent-clip', '--save-every', 5,
        '--rollout-val-every', 5, '--microbatch-size', args.microbatch_size]
    stages = [args.output / label for label in 'ABC']
    training = []
    for i, out in enumerate(stages):
        extra = ['--out-dir', out, '--seq-len', 2 if i == 0 else 3,
            '--unroll-steps', 1 if i == 0 else 2, '--lr', .0005 if i == 0 else .0001,
            '--decouple-prob', .3 if i == 2 else 0, '--decouple-latent', 'matched_root',
            '--root-recon-weight', .1 if i == 2 else 0]
        if (out / 'latest.pt').exists():
            extra += ['--resume', out / 'latest.pt']
        elif i:
            extra += ['--init-ckpt', stages[i - 1] / 'best.pt']
        training.append(python('train_flowmatch_vqvae_controller.py', *common, *extra))
    evaluation = [python('analysis/evaluate_repair_protocol.py', '--runs',
        *[out / 'best.pt' for out in stages], '--out', args.output / 'evaluation', '--device', args.device)]
    return preparation, training, evaluation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['prepare', 'train', 'evaluate', 'all'], required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'checkpoints/flowmatch_repair_v2')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--microbatch-size', type=int, choices=[128, 256, 512], default=512)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(); args.output = args.output.resolve()
    preparation, training, evaluation = commands(args)
    requested = (preparation if args.mode in ('prepare', 'all') else []) + (training if args.mode in ('train', 'all') else []) + (evaluation if args.mode in ('evaluate', 'all') else [])
    for command in requested:
        print(shlex.join(command), flush=True)
        if args.dry_run:
            continue
        if 'precompute_vq_targets.py' in command[1] and (ROOT / 'cache/vq_targets_vq150ep_repair_v2/meta.json').exists():
            sys.path.insert(0, str(ROOT))
            from Utils.vq_target_cache import VQTargetCache
            from Utils.reproducibility import artifact_fingerprints
            directory = ROOT / 'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep'
            cache = VQTargetCache(ROOT / 'cache/vq_targets_vq150ep_repair_v2')
            cache.validate(fingerprints=artifact_fingerprints(ROOT / 'database_100sty_375_memmap', directory / 'best.pt', directory / 'norm_stats.npz'))
            continue
        if 'precompute_style_code_prior.py' in command[1] and (ROOT / 'cache/style_code_prior_vq150ep_repair_v2.npz').exists():
            sys.path.insert(0, str(ROOT))
            from Utils.style_code_prior import load_style_code_prior
            from Utils.vq_target_cache import VQTargetCache
            prior = load_style_code_prior(ROOT / 'cache/style_code_prior_vq150ep_repair_v2.npz')
            cache = VQTargetCache(ROOT / 'cache/vq_targets_vq150ep_repair_v2')
            if prior.get('fingerprints') != cache.meta.fingerprints or prior.get('cache_sha256') != cache.meta.indices_sha256:
                raise ValueError('Existing repair prior/cache differ; preserve them and select a new artifact directory')
            continue
        if 'train_flowmatch_vqvae_controller.py' in command[1]:
            out = Path(command[command.index('--out-dir') + 1])
            if (out / 'latest.pt').exists():
                import torch
                cp = torch.load(out / 'latest.pt', map_location='cpu', weights_only=False)
                if cp.get('implementation_version') != 2 or cp.get('args', {}).get('epochs') != 50:
                    raise ValueError('Existing stage is not a compatible bounded 50-epoch run')
                if cp['epoch'] >= 50:
                    if not (out / 'best.pt').exists():
                        raise ValueError('Completed stage lacks validation-selected best.pt')
                    required = {'prediction_mode': 'target', 'flow_loss_space': 'normalized', 'seed': 42,
                        'batch_size': 512, 'style_consistency_weight': 0, 'solver_steps': 8,
                        'inference_requantize': True, 'inference_latent_clip': True}
                    stage = 'ABC'.index(out.name)
                    required.update(seq_len=2 if stage == 0 else 3, unroll_steps=1 if stage == 0 else 2,
                        decouple_prob=.3 if stage == 2 else 0., root_recon_weight=.1 if stage == 2 else 0.)
                    if any(cp['args'].get(key) != value for key, value in required.items()) or not cp.get('selection'):
                        raise ValueError('Completed stage differs from the fixed A/B/C protocol')
                    continue
        subprocess.run(command, check=True, cwd=ROOT)


if __name__ == '__main__':
    main()
