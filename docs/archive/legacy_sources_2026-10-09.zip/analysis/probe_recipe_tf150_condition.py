"""Small CPU/FP32 validation TF controls; oracle history is diagnostic, never a benchmark."""
from pathlib import Path
import json
import sys
import time

import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from Utils.motion_eval import load_motion_model
from Utils.runtime import load_norm_stats
from Utils.vq_target_cache import VQTargetCache
from Utils.style_code_prior import sparse_code_histogram
from Utils.reproducibility import case_noise_plan,state_fingerprint,file_sha256
from Utils.fid_feature_extractor import build_fid_feature_extractor_from_checkpoint
from evaluate_minor_revision_generalization import _classifier_stats,_root_ade_cm

OUT=ROOT/'analysis/recipe_tf150_results_2026-10-07'


def main():
    torch.set_num_threads(2);torch.set_float32_matmul_precision('highest');torch.manual_seed(42)
    ckpt=ROOT/'checkpoints/flowmatch_recipe_tf150/epoch_0150.pt'
    model=load_motion_model(model_name='flowmatch_target',ckpt_path=ckpt,num_styles=90).eval()
    before=state_fingerprint(model.vqvae.state_dict());cache=VQTargetCache(ROOT/'cache/vq_targets_vq150ep_repair_v2')
    mean,std=load_norm_stats(ROOT/'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/norm_stats.npz')
    db=ROOT/'database_100sty_375_memmap';meta=json.loads((db/'meta.json').read_text());segments=json.loads((db/'segments.json').read_text())
    raw=np.memmap(db/'X.f32',mode='r',dtype=np.float32,shape=(meta['num_frames'],375));names=json.loads((db/'StyleNames.json').read_text())
    classifier,clf_meta=build_fid_feature_extractor_from_checkpoint(ROOT/'checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth',map_location='cpu')
    classifier.eval();class_names=clf_meta['class_names']
    cases=json.loads((ROOT/'eval_results/recipe_tf150_val_cases.json').read_text())['horizons']['240']
    picked=np.random.default_rng(42).choice(len(cases),8,replace=False)
    sources=[cases[int(i)] for i in picked]
    target_names=['BigSteps','March','Skip','Morris','Teapot','OnPhoneLeft','WildArms','Zombie']
    target_names=[names[row['source_label']] for row in sources]+target_names
    sources=sources+sources
    targets=[class_names.index(name) for name in target_names]
    source_raw=np.stack([raw[row['source_start']:row['source_start']+241] for row in sources])
    x=torch.from_numpy((source_raw-mean)/std)
    plans=json.loads((ROOT/'eval_results/recipe_tf150_val_e0150_n5/minor_revision_generalization_summary.json').read_text())['config']['recipe_meta']['chosen_clips']
    probabilities={}
    for record in plans:
        codes=np.concatenate([np.asarray(cache.indices[c['frame_start']:c['frame_start']+c['frames']],dtype=np.int64) for c in record['clips']])
        probabilities[names[record['target_label']]]=sparse_code_histogram(codes,selected_slots=model.selected_style_slots,num_embeddings=2048,topk=4)
    oracle_refs={}
    for path in sorted((ROOT/'eval_results/unseen_tf240_recipe_ep150/recipes').glob('*.json')):
        data=json.loads(path.read_text());p=np.zeros((8,2048),np.float32)
        for item in data['slots']:p[list(model.selected_style_slots).index(item['slot']),item['codes']]=item['weights']
        probabilities[data['metadata']['style_name']]=p
    unseen_db=ROOT/'database_100sty_375_memmap_zeroshot'
    u_meta=json.loads((unseen_db/'meta.json').read_text());u_segments=json.loads((unseen_db/'segments.json').read_text())
    u_raw=np.memmap(unseen_db/'X.f32',mode='r',dtype=np.float32,shape=(u_meta['num_frames'],375))
    u_names=json.loads((unseen_db/'StyleNames.json').read_text())
    unseen_plans=json.loads((ROOT/'eval_results/unseen_tf240_recipe_ep150/case_manifest.json').read_text())['recipes']
    for i,name in enumerate(target_names):
        if i<8:oracle_refs[i]=np.array(source_raw[i,:-1],copy=True);continue
        if name in names:
            s=next(s for s in segments if s['style_name']==name and s['split']=='val' and not s['mirror'])
            start=s['frame_start']+(s['num_frames']-240)//2
            oracle_refs[i]=np.array(raw[start:start+240],copy=True)
        else:
            plan=next(p for p in unseen_plans if p['style_name']==name)
            c=next(c for c in plan['clips'] if c['role']=='reference')
            oracle_refs[i]=np.array(u_raw[c['start']:c['start']+240],copy=True)
    probs=torch.from_numpy(np.stack([probabilities[name] for name in target_names]))
    noise=case_noise_plan(model,[r['source_start'] for r in sources],targets,241,seed=42,noise_std=1.)
    ids=torch.tensor([[r['source_start']+k for k in range(241)] for r in sources])
    latents=cache.lookup_latents(ids.flatten(),vqvae=model.vqvae,device=torch.device('cpu')).reshape(16,241,128)
    current=x[:,:-1].reshape(-1,375);previous=latents[:,:-1].reshape(-1,128)
    hybrid_raw=np.stack([oracle_refs[i] for i in range(16)])
    # Target-style GT history with source root, trajectory and physically corrected velocity.
    donor_motion=hybrid_raw[:,:,84:];source_root=source_raw[:,:-1,84:87]
    delta=source_root-donor_motion[:,:,:3]
    translation=delta.copy();translation[:,:,1]=0
    omega=np.zeros_like(delta);omega[:,:,1]=np.deg2rad(delta[:,:,1])
    positions=donor_motion[:,:,3:75].reshape(16,240,24,3)
    donor_motion[:,:,219:291]+=(translation[:,:,None]+np.cross(omega[:,:,None],positions)).reshape(16,240,72)
    donor_motion[:,:,:3]=source_root;hybrid_raw[:,:,:84]=source_raw[:,:-1,:84]
    hybrid=torch.from_numpy((hybrid_raw-mean)/std).reshape(-1,375)
    summaries={}
    def summarize(name,motions):
        generated=source_raw.copy();generated[:,1:,84:]=motions.reshape(16,240,291).numpy()*std[84:]+mean[84:]
        pred,conf,_=_classifier_stats(classifier,generated[:,1:],np.asarray(targets),device=torch.device('cpu'),
            classifier_window=240,classifier_stride=240,classifier_batch_size=16,joint_set=clf_meta['joint_set'])
        root_error=generated[:,1:,84:87]-source_raw[:,1:,84:87]
        groups={}
        for group,span in [('matched',slice(0,8)),('cross_dynamic',slice(8,12)),('cross_static',slice(12,14)),('ood',slice(14,16))]:
            groups[group]=dict(n=len(pred[span]),accuracy_pct=float((pred[span]==np.asarray(targets)[span]).mean()*100),
                root_ade_cm=float(np.mean([_root_ade_cm(ref,out,dt=1/60,context_frames=1) for ref,out in zip(source_raw[span],generated[span])])),
                mean_root_error=root_error[span].mean(axis=(0,1)).tolist())
        summaries[name]=dict(groups=groups,predicted_names=[class_names[int(i)] for i in pred],target_confidence=conf.tolist())
        print(name,groups,flush=True)
    with torch.no_grad():
        feature=model.encode_conditions(x_curr=x[:,0],style_label=None,manual_style_probs=probs)[2]
        features=feature[:,None].expand(-1,240,-1).reshape(-1,64)
        zs=[];begin=time.perf_counter()
        for start in range(0,len(current),512):
            zs.append(model.sample_latent(x_curr=current[start:start+512],style_label=None,prev_latent=previous[start:start+512],
                style_feature=features[start:start+512],z0=noise.reshape(-1,128)[start:start+512],num_steps=8,noise_std=1.))
        zs=torch.cat(zs);print('Source-history Euler finished',time.perf_counter()-begin,flush=True)
        for name,clip,quant in [('continuous',False,False),('clip_only',True,False),('clip_quantized',True,True)]:
            motions=[model.feedback_state(zs[start:start+512],latent_clip=clip,requantize=quant)[0] for start in range(0,len(zs),512)]
            summarize(name,torch.cat(motions))
        next_z=latents[:,1:].reshape(-1,128)
        summarize('source_gt_next_quantized_ae',torch.cat([model.vqvae.decode(next_z[start:start+512]) for start in range(0,len(next_z),512)]))
        h_previous=torch.cat([model.frame_latent(hybrid[start:start+512]) for start in range(0,len(hybrid),512)])
        summarize('oracle_history_quantized_ae',torch.cat([model.vqvae.decode(h_previous[start:start+512]) for start in range(0,len(h_previous),512)]))
        zs=[]
        for start in range(0,len(hybrid),512):
            zs.append(model.sample_latent(x_curr=hybrid[start:start+512],style_label=None,prev_latent=h_previous[start:start+512],
                style_feature=features[start:start+512],z0=noise.reshape(-1,128)[start:start+512],num_steps=8,noise_std=1.))
        zs=torch.cat(zs)
        summarize('oracle_target_style_history',torch.cat([model.feedback_state(zs[start:start+512])[0] for start in range(0,len(zs),512)]))
    assert state_fingerprint(model.vqvae.state_dict())==before
    result=dict(checkpoint_sha256=file_sha256(ckpt),seed=42,split='validation',device='CPU FP32 highest',
        generated_frames=240,ode_steps=8,source_starts=[r['source_start'] for r in sources],target_names=target_names,
        vq_unchanged=True,summaries=summaries,
        limits='16 tiny diagnostic cases, no rollout/updates. Cached GPU GT latents, CPU field/decoder. Source GT AE accuracy is computed against requested targets: only root reconstruction is used as a baseline, cross/OOD target accuracy there is not an AE quality metric. Oracle history supplies actual target-style motion every step: diagnostic only, not unseen generation or a replacement evaluation protocol.')
    (OUT/'condition_probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
