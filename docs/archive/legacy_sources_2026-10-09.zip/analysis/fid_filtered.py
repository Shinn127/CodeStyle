"""FID for temporally-filtered predictions, on the paper's exact window set.

The official script has no filter option, so this replicates its FID pipeline
(extractor features per 60-frame sequence + the same bootstrap CI) for the filtered decode.
Used to complete the "all seven metrics better" claim when the F.S. fix is the 3-tap decoder
filter rather than a retrained model.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

NEWCODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEWCODE))

from Utils.fid_feature_extractor import (  # noqa: E402
    build_motion_feature_classifier_from_checkpoint,
    motion375_clip_to_classifier_input,
)
from Utils.model_loading import build_vqvae_from_checkpoint  # noqa: E402
from Utils.motion_eval import MotionEvalConfig, frechet_distance  # noqa: E402

DB = NEWCODE / "database_100sty_375_memmap"
CFG = MotionEvalConfig()
WINDOW, STRIDE = 60, 30
K3 = torch.tensor([0.25, 0.5, 0.25])


def smooth_time(x: torch.Tensor, kernel: torch.Tensor) -> torch.Tensor:
    pad = kernel.numel() // 2
    xt = x.transpose(1, 2)
    xt = F.pad(xt, (pad, pad), mode="replicate")
    weight = kernel.to(device=x.device, dtype=x.dtype).view(1, 1, -1).expand(x.size(-1), 1, -1)
    return F.conv1d(xt, weight, groups=x.size(-1)).transpose(1, 2)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=Path, required=True)
    ap.add_argument("--extractor", type=Path, required=True)
    ap.add_argument("--batch-frames", type=int, default=64)
    ap.add_argument("--bootstrap", type=int, default=100)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    device = torch.device(args.device)
    model = build_vqvae_from_checkpoint(args.ckpt, map_location="cpu").to(device).eval()
    extractor, _ = build_motion_feature_classifier_from_checkpoint(args.extractor, map_location="cpu")
    extractor = extractor.to(device).eval()
    norm = np.load(args.ckpt.parent / "norm_stats.npz")
    mean, std = norm["mean"], norm["std"]

    meta = json.loads((DB / "meta.json").read_text())
    segs = json.loads((DB / "segments.json").read_text())
    x = np.memmap(DB / "X.f32", dtype=np.float32, mode="r", shape=(meta["num_frames"], 375))
    spans = []
    for seg in segs:
        if seg.get("split") != "test":
            continue
        last = seg["frame_start"] + seg["num_frames"] - WINDOW
        spans.extend((s, WINDOW) for s in range(seg["frame_start"], last + 1, STRIDE))
    print(f"windows: {len(spans):,}", flush=True)

    ref_feats, raw_feats, filt_feats = [], [], []
    for begin in range(0, len(spans), args.batch_frames):
        chunk = spans[begin : begin + args.batch_frames]
        raw = np.stack([np.array(x[s : s + w], dtype=np.float32) for s, w in chunk])
        batch = torch.from_numpy(((raw - mean) / std).astype(np.float32)).to(device)
        with torch.no_grad():
            ae = model.decode(model.encode_pre_vq(batch), from_indices=False)
            filt = smooth_time(ae, K3)
            preds = {"raw": ae, "filt": filt}
            feats = {"ref": [], "raw": [], "filt": []}
            feats["ref"] = extractor.get_feats(motion375_clip_to_classifier_input(raw).to(device))
            for tag, motion in preds.items():
                pred = batch.clone()
                pred[..., 84:] = motion
                pred_raw = (pred.detach().cpu().numpy() * std + mean).astype(np.float32)
                feats[tag] = extractor.get_feats(motion375_clip_to_classifier_input(pred_raw).to(device))
        ref_feats.append(feats["ref"].detach().cpu().numpy())
        raw_feats.append(feats["raw"].detach().cpu().numpy())
        filt_feats.append(feats["filt"].detach().cpu().numpy())
        if begin % (args.batch_frames * 20) == 0:
            print(f"  {begin + len(chunk):,}/{len(spans):,}", flush=True)

    ref = np.concatenate(ref_feats, axis=0)
    raw = np.concatenate(raw_feats, axis=0)
    filt = np.concatenate(filt_feats, axis=0)
    out = {"windows": len(spans), "real_frames": int(ref.shape[0])}
    rng = np.random.default_rng(42)
    n = ref.shape[0]
    for tag, pred in (("raw", raw), ("filt", filt)):
        value = float(frechet_distance(ref, pred, eps=CFG.fid_eps))
        boots = []
        for _ in range(args.bootstrap):
            idx = rng.integers(0, n, size=n)
            boots.append(frechet_distance(ref[idx], pred[idx], eps=CFG.fid_eps))
        out[tag] = value
        out[tag + "_ci95"] = float(1.96 * np.std(boots))
        print(f"FID {tag}: {value:.4f} ± {out[tag + '_ci95']:.4f}", flush=True)
    print(f"paper FID: 3.060 ± 0.390")
    args.out.write_text(json.dumps(out, indent=2))
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
