# NewCode 实现审计：style prior 与 flow matching 控制器

日期：2026-10-05。对象：用户提供的接收稿 `MM-2025-11-0162.R2_Ma.pdf` 和当前磁盘上的 NewCode。

**结论：style prior 的计数与概率计算基本正确；控制器存在确定的训练缺陷，近期实验配置也未对齐论文主方法。先修实现、固定协议，比继续提高 decouple probability 或延长训练更有价值。**

本轮只新增分析报告与检查结果，没有修改模型、训练脚本、已有实验文件或 checkpoint，没有启动训练。下文“已确认”来自代码和本轮检查；已有实验数字来自磁盘上的结果文件，未重新跑完整评估。当前源代码不能自动代表每个历史 checkpoint 训练时的源代码，历史因果判断需要当时的代码版本支持。

## 1. 实际数据与模型链路

### 1.1 数据行的时间含义

[generate_database_100sty.py:509](/home/shinn/桌面/multimedia/revision/NewCode/generate_database_100sty.py:509) 明确使用 `previous_ids = frame_ids - 1`。第 i 行是：

```text
x[i] = [T_i, S_(i-1)]                         375 = 84 + 291
T_i: 12 个时间采样 × 7 个轨迹通道
S: root vx / yaw rate / vz + 24 joints 的 position / rotation xy / velocity
```

位置为米，线速度为米/秒，yaw rate 为度/秒；评估按 60 fps 积分 root。这里的 root 分量是速度，不能直接当成每帧位移。

当前主库有 7,068,516 帧、90 个 IND styles、1,458 个 segments；另外 10 styles 在 zero-shot 库。train/val/test 帧数分别为 5,714,320 / 746,384 / 607,812。729 个 `source_entry_id` 及其镜像没有跨 split，检查结果为 0/729；窗口限制在 segment 内。`dataset.py` 使用预先保存的 clip split 时，命令行的 split seed/ratio 不重新决定划分。

归一化由 train windows 计算；主控制器通过 VQ cache metadata 读取 VQ 的 normalization，链路基本一致。

### 1.2 VQ、先验与 style token

```text
归一化 x[i]
  → frozen VQ encoder
  → z_e: 128 维 = 32 slots × 4 dims
  → shared codebook: 2048 × 4
  → z_q 与 32 个 code indices

train indices + labels + segments
  → counts[90,32,2048]
  → Laplace-smoothed prior + global prior
  → 各 slot 的 mean-style JS saliency
  → 选 Ω 中 8 个 slots

style label
  → embedding(128) + MLP
  → logits[8,2048] → softmax → top-4 → renormalize
  → 各 slot 对 shared codebook 加权求和
  → 8×4 = 32 维 prototype → LayerNorm + MLP → 64 维 style token
```

[StyleCodeSelector](/home/shinn/桌面/multimedia/revision/NewCode/arch/flowmatch_vqvae_controller.py:51) 没有直接覆盖生成 latent 的 8 个 slots；它把这些 slots 的原型作为条件给整个生成器。这与论文的“条件式 style selection”思路一致，也意味着 saliency 高不能保证该 slot 只编码风格。

当前 VQ 是逐帧的六层 `skip_cat_mlp`，不是论文的两帧 transformer encoder。用户已解决 VQ 阶段，本报告不建议首先重写它，但下游必须按当前 VQ 的实际量化路径建立基线。

### 1.3 Flow 训练与评估

[compute_loss](/home/shinn/桌面/multimedia/revision/NewCode/arch/flowmatch_vqvae_controller.py:707) 把相邻行作为 transition：上一行提供 `T_i, S_(i-1)` 与 previous latent，下一行提供 target latent 和 `S_i`。

生成器实际有 6 个 transformer tokens：`z_t / z_prev / motion291 / trajectory84 / style64 / time64`，hidden=256、2 layers、FFN=1024。所谓 content encoder 实际是 motion/traj 各自的 linear projection，未实现论文描述的独立两层 content MLP。

latent 采用两层尺度变换：全局标准差 g 用于居中缩放，各维 `transport_std = std_j/g` 用于噪声和 field output。

```text
a = (z_raw - mean) / g
source = transport_std × Gaussian noise
bridge = (1-t) × source + t × target
velocity mode: velocity = transport_std × field_output
target mode: target_pred = transport_std × field_output
             velocity = (target_pred - z_t) / max(1-t, eps)
```

Euler target 转 velocity 的实现与论文公式一致；8 steps 下最后采样时间为 7/8，不会触及 eps=0.001 的奇点。不要把复现问题归因于这个转换本身。需要注意 target loss 在各维 transport-normalized 空间算 MSE，velocity loss 在全局 normalized 空间算 MSE，两种模式除了时间参数化，还具有不同的维度权重。

普通训练使用真实 previous motion/latent，rollout 使用自己上一帧的输出；这是 exposure bias 的来源，但它不是下列实现缺陷的替代解释。

## 2. 已确认的优先问题

### A. Reconstruction loss 对控制器没有梯度

来源：[basic_vqvae_375to291.py:654](/home/shinn/桌面/multimedia/revision/NewCode/arch/basic_vqvae_375to291.py:654) 的 `decode()` 被 `@torch.no_grad()` 装饰；[flow controller:812](/home/shinn/桌面/multimedia/revision/NewCode/arch/flowmatch_vqvae_controller.py:812) 用这个接口计算 reconstruction loss。

冻结 decoder 的参数是正确的，但 decoder 对输入 latent 的导数必须保留。当前 `pred_motion.requires_grad=False`，因此 `L_rec` 只是一个数值项。默认 `recon_weight=0.1` 没有实现论文中 reconstruction supervision 的训练作用，却仍会影响 total loss 和 best checkpoint 选择。

本轮 CPU fixture 固定输入、参数与随机数后，`recon_weight=0` 和 `0.1` 的所有控制器参数梯度**逐项完全相同，最大差为 0**。直接调用 frozen `vqvae.decoder(z)` 可以保留 latent 梯度，VQ 参数仍可全部冻结；这是一个最小修复方向，不需要改 VQ 训练架构。

同一问题也切断了基于 `pred_motion` 的 style-consistency loss 到生成器的梯度。日志显示 loss 非零不能证明它正在训练模型。

### B. 近期实验训练的是 velocity，论文主方法是 target

来源：[CLI 默认值](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:905)、wrapper 和各 run 的 `config.json`。

下列当前 VQ150ep 系列的实际配置均为 `prediction_mode=velocity`：`prior_90st`、`decouple_p02/p03`、`retarget_p05/p07`、`retarget_p05_noise06_s25`、`goal_long`。实验名字中的 prior/retarget 不改变 prediction mode；`run_goal_pipeline.sh` 也没有显式传 target。

代码实现了 target mode，旧 `full_new` / `target_head10` 也有 target checkpoint，但它们使用旧 VQ/数据链路，不能代替当前主库与 VQ150ep 的 target baseline。

论文 Table 2 比较 target 与 velocity，并报告 target+requantize 的更低 jitter。当前 velocity 实验的好坏不足以评价论文主方法是否已经复现。

其他已知差异：论文 FFN=512，当前为 1024；论文写 cosine warm restarts，当前是 `CosineAnnealingLR`，没有 warm restart。这些属于配置/结构差异，优先级低于梯度缺陷。

### C. 自回归展开分支不能完成真实训练 batch

来源：[unrolled_flow_loss](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:172) 与 [_run_epoch:731](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:731)。

`unrolled_flow_loss()` 只聚合 6 个键，随后 `_run_epoch()` 按 `_metric_keys()` 读取 `style_consistency_loss`、latent norms，以及 target 模式的附加字段。第一处缺失即抛出 `KeyError: 'style_consistency_loss'`。本轮单 batch、`seq_len=3, unroll_steps=2` 的真实 `_run_epoch` fixture 已复现。

现有测试只检查展开函数有限值与有某些梯度，没有跑到真实 epoch 的日志聚合，因而测试通过不能证明这个训练入口可用。

### D. 展开反馈与评估时间轴错一帧

来源：[train_flowmatch_vqvae_controller.py:262](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:262)。

评估首步用 `x_window[:,0]`；生成第一帧后，下次条件应是 `[T_(i+1), generated S_i]`，即来自 `x_window[:,1,:84]` 的 trajectory。展开实现却取 `step+2`。

给 trajectory 第一维填入行编号的三步 trace：

```text
评估预期条件行：0, 1, 2
实际展开条件行：0, 2, 3
```

普通 one-step 训练和正常评估之间没有这个错位；缺陷限于新展开分支。

展开分支另外还有四处不一致：

- requantize feedback 只替换 latent，没有重新解码对应 motion，反馈中的 motion 与 latent 不再来自同一个状态。
- `--decouple-latent retarget` 在 window 分支没有生效；它直接复制 donor sequence latents。
- reconstruction targets 总是 `decode(target_zq)`，不是原始 GT motion；现有“steps=1 等于原目标”测试只比较 flow loss，未比较 reconstruction target。
- prior/entropy 权重只施加在第一步，然后 total 除以 steps，实际 regularization 随展开深度被削弱；style-consistency 分支被整个跳过。

这些问题需要一起修，不能只补上缺失的日志键后立即启动长训练。

### E. 随机 donor 解耦的目标与源轨迹存在直接冲突

来源：[apply_style_decoupling](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:287)。

它保留源 trajectory 和 previous pose，却随机选择另一 style 的样本，把整个 motion291 换成 donor motion。替换包括 **root vx/yaw/vz**，也包括不同动作、速度和 phase 下的关节状态。当前没有按 suffix/action、速度、heading、phase 匹配 donor。

`retarget` 做的是 `encode(source trajectory, donor motion)`，并未 retarget donor 的 root velocity 或关节动力学。把 trajectory 输入编码器不能保证 decoder 输出服从源轨迹；因为 VQ 训练监督的是 motion，合成组合本身也可能在训练分布之外。

**已确认事实**：训练目标的 root velocity 可以与保留的 source trajectory 冲突。**实验假设**：这种冲突、跨动作/phase 的跳变和 exposure bias 共同造成 Root ADE 恶化；各自贡献仍需受控实验分离。不能仅凭现有表格断言必须改 VQ 架构。

### F. 训练、评估与 re-quantization 状态不一致

论文 Algorithm 4 在生成后 quantize 再 decode。当前：

| 环节 | 实际路径 |
| --- | --- |
| flow target | frozen VQ 的 quantized latent |
| reconstruction prediction | continuous predicted latent → decoder |
| 普通评估默认 | continuous latent，`flow_requantize_z=False` |
| 展开默认 feedback | quantized latent + 原 continuous motion |

[Utils/motion_eval.py:576](/home/shinn/桌面/multimedia/revision/NewCode/Utils/motion_eval.py:576) 开 requantize 后先 decode，再 clip latent；若 clipping 改变该 code vector，反馈的 latent 与已经解码的 motion 也会不一致。正常 continuous 分支则在 clip 后再次 decode。

现有结果只能说明对这些 checkpoint 临时开 quantization 的效果，不能证明按论文一致路径训练后的 re-quantization 没有效果。论文训练 reconstruction 算法本来使用 continuous latent；若增加展开训练，则展开 feedback 应按目标部署/评估路径一致构造。

## 3. Style prior：哪些已验证，哪些仍有风险

本轮重新运行 `verify_style_code_prior.py --controller-ckpt ...prior_90st/best.pt --expect-entropy-floor 4.834`，**21/21 通过**。

| 检查 | 本轮结果 |
| --- | --- |
| 全量 counts 独立重算 | 5,898,240 个计数项，绝对误差总和 0 |
| prior/global prior/saliency 重算 | 最大误差不超过 4.43e-8 |
| 先验 split | train；5,714,320 帧 |
| selected slots Ω | `[4,9,10,17,18,20,23,24]`，与 saliency top-8 一致 |
| selected prior entropy floor | 4.8342 nats |
| selected prior top-4 mass | 平均 19.2566%，外部质量约 80.7% |
| dense KL(prior‖selector) | 0.3642 nats |
| selector top-4 与 prior top-4 overlap | 42.4% |

当前 `dense` 实际返回 cross entropy，而不是减去 target entropy 后的 KL；两者训练梯度相同。CE 的约 4.834 常数下界不能被当成“优化困难”或“强梯度支配”的证据。应该看 excess CE/KL、梯度和输出行为。

论文把 Laplace-positive prior 与 hard top-k distribution 直接做 forward KL，这个字面目标为无穷。旧 `legacy` 的 clamp 使数值有限，却给 top-k 外的 code logits 几乎没有有效学习信号。本轮四码两选 fixture：legacy 的两个未选 logits 梯度为精确 0，dense 则均有非零梯度。保留当前 dense 修复有理由。

但 dense supervision 与稀疏 token 并不等价：绝大多数 prior 概率质量未进入 token；flow loss 与 entropy 可以继续改变选码顺序。42.4% overlap、较低 dense KL 和较尖的 selector 可以同时成立。当前证据支持“计数实现正确、selector 学到一定分布”，还不支持“style token 已最优”或“content/style 已充分解耦”。

现有 `style_token_diagnostic.json` 显示均值 token 干预使 matched accuracy 从 68% 降至 13.5%。这说明模型依赖 token；**依赖 token 不等于能够在冲突的源运动上服从目标 style**。文档中“generator 忽略 token”的笼统表述需要收窄。

缓存还有一个需核实的数值问题：本轮用真实 VQ150ep 与相同 normalization，在 seed=42 随机 64 帧上做 CPU 编码，2,048 个 slot indices 中 21 个不同于已保存 cache。CPU online 与 float64 最近邻结果完全一致；发生差异的 cached code 与 CPU 最佳 code 的 squared-distance 差平均约 0.000199、最大约 0.001398，提示边界/精度效应，但尚未确认原因。本环境没有可用 CUDA，不能复查缓存生成时的 GPU 运算。

这不是“缓存已过期”的证据。外部 VQ150ep 与 controller 内嵌 VQ 的 state dict 完全一致，checkpoint 时间也早于 cache。后续应在相同 GPU、matmul precision、batch size 下抽样比较，再决定是否需要重建缓存。当前 cache validation 只有路径/shape，缺少内容 hash 与生成精度记录，同一路径文件被覆盖时不能有效检测。

## 4. 其他功能与评估口径

### 4.1 Style-consistency 分支暂不能作为改进依据

[style_consistency_loss:384](/home/shinn/桌面/multimedia/revision/NewCode/train_flowmatch_vqvae_controller.py:384) 对 motion291 使用 `mean[:291], std[:291]`；main 实际传入完整 375 维 stats，正确 motion stats 应为 `[84:]`。当前会拿 trajectory 的统计反归一化部分动作。

默认 frame classifier 是 100 classes，主生成器是 90 styles，main 又要求 class counts 精确相等，会直接拒绝默认配置。现有两个 classifier 的前 90 个 class names 与 DB 一致，所以应校验名称映射与目标范围，而非盲目要求输出类数相等。

除此之外还有上文的 decoder 梯度断开、展开时忽略该 loss、单帧 proxy 与 60-frame 报告指标不同的问题。此分支在近期 run 中 weight=0，不能解释这些 run 的主结果，但后续启用前必须修复。训练用分类器与报告用分类器最好保持独立。

### 4.2 Clip-style 功能与论文描述有差异

当前 learned style branch 只接收 label 或 manual probabilities，没有论文的两层 temporal style-clip encoder。`build_zeroshot_style_recipe.py` 对 exemplar 做逐帧 VQ，再用频率 top-k 构造 recipe。这是一条明确可用的 clip→recipe 路径，但不是论文 Eq. 3 描述的 learned clip encoder。

另一个已复现的接口缺陷：[StyleCodeSelector:123](/home/shinn/桌面/multimedia/revision/NewCode/arch/flowmatch_vqvae_controller.py:123) 在 manual probabilities 为 `[M,K]` 时把 batch 强制设为 1，不能同时接受 B>1 个 labels 共享同一个 recipe。评估外层宣称支持二维 recipe，实际会抛出 `Cannot align ... style labels with batch size 1`；三维 `[B,M,K]` 和单样本模拟不受这个缺陷影响。

### 4.3 表征指标不能直接作为量化控制器上界

[reconstruct_motion_batch:418](/home/shinn/桌面/multimedia/revision/NewCode/Utils/motion_eval.py:418) 对 `basic_vqvae` 使用 `encode_pre_vq → decode(z_e)`；训练期 `Utils/vqvae_eval.py` 用 `encode → decode(z_q)`。两条路径不同。

这不否定用户已经取得的 VQ 改进；但确认 downstream 上界时，应把 continuous AE、quantized AE、teacher-forced controller 和 rollout 四条路径并列评估。单用 continuous AE 的 91.33% style accuracy 不能完整排除量化环节。64 随机帧的 normalized motion MAE 分别为 0.06246 / 0.06660，仅是局部数值检查，不能充当完整 benchmark。

### 4.4 评估协议需要固定

- 当前 style classifier 为 100 classes、45 维 ybot15、60-frame window、含镜像；class names 映射通过检查。classifier 自身训练使用全量 clips，没有 train/test split。论文 real-motion 92.30% 与当前 96.40% 表明当前数值基准不完全一致，但不能只据此判断哪个协议有错。
- MPJPE 在积分 root 后的 global joints 上算；F.S. 与 Jitter 在 root-local joints 上算。特别是 F.S. 的 contact speed 与 toe displacement 都在 local frame，不能直接当作物理 world-space 足滑：世界空间固定的落地脚也会因 root 移动而在 local frame 移动。论文没有给出足够细节判定与旧指标是否一致。
- global pooled FID、按 style 聚合 FID、按 clip 聚合 FID 是不同统计量，不能混用数值。当前 baseline 的 global FID 为 36.17，style-FID 为 0.3377，量级相差并不等于代码必然错误。
- stride=30、window=60 的窗口有重叠，cross 的 5 个 targets 又共享 source。当前 CI 按 pair 独立计算，不能视为严格独立样本 CI；应按 source clip/源窗口聚类 bootstrap，并明确协议。
- controller 的 `best.pt` 由 teacher-forced val total loss 选取，不评估 cross control 或 long rollout。latents 的 mean/std/min/max 则从全库统计，包含 val/test；这属于 transductive normalization，应改用 train 或明确记录，不宜宣称所有统计仅来自 train。

## 5. 已有结果揭示的是风格与轨迹的权衡

以下数字来自现有 `minor_revision_generalization_summary.csv/json`，同为 seed=42、horizon=60、1,000 sources、每 source 5 targets、CAMDM100 mirror classifier，requantize=False；本轮未重跑。

| Run | matched acc | cross acc | matched Root ADE cm | cross Root ADE cm |
| --- | ---: | ---: | ---: | ---: |
| prior_90st，p=0，50ep | 64.90 | 10.44 | 1.348 | 1.790 |
| donor p=0.2，20ep | 67.80 | 57.14 | 3.930 | 9.292 |
| donor p=0.3，20ep | 72.20 | 66.62 | 4.104 | 9.406 |
| retarget p=0.5，25ep | 73.70 | 69.34 | 6.296 | 11.388 |
| retarget p=0.5，noise=0.6，25ep | 73.40 | 71.98 | 7.382 | 13.517 |
| 论文 Table 4 | 84.40 | 71.02 | 2.747 | 3.088 |

不能把 cross 接近 72% 视为已经接近论文联合结果：其 cross Root ADE 比论文值大约 4.4 倍。也不能从这些不同 p/epochs/noise 的 run 分离出纯粹的 retarget 收益。

普通 prior_90st rollout 的 MPJPE=5.952 cm 接近论文 Table 2 的约 6 cm，但 Jitter=0.833 cm、F.S.=1.015 cm，高于论文 target+requantize 的 0.348 / 0.600；既有实现差异，也有协议差异，需要分别验证。

## 6. 最小修复与验证顺序

1. **先恢复 reconstruction 到 latent 的梯度**，保留 VQ 参数冻结；验证仅启用 recon 时 flow/selector 获得非零梯度、VQ 参数无梯度。不要只测 total loss 能 backward。
2. **修好展开入口与 feedback 状态**：日志键、trajectory 行编号、quantized latent 与 motion 一致、retarget 参数真正生效、GT reconstruction target 与 regularizer 权重定义一致。运行真实单 batch `_run_epoch`，比较 rollout 的逐步条件 trace。
3. **建立当前 VQ150ep 的 target、p=0 基线**。固定 solver=8、seed、normalization、classifier 与 metric settings；分别报告 continuous/quantized teacher forcing 和 rollout。短训练确认 reconstruction 与 jitter 有改善后，再决定长训规模。
4. matched motion/control 稳定后，再研究 cross-style：优先按动作/速度/heading 匹配 donor，处理 root velocity 与源轨迹的矛盾，或做有明确约束的 cross-style objective。不要把全帧随机置换直接等同于 content/style disentanglement。
5. 保留现有统计正确的 prior；若还有瓶颈，再单独研究 sparse support/原型质量，不同时改 slots、top-k、temperature、decoder 和控制器。

本轮验证范围：prior 全量独立校验 21/21；相关现有单测 37 passed；额外 CPU fixtures 复现梯度断开、unroll epoch 报错、轨迹行错位和 shared recipe batch 问题。没有 CUDA 或完整训练验证，不承诺上述修复能恢复论文的具体数字。

检查结果：[IMPLEMENTATION_AUDIT_2026-10-05_checks.json](/home/shinn/桌面/multimedia/revision/NewCode/analysis/IMPLEMENTATION_AUDIT_2026-10-05_checks.json)。额外 fixture 脚本保存在 `/tmp/newcode_audit_checks_20261005.py`，可在 mcc 环境短时重跑。
