"""Reuse a compatible controller for bounded rollout recovery; prints one command unless --execute."""
from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis.run_repair_pipeline import commands
from Utils.runtime import load_checkpoint


def recovery_command(args, config):
    if config.get('prediction_mode') != 'target':
        raise ValueError('Recovery entry requires a compatible target checkpoint')
    if not 1 <= args.epochs <= 50 or not 2 <= args.unroll_steps <= 8:
        raise ValueError('Recovery is bounded to 1–50 epochs and 2–8 unroll steps')
    stage = 'C' if args.cross else 'B'
    _, stages, _ = commands(SimpleNamespace(output=args.output, device=args.device,
                                            microbatch_size=args.microbatch_size))
    command = stages[2 if args.cross else 1]
    def put(flag,value):
        command[command.index(flag)+1] = str(value)
    put('--epochs',args.epochs)
    put('--seq-len',args.unroll_steps+1)
    put('--unroll-steps',args.unroll_steps)
    put('--style-proto-normalization',config.get('style_proto_normalization','layernorm'))
    put('--style-selector-init',config.get('style_selector_init','random'))
    put('--style-entropy-weight',config.get('style_entropy_weight',.02))
    put('--recipe-prob',0)
    put('--rollout-val-every',1)
    # Reuse the source run's immutable artifacts rather than substituting a new VQ/prior.
    for flag,key in [('--db','db'),('--vqvae-ckpt','vqvae_ckpt'),('--norm-stats','norm_stats'),
                     ('--vq-target-cache','vq_target_cache'),('--style-code-prior','style_code_prior')]:
        if not config.get(key):
            raise ValueError(f'Recovery source must record {key}')
        put(flag,config[key])
    if '--resume' not in command:
        put('--init-ckpt',args.init_ckpt.resolve())
    command += ['--lr-schedule-epochs','50', '--train-feedback-context' if args.feedback_context else '--no-train-feedback-context']
    if config.get('rollout_val_classifier'):
        command += ['--rollout-val-classifier',str(config['rollout_val_classifier'])]
    # Preserve weight-compatible architecture and selector behavior from the source run.
    for key in ['style_dim','style_selector_hidden_dim','style_num_slots','flow_hidden_dim',
                'flow_layers','flow_ffn_dim','flow_heads','time_embed_dim','style_selector_topk',
                'style_selector_temperature','target_time_eps']:
        if key in config:
            flag = '--'+key.replace('_','-')
            if flag in command:
                put(flag,config[key])
            else:
                command += [flag,str(config[key])]
    return command, args.output/stage


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--init-ckpt',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=ROOT/'checkpoints/flowmatch_rollout_recovery')
    parser.add_argument('--epochs',type=int,default=5)
    parser.add_argument('--unroll-steps',type=int,default=4)
    parser.add_argument('--microbatch-size',type=int,choices=[128,256,512],default=512)
    parser.add_argument('--device',default='cuda')
    parser.add_argument('--cross',action='store_true',help='Use existing matched_root p=.3/root weight=.1; use a recovered matched model as init')
    parser.add_argument('--feedback-context',action=argparse.BooleanOptionalAction,default=True,
                        help='Condition on frozen-VQ reconstructed GT previous motion; disable for an unroll-only comparison')
    parser.add_argument('--execute',action='store_true')
    args = parser.parse_args(); args.output = args.output.resolve()
    source = load_checkpoint(args.init_ckpt)
    command,out = recovery_command(args,source['args'])
    print(shlex.join(command),flush=True)
    if not args.execute:
        return
    if (out/'latest.pt').exists():
        latest = load_checkpoint(out/'latest.pt')
        if latest['epoch'] >= args.epochs:
            required = dict(epochs=args.epochs,lr_schedule_epochs=50,seq_len=args.unroll_steps+1,
                unroll_steps=args.unroll_steps,microbatch_size=args.microbatch_size,
                train_feedback_context=args.feedback_context,
                decouple_prob=.3 if args.cross else 0.,root_recon_weight=.1 if args.cross else 0.)
            if any(latest['args'].get(k)!=v for k,v in required.items()) or not latest.get('selection'):
                raise ValueError('Completed recovery differs from requested configuration or lacks validation selection')
            return
    subprocess.run(command,check=True,cwd=ROOT)


if __name__=='__main__':
    main()
