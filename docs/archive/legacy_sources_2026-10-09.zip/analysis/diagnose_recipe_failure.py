"""Fixed CPU/FP32 validation contrasts for recipe conditioning; no training or rollout."""
from pathlib import Path
import json
import sys
import argparse

import numpy as np
import torch
import torch.nn.functional as F

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from Utils.motion_eval import load_motion_model
from Utils.runtime import configure_torch_runtime, load_norm_stats
from Utils.reproducibility import case_noise_plan, state_fingerprint
from dataset import Motion375Dataset
from evaluate_unseen_style import generate_pure_recipe
from evaluate_minor_revision_generalization import _classifier_stats, _root_ade_cm
from Utils.fid_feature_extractor import build_fid_feature_extractor_from_checkpoint


def histogram(indices, slots, size):
    counts=np.stack([np.bincount(indices[:,slot],minlength=size) for slot in slots]).astype(np.float32)
    return torch.from_numpy(counts/counts.sum(-1,keepdims=True))


@torch.no_grad()
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--interface-only',action='store_true')
    args=parser.parse_args()
    torch.set_num_threads(2)
    configure_torch_runtime(device=torch.device('cpu'),tf32=False,cudnn_benchmark=False,matmul_precision='highest')
    ckpt=ROOT/'checkpoints/flowmatch_tf150_staged_noise/best.pt'
    model=load_motion_model(model_name='flowmatch_target',ckpt_path=ckpt,num_styles=90).eval()
    vq_before=state_fingerprint(model.vqvae.state_dict())
    classifier,metadata=build_fid_feature_extractor_from_checkpoint(
        ROOT/'checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth',map_location='cpu')
    classifier.eval()
    db=ROOT/'database_100sty_375_memmap'
    mean,std=load_norm_stats(ROOT/'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/norm_stats.npz')
    segments=json.loads((db/'segments.json').read_text())
    names=json.loads((db/'StyleNames.json').read_text())
    raw=np.memmap(db/'X.f32',mode='r',dtype=np.float32,shape=(7068516,375))
    cache_path=ROOT/'cache/vq_targets_vq150ep_repair_v2'
    cache_meta=json.loads((cache_path/'meta.json').read_text())
    assert cache_meta['complete'] and cache_meta['fingerprints']==model.eval_fingerprints
    codes=np.memmap(cache_path/cache_meta['indices_file'],mode='r',dtype=cache_meta['indices_dtype'],
        shape=(cache_meta['num_frames'],cache_meta['num_codebooks']))
    slots=model.selected_style_slots
    size=model.vqvae.quantizer.num_embeddings
    learned=model.style_selector(codebook_weight=model.vqvae.quantizer.embedding_weight,style_label=torch.arange(90))
    probabilities={'selector_exact':learned['style_probs'], 'prior_dense':model.style_prior_probs}
    probabilities['prior_top4']=model.style_selector._sparsify_probs(model.style_prior_probs)
    # Reproduce the user's legacy recipe sampling from all windows, but reuse the verified code cache.
    dataset=Motion375Dataset(db_path=db,seq_len=240,stride=30,normalize=False)
    window_labels=dataset.labels[dataset.sample_starts]
    rng=np.random.default_rng(42)
    legacy=[]; independent=[]
    exemplar_manifest=[]
    for label in range(90):
        candidates=np.flatnonzero(window_labels==label)
        chosen=rng.choice(candidates,min(5,len(candidates)),replace=False)
        rows=np.concatenate([np.asarray(codes[s:s+240]) for s in dataset.sample_starts[chosen]])
        legacy.append(histogram(rows,slots,size))
        candidates=[s for s in segments if s['label']==label and s.get('split')=='train'
                    and not s.get('mirror') and s['num_frames']>=240]
        local=np.random.default_rng(np.random.SeedSequence([42,label]))
        selected=local.choice(len(candidates),min(5,len(candidates)),replace=False)
        selected_rows=[]; records=[]
        for index in selected:
            s=candidates[index]
            start=s['frame_start']+int(local.integers(s['num_frames']-240+1))
            selected_rows.append(np.asarray(codes[start:start+240]))
            records.append(dict(source_entry_id=s['source_entry_id'],start=start))
        independent.append(histogram(np.concatenate(selected_rows),slots,size))
        exemplar_manifest.append(records)
    probabilities['legacy_hist_dense']=torch.stack(legacy)
    probabilities['legacy_hist_top4']=model.style_selector._sparsify_probs(probabilities['legacy_hist_dense'])
    probabilities['train_clip_top4']=model.style_selector._sparsify_probs(torch.stack(independent))
    # Isolate mirror aggregation from short-clip sampling without changing VQ/device.
    unmirrored_counts=np.zeros((90,len(slots),size),dtype=np.int64)
    for segment in segments:
        if segment.get('split')!='train' or segment.get('mirror'):
            continue
        selected=codes[segment['frame_start']:segment['frame_start']+segment['num_frames']]
        for local,slot in enumerate(slots):
            unmirrored_counts[segment['label'],local]+=np.bincount(selected[:,slot],minlength=size)
    unmirrored_prior=unmirrored_counts.astype(np.float64)+1
    unmirrored_prior/=unmirrored_prior.sum(-1,keepdims=True)
    probabilities['train_all_unmirrored_top4']=model.style_selector._sparsify_probs(
        torch.from_numpy(unmirrored_prior.astype(np.float32)))
    stats={}; features={}
    for key,p in probabilities.items():
        output=model.style_selector(codebook_weight=model.vqvae.quantizer.embedding_weight,manual_probs=p,batch_size=90)
        feature=output['style_feature']; features[key]=feature
        nearest=torch.cdist(feature,learned['style_feature']).argmin(-1)
        stats[key]=dict(mean_token_l2=float((feature-learned['style_feature']).norm(dim=-1).mean()),
            max_token_abs_error=float((feature-learned['style_feature']).abs().max()),
            nearest_own_fraction=float((nearest==torch.arange(90)).float().mean()),
            mean_centered_feature_norm=float((feature-learned['style_feature'].mean(0)).norm(dim=-1).mean()),
            selected_code_overlap=float(((p>0)&(learned['style_probs']>0)).sum(-1).float().mean()/4))
    p=model.style_prior_probs
    dense=F.softmax(learned['style_logits']/model.style_selector.temperature,-1)
    kl=(p*(p.clamp_min(1e-8).log()-dense.clamp_min(1e-8).log())).sum(-1).mean()
    mask=probabilities['prior_top4']>0
    learned_mask=learned['style_probs']>0
    stats['dense_prior_vs_selector']=dict(kl=float(kl),
        exact_top4_slot_fraction=float((mask==learned_mask).all(-1).float().mean()),
        top4_overlap=float((mask&learned_mask).sum(-1).float().mean()/4))
    candidates=[s for s in segments if s.get('split')=='val' and not s.get('mirror') and s['num_frames']>=241]
    chosen=np.random.default_rng(42).choice(len(candidates),8,replace=False)
    source_segments=[candidates[i] for i in chosen]
    starts=[s['frame_start']+(s['num_frames']-241)//2 for s in source_segments]
    source_labels=np.array([s['label'] for s in source_segments])
    targets=np.concatenate([source_labels,(source_labels+37)%90])
    starts=starts+starts
    source_labels=np.concatenate([source_labels,source_labels])
    references=np.stack([raw[s:s+241] for s in starts])
    x=torch.from_numpy((references-mean)/std)
    noise=case_noise_plan(model,starts,targets,241,seed=42,noise_std=1.)
    batch=x.size(0); current=x[:,:-1].reshape(-1,375)
    previous=torch.cat([model.frame_latent(current[b:b+512]) for b in range(0,len(current),512)])
    # Cache identical GT history once for all contrasts; each mode changes only style feature.
    def generate(feature):
        feature=feature[:,None].expand(-1,240,-1).reshape(-1,64)
        motion=[]
        for begin in range(0,len(current),512):
            latent=model.sample_latent(x_curr=current[begin:begin+512],style_label=None,
                prev_latent=previous[begin:begin+512],style_feature=feature[begin:begin+512],
                z0=noise.reshape(-1,128)[begin:begin+512],num_steps=8)
            motion.append(model.feedback_state(latent)[0])
        result=x.clone(); result[:,1:,84:]=torch.cat(motion).reshape(batch,240,291)
        return result
    modes={'label':learned['style_feature'][targets],**{k:f[targets] for k,f in features.items()}}
    label_motion=None; summaries={}
    for key,feature in modes.items():
        if args.interface_only and key not in {'label','selector_exact'}:
            continue
        generated=generate(feature)
        if key=='label': label_motion=generated.clone()
        generated_raw=generated.numpy()*std+mean
        pred,conf,_=_classifier_stats(classifier,generated_raw[:,1:],targets,
            device=torch.device('cpu'),classifier_window=240,classifier_stride=240,
            classifier_batch_size=16,joint_set=metadata['joint_set'])
        ade=[_root_ade_cm(ref,output,dt=1/60,context_frames=1) for ref,output in zip(references,generated_raw)]
        summaries[key]=dict(matched_acc_pct=float(np.mean(pred[:8]==targets[:8])*100),
            cross_acc_pct=float(np.mean(pred[8:]==targets[8:])*100),predictions=pred.tolist(),
            target_confidence=conf.tolist(),mean_root_ade_cm=float(np.mean(ade)),
            max_motion_delta_from_label=float((generated-label_motion).abs().max()))
        print(f"[Probe] {key}: matched={summaries[key]['matched_acc_pct']:.1f}, cross={summaries[key]['cross_acc_pct']:.1f}",flush=True)
    assert state_fingerprint(model.vqvae.state_dict())==vq_before
    result=dict(checkpoint=str(ckpt),seed=42,split='validation',device='cpu/fp32/highest',
        samples='8 original validation sources, each matched+cross; 240 generated frames; no rollout/training',
        targets=targets.tolist(),starts=starts,source_labels=source_labels.tolist(),token_stats=stats,
        generation=summaries,train_recipe_exemplars=exemplar_manifest,vq_unchanged=True)
    filename='recipe_interface_parity_2026-10-06.json' if args.interface_only else 'recipe_failure_diagnostic_2026-10-06.json'
    (ROOT/'analysis'/filename).write_text(json.dumps(result,indent=2))


if __name__=='__main__': main()
