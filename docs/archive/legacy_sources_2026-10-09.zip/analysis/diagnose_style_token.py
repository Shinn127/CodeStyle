#!/usr/bin/env python
"""Cheap, training-free diagnostic for the style token.

Question: the style-code prior is verified correct and the selector matches it in distribution
(KL 0.364 nats), but the *hard* TopK selection agrees with the prior's top-4 only ~42% of the
time, so the style token may be too weak. Does sharpening / strengthening it at inference
improve style expression, without any retraining?

Three eval-time interventions are swept on the *same* trained controller (no weight updates):

  A. selector temperature tau in {1.0, 0.5, 0.3}      -- sharper TopK selection
  B. token gain alpha in {1.0, 2.0, 3.0}              -- amplify (e_s - mean) before the generator
  C. prior mixing beta in {0.0, 0.3, 0.5}             -- pi ~ (1-b) pi + b * prior_of_target_style

Reported per configuration: matched-style accuracy, cross-style accuracy (5 random targets per
source), mean target confidence, token separability (pairwise cosine), and TopK-4 overlap with
the prior. Rollouts use the same code path as the evaluation scripts.

    python analysis/diagnose_style_token.py --controller-ckpt checkpoints/flowmatch_vqvae_controller_prior_90st/best.pt
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

import sys

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Utils.fid_feature_extractor import (  # noqa: E402
    JOINT_SET_YBOT15,
    build_fid_feature_extractor_from_checkpoint,
    motion375_clip_to_classifier_input,
)
from Utils.motion_eval import load_motion_model, reconstruct_motion_batch  # noqa: E402
from Utils.runtime import load_norm_stats, resolve_device, set_seed  # noqa: E402
from dataset import build_train_val_test_datasets  # noqa: E402


class StyleSelectorProbe(torch.nn.Module):
    """Wraps the trained selector and post-processes its output (temperature / gain / prior mix)."""

    def __init__(self, inner, *, temperature, gain, prior_probs, beta, token_mean, slots):
        super().__init__()
        self.inner = inner
        self.temperature = float(temperature)
        self.gain = float(gain)
        self.prior_probs = prior_probs            # [styles, |Omega|, K] or None
        self.beta = float(beta)
        self.token_mean = token_mean              # [1, feat_dim] or None
        self.slots = slots

    def forward(self, *, codebook_weight, style_label=None, manual_probs=None, manual_strength=1.0):
        if self.prior_probs is not None and style_label is not None and self.beta > 0.0:
            gather = style_label.reshape(-1).to(device=self.prior_probs.device)
            manual_probs = self.prior_probs[gather].to(device=codebook_weight.device)
            manual_strength = self.beta
        out = self.inner(
            codebook_weight=codebook_weight,
            style_label=style_label,
            manual_probs=manual_probs,
            manual_strength=manual_strength,
            temperature=self.temperature,
        )
        if self.gain != 1.0 and self.token_mean is not None:
            out["style_feature"] = self.token_mean + self.gain * (out["style_feature"] - self.token_mean)
        return out


def _token_stats(selector, num_styles: int, codebook_weight: torch.Tensor, prior: np.ndarray, slots: np.ndarray):
    labels = torch.arange(num_styles)
    with torch.no_grad():
        out = selector(codebook_weight=codebook_weight, style_label=labels)
    feats = out["style_feature"].double().cpu()
    fn = torch.nn.functional.normalize(feats, dim=1)
    sim = fn @ fn.t()
    off = sim[~torch.eye(num_styles, dtype=bool)]
    sparse = out["style_probs"].double().cpu().numpy()
    prior_sel = prior[:, slots, :]
    prior_top = np.argsort(-prior_sel, axis=-1)[..., :4]
    sel_top = np.argsort(-sparse, axis=-1)[..., :4]
    overlap = np.mean([len(set(prior_top[s, k]) & set(sel_top[s, k])) / 4
                       for s in range(num_styles) for k in range(len(slots))])
    top1_mass = float(sparse.max(axis=-1).mean())
    return {"token_cos_mean": float(off.mean()), "prior_top4_overlap": float(overlap),
            "selector_top1_mass": top1_mass}


def _rollout_accuracy(*, model, x, labels, target_labels, classifier, device, mean, std, batch_size=64):
    """Roll out with `labels` as conditioning, score the decoded motion against `target_labels`."""
    n = x.size(0)
    preds = []
    confs = []
    for start in range(0, n, batch_size):
        xb = x[start:start + batch_size]
        lb = labels[start:start + batch_size]
        with torch.no_grad():
            pred = reconstruct_motion_batch(
                model_name="flowmatch_velocity",
                model=model,
                x=xb,
                style_label=lb,
                flow_eval_mode="rollout",
                flow_solver="euler",
                flow_ode_steps=None,
                flow_noise_std=None,
                flow_requantize_z=False,
                flow_latent_clip=True,
            )
        if pred.dim() == 2:
            pred = pred.unsqueeze(1)
        pred_raw = pred * std + mean                                    # normalized -> raw (meters)
        inp = motion375_clip_to_classifier_input(pred_raw, joint_set=JOINT_SET_YBOT15)
        with torch.no_grad():
            _feats, logits = classifier(inp.to(device=device))
        probs = torch.softmax(logits, dim=1)
        preds.append(probs.argmax(1).cpu())
        confs.append(probs.gather(1, target_labels[start:start + batch_size].unsqueeze(1)).squeeze(1).cpu())
    pred = torch.cat(preds).to(target_labels.device)
    conf = torch.cat(confs).to(target_labels.device)
    acc = float((pred == target_labels).float().mean())
    return acc, float(conf.mean())


def main() -> None:
    parser = argparse.ArgumentParser(description="Training-free style-token diagnostic")
    parser.add_argument("--controller-ckpt", type=Path,
                        default=ROOT / "checkpoints" / "flowmatch_vqvae_controller_prior_90st" / "best.pt")
    parser.add_argument("--db", type=Path, default=ROOT / "database_100sty_375_memmap")
    parser.add_argument("--prior", type=Path,
                        default=ROOT / "cache" / "style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz")
    parser.add_argument("--classifier-ckpt", type=Path,
                        default=ROOT / "checkpoints" / "fid_feature_extractor_camdm100_mirror" / "100style_position_classifier.pth")
    parser.add_argument("--num-sources", type=int, default=200)
    parser.add_argument("--targets-per-source", type=int, default=5)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    set_seed(args.seed)
    device = resolve_device(args.device)

    data = np.load(args.prior.expanduser().resolve(), allow_pickle=True)
    prior = np.asarray(data["prior"], dtype=np.float32)
    slots = np.asarray(data["selected_slots"], dtype=np.int64)
    num_styles = int(prior.shape[0])
    prior_t = torch.from_numpy(prior)
    prior_sel_t = prior_t[:, slots, :].contiguous()   # [styles, |Omega|, K] -- what the selector parameterises

    model = load_motion_model(model_name="flowmatch_velocity", ckpt_path=args.controller_ckpt, num_styles=num_styles)
    model = model.to(device).eval()
    ckpt_args = torch.load(args.controller_ckpt, map_location="cpu", weights_only=False).get("args", {})
    norm_stats = Path(str(ckpt_args.get("norm_stats") or (args.controller_ckpt.parent / "norm_stats.npz")))
    mean_np, std_np = load_norm_stats(norm_stats)
    mean = torch.from_numpy(mean_np.astype(np.float32)).to(device)
    std = torch.from_numpy(std_np.astype(np.float32)).to(device)

    probe_classifier, clf_meta = build_fid_feature_extractor_from_checkpoint(args.classifier_ckpt, map_location="cpu")
    probe_classifier = probe_classifier.to(device).eval()
    print(f"[Info] controller   : {args.controller_ckpt}")
    print(f"[Info] classifier   : {args.classifier_ckpt.name} ({clf_meta['class_num']} classes, {clf_meta['joint_set']})")
    print(f"[Info] prior slots  : {slots.tolist()}")

    _, _, test_ds = build_train_val_test_datasets(
        db_path=args.db, seq_len=60, stride=30, normalize=False, val_ratio=0.1, test_ratio=0.1, seed=args.seed
    )
    rng = np.random.default_rng(args.seed)
    idx = np.sort(rng.choice(len(test_ds), size=min(args.num_sources, len(test_ds)), replace=False))
    x_raw = torch.stack([test_ds[int(i)]["x"] for i in idx]).float()
    src_labels = torch.tensor([int(test_ds[int(i)]["label"]) for i in idx], dtype=torch.long)
    x = (x_raw.to(device) - mean) / std          # [B, T=60, 375], same layout the evaluators pass
    src_labels = src_labels.to(device)
    # cross-style targets: 5 random styles != source style
    offs = torch.tensor([1, 7, 19, 37, 61], device=device)
    cross_targets = (src_labels.unsqueeze(1) + offs) % num_styles    # [B, 5]

    inner = model.style_selector
    codebook = model.vqvae.quantizer.embedding_weight.detach()
    with torch.no_grad():
        base_feats = inner(codebook_weight=codebook, style_label=torch.arange(num_styles))["style_feature"]
    token_mean = base_feats.mean(dim=0, keepdim=True)

    configs = ([("mean-token", 1.0, 0.0, 0.0)]          # token replaced by its global mean: no style info
               + [("tau", t, 1.0, 0.0) for t in (1.0, 0.5, 0.3)]
               + [("gain", 1.0, g, 0.0) for g in (2.0, 3.0)]
               + [("prior-mix", 1.0, 1.0, b) for b in (0.3, 0.5)])

    rows = []
    for kind, tau, gain, beta in configs:
        probe = StyleSelectorProbe(inner, temperature=tau, gain=gain,
                                   prior_probs=prior_sel_t if beta > 0 else None,
                                   beta=beta, token_mean=token_mean, slots=slots).to(device)
        model.style_selector = probe
        stats = _token_stats(probe, num_styles, codebook, prior, slots)
        matched_acc, matched_conf = _rollout_accuracy(
            model=model, x=x, labels=src_labels, target_labels=src_labels,
            classifier=probe_classifier, device=device, mean=mean, std=std)
        flat_x = x.repeat_interleave(cross_targets.size(1), dim=0)
        flat_lbl = cross_targets.reshape(-1).to(device)
        cross_acc, cross_conf = _rollout_accuracy(
            model=model, x=flat_x, labels=flat_lbl, target_labels=flat_lbl,
            classifier=probe_classifier, device=device, mean=mean, std=std)
        row = {"kind": kind, "tau": tau, "gain": gain, "beta": beta,
               "matched_acc": matched_acc, "matched_conf": matched_conf,
               "cross_acc": cross_acc, "cross_conf": cross_conf, **stats}
        rows.append(row)
        print(f"[{kind:9s}] tau={tau:.2f} gain={gain:.1f} beta={beta:.1f} | "
              f"matched {100*matched_acc:5.2f}%  cross {100*cross_acc:5.2f}%  "
              f"| token cos {stats['token_cos_mean']:.3f}  prior top-4 overlap {100*stats['prior_top4_overlap']:5.1f}%  "
              f"selector top-1 mass {stats['selector_top1_mass']:.3f}")
    model.style_selector = inner

    if args.out is not None:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
        print(f"[Done] wrote {args.out}")


if __name__ == "__main__":
    main()
