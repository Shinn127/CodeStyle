"""Sealed test phase for the three repaired controller stages. Run explicitly after training."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Utils.fid_feature_extractor import build_fid_feature_extractor_from_checkpoint, motion375_clip_to_classifier_input
from Utils.motion_eval import load_motion_model, reconstruct_motion_batch, compute_sequence_metric_sums, MotionEvalConfig
from Utils.reproducibility import case_noise_plan, state_fingerprint, cluster_interval, file_sha256
from Utils.runtime import load_checkpoint, load_norm_stats, configure_torch_runtime
from Utils.controller_validation import selection_key


def export_example(args, name, ref, gen, *, case):
    """Fixed, unsmoothed clips plus the existing Geno BVH exporter and root-track plot."""
    from Visualization.io.genoview_bvh import export_motion375_segment_to_bvh
    from Utils.motion375 import reconstruct_root_track_from_375
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    directory = args.out / 'examples'; directory.mkdir(exist_ok=True)
    np.savez(directory / f'{name}.npz', reference=ref, generated=gen, case_json=json.dumps(case))
    meta = json.loads((args.db / 'meta.json').read_text())
    segments = json.loads((args.db / 'segments.json').read_text())
    mirror = next((bool(s.get('mirror')) for s in segments
                   if s['frame_start'] <= case['source_start'] < s['frame_start'] + s['num_frames']), False)
    with tempfile.TemporaryDirectory(dir=directory) as temporary:
        db = Path(temporary)
        for label, clip in [('reference', ref), ('generated', gen)]:
            np.asarray(clip, np.float32).tofile(db / 'X.f32')
            (db / 'meta.json').write_text(json.dumps({'num_frames': len(clip), 'feature_dim': 375,
                'coordinate_convert': bool(meta.get('coordinate_convert', False))}))
            export_motion375_segment_to_bvh(db_path=db, template_bvh=args.bvh_template,
                template_frame=0, segment_index=0, segment_offset=0, frame_start=0,
                num_frames=len(clip), fps=60, root_wy_in_degrees=True, mirror_template=mirror,
                out_bvh=directory / f'{name}_{label}.bvh')
    fig, ax = plt.subplots(figsize=(5, 4))
    for label, clip in [('reference', ref), ('generated', gen)]:
        track, _ = reconstruct_root_track_from_375(clip)
        ax.plot(track[:, 0], track[:, 2], label=label)
    ax.set(xlabel='World x (m)', ylabel='World z (m)', title=name, aspect='equal')
    ax.legend(); fig.tight_layout(); fig.savefig(directory / f'{name}_root.png'); plt.close(fig)


@torch.no_grad()
def evaluate_diagnostics(model, *, args, mean, std, cases):
    """Separate AE/controller paths on the same 1,000 source cases, before attributing gaps."""
    source, _ = load_arrays(args.db)
    rows = []
    paths = ['continuous_ae', 'quantized_ae', 'teacher_forced_continuous',
             'teacher_forced_quantized', 'rollout_continuous', 'rollout_quantized']
    for begin in range(0, len(cases), args.batch_size):
        batch = cases[begin:begin + args.batch_size]
        starts = [c['source_start'] for c in batch]; labels = [c['source_label'] for c in batch]
        raw = np.stack([source[s:s + 60] for s in starts])
        x = torch.from_numpy((raw - mean) / std).to(args.device)
        noise = case_noise_plan(model, starts, labels, 60)
        for path in paths:
            ae = path.endswith('_ae')
            pred = reconstruct_motion_batch(model_name='basic_vqvae' if ae else 'flowmatch_target',
                model=model.vqvae if ae else model, x=x, style_label=torch.tensor(labels, device=args.device),
                vq_eval_path='pre_vq' if path == 'continuous_ae' else 'quantized',
                flow_eval_mode='reconstruct' if path.startswith('teacher_forced') else 'rollout',
                flow_requantize_z=path.endswith('_quantized'), flow_latent_clip=True,
                noise_plan=None if ae else noise, flow_ode_steps=8)
            decoded = pred.cpu().numpy() * std + mean
            for case, ref, gen in zip(batch, raw, decoded):
                sums = compute_sequence_metric_sums(reference_375=ref, prediction_375=gen, cfg=MotionEvalConfig())
                rows.append({**case, 'path': path, 'mpjpe_cm': sums.mpjpe_sum_cm / sums.mpjpe_count,
                    'root_ade_cm': sums.root_ade_sum_cm / sums.root_ade_count,
                    'jitter_cm': sums.jitter_sum_cm / sums.jitter_count,
                    'foot_sliding_local_cm': sums.foot_sliding_sum_cm / sums.foot_sliding_count
                        if sums.foot_sliding_count else None, 'contact_count': sums.foot_sliding_count})
    (args.out / 'path_diagnostics.json').write_text(json.dumps({'paths': paths, 'rows': rows}, indent=2))
    # Interface examples share the source and raw Gaussian noise across label/recipe variants.
    case = cases[0]; start = case['source_start']; labels = [case['source_label'], *case['targets'][:1]]
    raw = np.array(source[start:start + 60], copy=True); x = torch.from_numpy((raw - mean) / std)[None].to(args.device)
    for name, label in zip(['matched', 'cross'], labels):
        noise = case_noise_plan(model, [start], [label], 60)
        pred = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x,
            style_label=torch.tensor([label], device=args.device), noise_plan=noise, flow_ode_steps=8)
        export_example(args, name, raw, pred[0].cpu().numpy() * std + mean, case={**case, 'target': label})
    probs = model.encode_conditions(x_curr=x[:, 0], style_label=torch.tensor([labels[-1]], device=args.device),
                                   return_style_details=True)[3]['style_probs']
    shared = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x, style_label=None,
        manual_style_probs=probs[0], noise_plan=noise, flow_ode_steps=8)
    individual = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x, style_label=None,
        manual_style_probs=probs, noise_plan=noise, flow_ode_steps=8)
    torch.testing.assert_close(shared, individual)
    schedule = torch.full((1, 60), labels[0], device=args.device, dtype=torch.long)
    schedule[:, 30:] = labels[-1]
    switched = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x,
        style_label=schedule, noise_plan=noise, flow_ode_steps=8)
    export_example(args, 'style_switch', raw, switched[0].cpu().numpy() * std + mean, case={**case, 'switch_frame': 30})


def load_arrays(db):
    meta = json.loads((db / 'meta.json').read_text())
    return np.memmap(db / 'X.f32', dtype='float32', mode='r', shape=(meta['num_frames'], 375)), json.loads((db / 'segments.json').read_text())


@torch.no_grad()
def evaluate_long_and_ood(model, *, args, mean, std, cases):
    source, segments = load_arrays(args.db)
    classifier, metadata = build_fid_feature_extractor_from_checkpoint(args.classifier)
    classifier = classifier.to(args.device).eval()
    if metadata['window_size'] != 60 or metadata['in_feat'] != 45:
        raise ValueError('Repair protocol requires the 60-frame/ybot15 classifier')
    rng = np.random.default_rng(42)
    eligible = [s for s in segments if s.get('split') == 'test' and not s.get('mirror') and s['num_frames'] >= 600]
    if not eligible:
        raise ValueError('No complete 600-frame test source clips')
    long_cases = []
    for i in range(100):
        segment = eligible[i % len(eligible)]
        start = int(segment['frame_start']) + int(rng.integers(0, int(segment['num_frames']) - 599))
        long_cases.append({'source_start': start, 'source_entry_id': int(segment['source_entry_id']),
                           'target': int(segment['label']), 'noise_seed': 42})
    long_rows = []
    for begin in range(0, len(long_cases), args.batch_size):
        batch = long_cases[begin:begin + args.batch_size]
        starts = [r['source_start'] for r in batch]; labels = [r['target'] for r in batch]
        raw = np.stack([source[s:s + 600] for s in starts])
        x = torch.from_numpy((raw - mean) / std).to(args.device)
        pred = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x,
            style_label=torch.tensor(labels, device=args.device),
            noise_plan=case_noise_plan(model, starts, labels, 600), flow_ode_steps=8)
        decoded = pred.cpu().numpy() * std + mean
        if begin == 0:
            export_example(args, 'long600', raw[0], decoded[0], case=batch[0])
        for case, ref, gen in zip(batch, raw, decoded):
            for horizon in range(50, 601, 50):
                sums = compute_sequence_metric_sums(reference_375=ref[:horizon], prediction_375=gen[:horizon], cfg=MotionEvalConfig())
                long_rows.append({**case, 'horizon': horizon, 'mpjpe_cm': sums.mpjpe_sum_cm / sums.mpjpe_count,
                    'root_ade_cm': sums.root_ade_sum_cm / sums.root_ade_count})
    (args.out / 'long_rollout.json').write_text(json.dumps({'cases': long_cases, 'rows': long_rows}, indent=2))
    target_data, target_segments = load_arrays(args.ood_db)
    ood_names = json.loads((args.ood_db / 'StyleNames.json').read_text())
    codebook_size = model.vqvae.quantizer.num_embeddings
    slots = model.selected_style_slots
    recipes = []
    references = []
    recipe_dir = args.out / 'ood_recipes'; recipe_dir.mkdir(exist_ok=True)
    for name in ood_names:
        candidates = sorted([s for s in target_segments if s['style_name'] == name and not s.get('mirror') and s['num_frames'] >= 240], key=lambda s: s['source_entry_id'])
        if len(candidates) < 6:
            raise ValueError(f'{name} needs five independent exemplars plus a held-out reference clip')
        chosen = set(rng.choice(len(candidates), 5, replace=False).tolist())
        counts = np.zeros((len(slots), codebook_size))
        for index, segment in enumerate(candidates):
            start = segment['frame_start'] + (segment['num_frames'] - 240) // 2
            raw = np.array(target_data[start:start + 240], copy=True)
            if index in chosen:
                _, indices, _ = model.vqvae.encode(torch.from_numpy((raw - mean) / std).to(args.device))
                selected = indices.cpu().numpy()[:, slots]
                for j in range(len(slots)):
                    counts[j] += np.bincount(selected[:, j], minlength=codebook_size)
            else:
                _, logits = classifier(motion375_clip_to_classifier_input(raw[None, 90:150], joint_set='ybot15').to(args.device))
                label = metadata['class_names'].index(name)
                references.append({'style': name, 'source_entry_id': segment['source_entry_id'],
                    'correct': int(logits.argmax(1).item() == label)})
        probs = np.zeros_like(counts, dtype=np.float32)
        entries = []
        for j, slot in enumerate(slots):
            codes = np.argsort(-counts[j], kind='stable')[:4]
            weights = counts[j, codes] / counts[j, codes].sum()
            probs[j, codes] = weights
            entries.append({'slot': int(slot), 'codes': codes.tolist(), 'weights': weights.tolist()})
        recipes.append(probs)
        payload = {'strength': 1., 'slots': entries, 'metadata': {'style_name': name,
            'selected_slots': list(slots), 'vq_state_sha256': state_fingerprint(model.vqvae.state_dict()),
            'exemplar_source_entry_ids': [candidates[i]['source_entry_id'] for i in sorted(chosen)],
            'reference_source_entry_ids': [candidates[i]['source_entry_id'] for i in range(len(candidates)) if i not in chosen]}}
        (recipe_dir / f'{name}.json').write_text(json.dumps(payload, indent=2))
    probs = torch.tensor(np.stack(recipes), device=args.device)
    rows = []
    ood_cases = []
    for case in cases:
        for target in rng.choice(len(ood_names), 5, replace=False):
            ood_cases.append({**case, 'ood_target': int(target), 'target_class': metadata['class_names'].index(ood_names[target]),
                              'recipe_source': str(recipe_dir / f'{ood_names[target]}.json'), 'noise_seed': 42})
    for begin in range(0, len(ood_cases), args.batch_size):
        batch = ood_cases[begin:begin + args.batch_size]
        starts = [r['source_start'] for r in batch]; targets = [r['target_class'] for r in batch]
        raw = np.stack([source[s:s + 60] for s in starts])
        x = torch.from_numpy((raw - mean) / std).to(args.device)
        pred = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x, style_label=None,
            manual_style_probs=probs[[r['ood_target'] for r in batch]],
            noise_plan=case_noise_plan(model, starts, targets, 60), flow_ode_steps=8)
        decoded = pred.cpu().numpy() * std + mean
        if begin == 0:
            export_example(args, 'ood', raw[0], decoded[0], case=batch[0])
        _, logits = classifier(motion375_clip_to_classifier_input(decoded, joint_set='ybot15').to(args.device))
        correct = (logits.argmax(1) == torch.tensor(targets, device=args.device)).cpu().tolist()
        for case, ref, gen, success in zip(batch, raw, decoded, correct):
            sums = compute_sequence_metric_sums(reference_375=ref, prediction_375=gen, cfg=MotionEvalConfig())
            rows.append({**case, 'correct': int(success), 'root_ade_cm': sums.root_ade_sum_cm / sums.root_ade_count})
    groups = [r['source_entry_id'] for r in rows]
    accuracy = float(np.mean([r['correct'] for r in rows]) * 100)
    ade = float(np.mean([r['root_ade_cm'] for r in rows]))
    summary = {'accuracy_pct': accuracy, 'root_ade_cm': ade,
        'accuracy_ci95': [v * 100 for v in cluster_interval([r['correct'] for r in rows], groups)],
        'root_ade_ci95': cluster_interval([r['root_ade_cm'] for r in rows], groups),
        'real_motion_reference': references, 'rows': rows, 'ci_unit': 'source_entry_id'}
    (args.out / 'ood_summary.json').write_text(json.dumps(summary, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=Path, nargs=3, required=True, help='A/B/C best.pt files')
    parser.add_argument('--db', type=Path, default=ROOT / 'database_100sty_375_memmap')
    parser.add_argument('--ood-db', type=Path, default=ROOT / 'database_100sty_375_memmap_zeroshot')
    parser.add_argument('--classifier', type=Path, default=ROOT / 'checkpoints/fid_feature_extractor_camdm100_mirror/100style_position_classifier.pth')
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--legacy-baselines', type=Path, nargs='*', default=[])
    parser.add_argument('--bvh-template', type=Path, default=ROOT.parent / 'GenoViewPython-main/resources/Geno_stance.bvh')
    args = parser.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; full evaluation was not started')
    if not args.bvh_template.is_file():
        raise FileNotFoundError(f'BVH template unavailable: {args.bvh_template}')
    checkpoints = [load_checkpoint(path) for path in args.runs]
    if any(cp.get('implementation_version') != 2 or not cp.get('selection') for cp in checkpoints):
        raise ValueError('Every stage must finish and have a validation-selected version 2 checkpoint')
    classifier_sha = file_sha256(args.classifier)
    for cp in checkpoints:
        config = cp['args']; selection = cp['selection']
        if selection['epoch'] != cp['epoch'] or tuple(selection['key']) != selection_key(selection['metrics']):
            raise ValueError('Checkpoint weights do not belong to their recorded validation selection')
        if config.get('prediction_mode') != 'target' or config.get('flow_loss_space') != 'normalized':
            raise ValueError('Main repair protocol requires normalized target prediction')
        if not config.get('inference_requantize') or not config.get('inference_latent_clip') or config.get('solver_steps') != 8:
            raise ValueError('Main repair protocol requires clip→quantize→decode and Euler8')
        if config['training_artifacts']['rollout_classifier_sha256'] != classifier_sha:
            raise ValueError('Test extractor differs from the fixed validation selector')
        if config['fingerprints'] != checkpoints[0]['args']['fingerprints']:
            raise ValueError('A/B/C source database, split, normalization or VQ manifold differs')
    selected = min(range(3), key=lambda i: tuple(checkpoints[i]['selection']['key']))
    common_manifest = args.out / 'seen_cases.json'
    def run(script, *parts):
        subprocess.run([sys.executable, str(ROOT / script), *map(str, parts)], check=True, cwd=ROOT)
    for label, path, cp in zip('ABC', args.runs, checkpoints):
        norm = cp['args']['norm_stats']
        run('evaluate_motion_375to291.py', '--models', 'flowmatch_target', '--flowmatch-target-ckpt', path,
            '--db', args.db, '--norm-stats', norm, '--fid-extractor-ckpt', args.classifier,
            '--seq-len', 60, '--stride', 30, '--device', args.device, '--out-dir', args.out / f'{label}_motion')
        run('evaluate_minor_revision_generalization.py', '--flow-ckpt', path, '--db', args.db,
            '--classifier-ckpt', args.classifier, '--case-manifest', common_manifest, '--include-gt-context',
            '--num-sources', 1000, '--targets-per-source', 5, '--horizons', 60,
            '--device', args.device, '--out-dir', args.out / f'{label}_styles')
    for index, path in enumerate(args.legacy_baselines):
        run('evaluate_minor_revision_generalization.py', '--flow-ckpt', path, '--db', args.db,
            '--classifier-ckpt', args.classifier, '--case-manifest', common_manifest, '--include-gt-context',
            '--device', args.device, '--out-dir', args.out / f'legacy{index}_styles')
    winner = args.runs[selected]
    configure_torch_runtime(device=torch.device(args.device), tf32=False, cudnn_benchmark=False, matmul_precision='highest')
    cp = checkpoints[selected]; mean, std = load_norm_stats(cp['args']['norm_stats'])
    model = load_motion_model(model_name='flowmatch_target', ckpt_path=winner, num_styles=90).to(args.device).eval()
    for steps in (4, 16):
        run('evaluate_minor_revision_generalization.py', '--flow-ckpt', winner, '--db', args.db,
            '--classifier-ckpt', args.classifier, '--case-manifest', common_manifest, '--include-gt-context',
            '--flow-ode-steps', steps, '--device', args.device, '--out-dir', args.out / f'best_steps{steps}')
    cases = json.loads(common_manifest.read_text())['horizons']['60']
    evaluate_diagnostics(model, args=args, mean=mean, std=std, cases=cases)
    unseen = evaluate_long_and_ood(model, args=args, mean=mean, std=std, cases=cases)
    motion = json.loads((args.out / f'{"ABC"[selected]}_motion/motion_eval_summary.json').read_text())['results'][0]
    styles = json.loads((args.out / f'{"ABC"[selected]}_styles/minor_revision_generalization_summary.json').read_text())['summaries']
    matched = next(r for r in styles if r['setting'].startswith('matched_'))
    cross = next(r for r in styles if r['setting'].startswith('cross_style_transfer_h'))
    checks = {'mpjpe': motion['mpjpe_cm'] <= 6.92, 'foot_sliding_local': motion['foot_sliding_cm'] <= .69,
        'jitter': motion['jitteriness_cm'] <= .40, 'matched_accuracy': matched['target_style_acc_pct'] >= 79.40,
        'cross_accuracy': cross['target_style_acc_pct'] >= 66.02, 'matched_ade': matched['root_ade_cm'] <= 3.16,
        'cross_ade': cross['root_ade_cm'] <= 3.55, 'unseen_accuracy': unseen['accuracy_pct'] >= 62.17,
        'unseen_ade': unseen['root_ade_cm'] <= 3.35}
    report = {'checkpoint': str(winner), 'selection_split': 'val', 'seed': 42, 'ode_steps': 8,
        'classifier_sha256': file_sha256(args.classifier), 'checks': checks, 'joint_passed': all(checks.values()),
        'training_randomness': 'single seed; cluster CI covers source-clip sampling only'}
    (args.out / 'acceptance.json').write_text(json.dumps(report, indent=2))
    comparisons = [('MPJPE (cm)', 6.016, motion['mpjpe_cm'], 6.92),
        ('Local F.S. (cm)', .600, motion['foot_sliding_cm'], .69),
        ('Local Jitter (cm)', .348, motion['jitteriness_cm'], .40),
        ('Matched accuracy (%)', 84.40, matched['target_style_acc_pct'], 79.40),
        ('Cross accuracy (%)', 71.02, cross['target_style_acc_pct'], 66.02),
        ('Matched Root ADE (cm)', 2.747, matched['root_ade_cm'], 3.16),
        ('Cross Root ADE (cm)', 3.088, cross['root_ade_cm'], 3.55),
        ('Unseen accuracy (%)', 67.17, unseen['accuracy_pct'], 62.17),
        ('Unseen Root ADE (cm)', 2.913, unseen['root_ade_cm'], 3.35)]
    text = f"Selected checkpoint: {winner}\n\nJoint targets passed: {report['joint_passed']}\n\n"
    text += '| Metric | Paper | Measured | Target |\n|---|---:|---:|---:|\n'
    text += ''.join(f'| {name} | {paper:.3f} | {value:.3f} | {target:.3f} |\n' for name, paper, value, target in comparisons)
    text += '\nSingle training seed (42); source-cluster intervals describe clip sampling only.\n'
    text += '\nWorld F.S. and global/style/clip FID are reported separately in motion summaries. '
    text += 'See path_diagnostics.json, stage matched/cross summaries, ood_summary.json and long_rollout.json for remaining gaps.\n'
    (args.out / 'paper_comparison.md').write_text(text)


if __name__ == '__main__':
    main()
