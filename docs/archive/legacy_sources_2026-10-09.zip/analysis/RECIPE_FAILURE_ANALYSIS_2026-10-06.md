# 当前controller的seen recipe / OOD失败定位

审计对象：`flowmatch_tf150_staged_noise/best.pt`（epoch135），与已有OOD报告中的checkpoint SHA256一致。读取用户已完成的完整报告；新增检查只用CPU/FP32、8个原始validation clips各matched/cross一次、240帧、固定seed42/noise，单步teacher-forced。没有训练、rollout或完整test重测，VQ state前后未变。

结论：用户观察成立。**当前checkpoint没有学到exemplar histogram与label selector之间的语义对齐；具备pure-recipe接口不等于具备可用的clip-style能力。** 上一轮检查主要证明形状、来源、VQ表示及接口可执行性；这不足以验证同style recipe与label的生成等价性，本轮补上这一检查。

## 完整结果

| 已有设置 | 数量 | Target accuracy | Root ADE |
|---|---:|---:|---:|
| Seen label cross，240帧TF | 5000 | 57.96% | 10.574cm |
| Seen exemplar recipe cross，历史dense路径，同cases | 5000 | 12.08% | 9.455cm |
| OOD pure TopK4 recipe，240帧TF | 5000 | 0.10% | 9.388cm |
| OOD real-motion reference，独立clips | 31 | 100% | 不适用 |
| OOD quantized AE，同reference | 31 | 77.42% | 本报告未统计 |

OOD生成中Robot与FairySteps占预测约51.6%（1341+1239 / 5000），source retention仅6.5%。它是错误目标风格/偏向少数已知类别，不能仅解释为照搬source。AE的77.42%说明representation也有损失，但不是生成0.10%的充分解释；AE不是生成器严格数学上界。

原始报告：`eval_results/gen_tf150_best_recipe_240f/`、`eval_results/gen_tf150_best_tf_240f/`、`eval_results/unseen_tf240_staged_noise/`。旧报告与checkpoint保持原样。

## 决定性接口对照

将当前模型自己的selector TopK概率原样传入pure recipe，style_label=None，其他GT输入、噪声、ODE8和反馈策略相同。修复重复归一化的末位精度变化后，90类style tokens与label路径逐元素完全相同；16个validation生成cases的全部motion也完全相同（max abs delta=0）。因此不存在pure recipe把正确selector概率接入另一套不兼容projection、错误slot或错误codebook的问题。

重复归一化原先导致token最大差约1.9e-6；部分latent位于最近邻量化边界，产生少量code变化，normalized motion最大差.226。它不改变这组分类accuracy，无法解释seen57.96→12.08或OOD0.10。已让FP32单位和概率在容差内保持原值，并保留大权重安全归一化、有限/非负/缺slot校验。

详细数据：`recipe_interface_parity_2026-10-06.json`；前修复诊断保留为 `recipe_failure_diagnostic_2026-10-06_pre_normalization_fix.json`。

## 核心原因一：训练和推理输入不是同一style表示

训练为 `style ID -> learned selector -> TopK4 -> codebook均值 -> learned projection -> flow`，recipe_prob=0，每style只提供其learned selector对应的一组token。推理换成 `exemplar -> GT VQ histogram -> TopK4 -> codebook均值 -> 同projection -> flow`。没有损失要求两者的token/flow输出一致，也没有exemplar variation训练；复用同一projection并不能建立语义等价关系。

90类统计（均相对当前learned selector token）：

| 概率输入 | 平均token L2差 | Nearest token为自身style的比例 | sparse code支持重合 |
|---|---:|---:|---:|
| Selector自己的概率 | 0 | 100% | 100% |
| 训练prior TopK4 | 2.846 | 80.0% | 74.7% |
| 历史5-window histogram TopK4 | 5.492 | 58.9% | 41.0% |
| 独立5个train clips，240帧，TopK4 | 7.106 | 30.0% | 34.2% |
| 全部未镜像train帧的prior TopK4 | 6.237 | 35.6% | 54.7% |

Nearest-token不是classifier结果；这里只定位条件分布错位。独立clip recipe仍偏离说明不能仅把错误归到原脚本dense输入；全部unmirrored train帧也不能对齐，说明短clip估计噪声不是唯一原因。训练prior包含mirrored augmentation，而exemplar为未镜像clips，其统计也存在系统差异。镜像不会被当成独立exemplar；本轮不通过改变标签或强制最近seen style“修复”OOD。

## 核心原因二：dense KL不能保证TopK后的几何表示一致

当前dense prior与selector的平均KL约.033855，但TopK4集合完全相同的slot只有34.3%。slot的平均4-code交集比例74.7%，意味着多数slot仍发生至少一个head code替换；在32维prototype中，这足以产生显著变化。

若第4/5码的概率接近，交换它们的排序只带来很小dense KL，却会替换TopK保留的code vector。因此 `KL(p_prior || p_selector)小`不能推出 `prototype_prior≈prototype_selector`，更不能推出 `flow(recipe)≈flow(label)`。训练中的flow/entropy梯度可以与selector和projection共同形成风格ID表示；现有prior约束不足以保证这套表示能由原始exemplar histogram恢复。

## 核心原因三：旧seen评估还有统计口径不一致

旧seen recipe报告使用dense histogram，而label使用TopK4；5个窗口可能来自同一原始clip、含镜像或不同split。dense均值混入大量尾部codes，减弱/改变prototype，且不等同于正式5个独立240帧exemplars。

已把seen recipe默认构建改为canonical：5个独立未镜像train clips、固定saved normalization、240帧、共享sparse_code_histogram与controller TopK、记录source IDs/crop starts。strength1时走style_label=None，与OOD一致。`--recipe-profile legacy`可复播旧all-window/dense行为；原window设置也需显式保留。修改只规范统计，**不宣称因此恢复模型能力**。

## 小规模受控生成对照

8个validation sources各matched/cross一次，同GT history、同Gaussian、同solver与输出政策，未调整classifier或模型权重。以下为修复数值归一化前的机制诊断；不是完整benchmark或checkpoint选择依据：

| 输入 | Matched acc | Cross acc |
|---|---:|---:|
| Label | 100% | 50% |
| Selector自身概率作为recipe | 100% | 50% |
| 全train dense prior | 50% | 12.5% |
| 全train prior TopK4 | 75% | 25% |
| 历史5-window dense recipe | 62.5% | 12.5% |
| 同窗口recipe只改TopK4 | 62.5% | 0% |
| 独立train clips TopK4 recipe | 62.5% | 12.5% |

这支持条件表示错位，并反驳“只补TopK即可恢复”的预期。修复后selector自身recipe仍100%/50%，与label所有生成值相同。90类统计复用内容指纹匹配的FP32 GPU code cache，生成使用CPU；不同设备NN边界并不是本次各输入对照的变量，不能把CPU小样本数字当完整GPU结果。

额外解码策略对照（同一flow latent，未重新采样）：16个seen validation cases（8matched+8cross）的label总accuracy在continuous、clip-only、clip→quantize均为75%；独立train-clip recipe对应43.75%、43.75%、37.50%。两类OOD（Zombie/WiggleHips各8个validation sources）三种策略均为0%。31个真实OOD reference的quantized AE在应用/不应用train bounds裁剪再量化时，style accuracy均为77.42%。量化可能放大一些误差，但本次没有支持“关闭量化即可修复recipe”的证据，主推理策略保持原样。详情在 `recipe_feedback_diagnostic_2026-10-06.json`。

## 后续修正的合理范围

1. 先验、recipe及inference协议现在固定；不更换classifier、VQ或通过降低评估时长宣称恢复。
2. 真正修复需要让generator在训练中接收seen exemplar recipes，并监督相同GT/合成cross目标。现有train-only recipe分支可用，可先考虑10%–20%的替换比例；保留大多数label batches，冻结VQ、recon/root/style-consistency=0、单步TF、FP32、matched_root不变。它不会增加Euler/decoder训练，但统计exemplars/数据传输的开销需要测量。
3. 若label-only到recipe差距仍大，可研究低成本prototype/token对齐：对seen clips的recipe token与冻结当前label token作约束；不是继续单纯提高dense prior权重。需要固定teacher/label anchors，避免两个分支一起塌缩。这里只是研究建议，本轮未加新loss或启动微调。
4. 用固定validation看label和recipe两组matched/cross、Root ADE与token分布，并先确认seen recipe能力，再锁定checkpoint重测OOD。recipe监督不能保证直方图丢失的时序/跨slot关系可恢复，OOD是否接近cross仍需实验。
5. 不能把recipe匹配到最近seen label，或给OOD加seen anchor后就声称unseen成功；这只能作为明确标注的混合风格诊断。

本轮交付：失效原因证据、数值等价性修复、seen recipe统计规范化、显式legacy复播与回归测试。未改变checkpoint，未启动新训练或完整OOD评估。

全部轻量回归测试192项通过、2项CUDA测试跳过、5项subtests通过；实际checkpoint的selector概率recipe与label生成逐元素一致。当前exemplar/OOD能力尚未通过模型训练修复。
