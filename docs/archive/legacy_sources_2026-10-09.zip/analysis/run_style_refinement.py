"""Paper-structure style refinement profile; dry-run by default, never starts on import."""
from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis.run_repair_pipeline import commands
from Utils.runtime import load_checkpoint


def apply_style_options(command):
    settings = {'--style-entropy-weight': '.003', '--style-proto-normalization': 'none',
                '--style-selector-init': 'prior', '--recipe-prob': '0'}
    for flag, value in settings.items():
        command[command.index(flag) + 1] = value
    return command


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'checkpoints/flowmatch_style_paper_v3')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--microbatch-size', type=int, choices=[128, 256, 512], default=512)
    parser.add_argument('--init-ckpt', type=Path, help='Optional compatible target/VQ checkpoint to initialize stage A')
    parser.add_argument('--execute', action='store_true', help='Explicitly run A/B/C; each at most 50 epochs')
    args = parser.parse_args(); args.output = args.output.resolve()
    _, stages, _ = commands(args)
    for index, command in enumerate(stages):
        apply_style_options(command)
        command += ['--recipe-frames', '240', '--recipe-exemplars', '5']
        if index == 0 and args.init_ckpt and '--resume' not in command:
            command += ['--init-ckpt', str(args.init_ckpt.resolve())]
        print(shlex.join(command), flush=True)
        if not args.execute:
            continue
        latest = args.output / 'ABC'[index] / 'latest.pt'
        if latest.exists():
            cp = load_checkpoint(latest)
            required = {'epochs': 50, 'seed': 42, 'style_entropy_weight': .003,
                'style_proto_normalization': 'none', 'style_selector_init': 'prior',
                'recipe_prob': 0., 'recipe_frames': 240, 'recipe_exemplars': 5,
                'prediction_mode': 'target', 'flow_loss_space': 'normalized', 'batch_size': 512,
                'microbatch_size': args.microbatch_size, 'style_hist_weight': .02,
                'recon_weight': .1, 'style_consistency_weight': 0., 'solver_steps': 8,
                'style_prior_loss': 'dense', 'style_selector_topk': 4, 'style_selector_temperature': 1.,
                'inference_requantize': True, 'inference_latent_clip': True,
                'matmul_precision': 'highest', 'tf32': False, 'dropout': 0.,
                'seq_len': 2 if index == 0 else 3, 'unroll_steps': 1 if index == 0 else 2,
                'decouple_latent': 'matched_root', 'decouple_prob': .3 if index == 2 else 0.,
                'root_recon_weight': .1 if index == 2 else 0., 'lr': .0005 if index == 0 else .0001}
            if (cp.get('implementation_version') != 2 or cp.get('training_objective_version') != 3
                    or any(cp.get('args', {}).get(k) != v for k, v in required.items())):
                raise ValueError('Existing stage differs from the bounded style-refinement profile')
            if cp['epoch'] >= 50:
                if not (latest.parent / 'best.pt').exists() or not cp.get('selection'):
                    raise ValueError('Completed stage lacks validation selection')
                continue
        subprocess.run(command, check=True, cwd=ROOT)


if __name__ == '__main__':
    main()
