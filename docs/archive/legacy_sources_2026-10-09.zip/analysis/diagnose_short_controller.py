"""Bounded validation-only diagnosis; no training, checkpoint selection or test-set tuning."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from Utils.motion_eval import load_motion_model, reconstruct_motion_batch, compute_sequence_metric_sums, MotionEvalConfig
from Utils.runtime import load_checkpoint, load_norm_stats
from Utils.controller_validation import classifier_label_mapping
from Utils.fid_feature_extractor import build_fid_feature_extractor_from_checkpoint, motion375_clip_to_classifier_input
from Utils.reproducibility import case_noise_plan


@torch.no_grad()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--sources', type=int, default=8)
    parser.add_argument('--device', default='cpu')
    args = parser.parse_args()
    if not 1 <= args.sources <= 32:
        raise ValueError('Diagnostic is bounded to at most 32 independent validation sources')
    torch.set_num_threads(2)
    torch.manual_seed(42)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    cp = load_checkpoint(args.checkpoint)
    config = cp['args']; db = Path(config['db'])
    model = load_motion_model('flowmatch_' + config['prediction_mode'], args.checkpoint,
                              num_styles=config['num_styles']).to(args.device).eval()
    mean, std = load_norm_stats(Path(config['norm_stats']))
    segments = json.loads((db / 'segments.json').read_text())
    names = json.loads((db / 'StyleNames.json').read_text())
    choices = [s for s in segments if s.get('split') == 'val' and not s.get('mirror') and s['num_frames'] >= 60]
    rng = np.random.default_rng(42)
    chosen = rng.choice(len(choices), args.sources, replace=False)
    starts = [int(choices[i]['frame_start']) + int(rng.integers(0, choices[i]['num_frames'] - 59)) for i in chosen]
    labels = torch.tensor([choices[i]['label'] for i in chosen], device=args.device)
    meta = json.loads((db / 'meta.json').read_text())
    source = np.memmap(db / 'X.f32', mode='r', dtype='float32', shape=(meta['num_frames'], 375))
    raw = np.stack([source[s:s+60] for s in starts])
    x = torch.from_numpy((raw - mean) / std).to(args.device)
    classifier, metadata = build_fid_feature_extractor_from_checkpoint(Path(config['rollout_val_classifier']))
    classifier = classifier.to(args.device).eval()
    mapping = classifier_label_mapping(names, metadata, device=args.device)
    noise = case_noise_plan(model, starts, labels.cpu().tolist(), 60)
    detail = model.style_selector(codebook_weight=model.vqvae.quantizer.embedding_weight.detach(),
                                  style_label=torch.arange(len(names), device=args.device))
    feature = detail['style_feature']
    report = {'checkpoint': str(args.checkpoint.resolve()), 'epoch': cp['epoch'], 'split': 'val',
        'sources': args.sources, 'starts': starts, 'source_entry_ids': [choices[i]['source_entry_id'] for i in chosen],
        'style_token_mean_norm': float(feature.mean(0).norm()),
        'style_token_centered_norm': float((feature-feature.mean(0)).norm(dim=1).mean()), 'paths': {}}
    for path in ['real', 'continuous_ae', 'quantized_ae', 'teacher_forced_continuous',
                 'teacher_forced_quantized', 'rollout_continuous', 'rollout_quantized', 'rollout_wrong_label']:
        ae = path.endswith('_ae')
        if path == 'real':
            prediction = x
        else:
            prediction = reconstruct_motion_batch(model_name='basic_vqvae' if ae else 'flowmatch_'+model.prediction_mode,
                model=model.vqvae if ae else model, x=x,
                style_label=(labels+37)%len(names) if path == 'rollout_wrong_label' else labels,
                vq_eval_path='pre_vq' if path == 'continuous_ae' else 'quantized',
                flow_eval_mode='reconstruct' if path.startswith('teacher_forced') else 'rollout',
                flow_requantize_z=path in ['teacher_forced_quantized', 'rollout_quantized', 'rollout_wrong_label'],
                flow_latent_clip=True, noise_plan=None if ae else noise, flow_ode_steps=8)
        generated = prediction.cpu().numpy()*std+mean
        _, logits = classifier(motion375_clip_to_classifier_input(generated, joint_set='ybot15').to(args.device))
        rows = [compute_sequence_metric_sums(reference_375=a, prediction_375=b, cfg=MotionEvalConfig()) for a,b in zip(raw,generated)]
        def metric(value, count):
            n = sum(getattr(r,count) for r in rows)
            return sum(getattr(r,value) for r in rows)/n if n else None
        report['paths'][path] = {'accuracy': float((logits.argmax(1)==mapping[labels]).float().mean()),
            'mpjpe_cm': metric('mpjpe_sum_cm','mpjpe_count'), 'root_ade_cm': metric('root_ade_sum_cm','root_ade_count'),
            'jitter_cm': metric('jitter_sum_cm','jitter_count'),
            'foot_sliding_cm': metric('foot_sliding_sum_cm','foot_sliding_count')}
        requested_labels = (labels+37)%len(names) if path=='rollout_wrong_label' else labels
        report['paths'][path]['requested_accuracy'] = float((logits.argmax(1)==mapping[requested_labels]).float().mean())
        report['paths'][path]['accuracy_reference'] = 'source_label'
        report['paths'][path]['mpjpe_by_horizon_cm'] = {}
        for horizon in [10,20,40,60]:
            partial = [compute_sequence_metric_sums(reference_375=a[:horizon], prediction_375=b[:horizon],
                       cfg=MotionEvalConfig()) for a,b in zip(raw,generated)]
            report['paths'][path]['mpjpe_by_horizon_cm'][horizon] = (
                sum(r.mpjpe_sum_cm for r in partial)/sum(r.mpjpe_count for r in partial))
        if path == 'rollout_quantized':
            baseline = generated
        elif path == 'rollout_wrong_label':
            report['label_intervention_pose_distance_cm'] = float(np.linalg.norm(
                (generated[...,87:159]-baseline[...,87:159]).reshape(args.sources,60,24,3),axis=-1).mean()*100)
        print(path, report['paths'][path], flush=True)
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
