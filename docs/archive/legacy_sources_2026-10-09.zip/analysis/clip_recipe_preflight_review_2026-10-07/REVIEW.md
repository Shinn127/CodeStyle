# GLM 训练前分析复核

2026-10-07。本轮没有训练、optimizer update 或 rollout；读取现有 GPU smoke 日志，补做 train-cache prior 可达性与 CPU donor 检索的只读核对。结论：功能验收支持开跑，但 prior、bank 代价、CI 的解释需要修正。

## 验证记录

用户提供的 GLM 记录为 219 项 CPU、26 项 CUDA/clip-recipe 通过，810-case TF validation 耗时28.8秒。本轮不重复CUDA测试；该测试数量与TF时间按用户提供记录引用。

本地 [smoke日志](/home/shinn/桌面/multimedia/revision/NewCode/checkpoints/clip_recipe_scratch150_smoke/history.jsonl) 可核对：train samples=1024，matched=817，cross=207，actual cross=.202148，recipe fraction=1，shortfall=0，donor candidates mean=2.1401，phase cost=.21515，prior CE=10.82350、target entropy=4.81329、KL=6.01021。无reconstruction/root/classifier loss。本地config确认新模式clip_recipe、从零初始化、2个train updates、TF验证关闭。

选型代码的键为 `(constraints_failed, -cross_accuracy, -matched_accuracy, normalized_ADE_sum)`，与GLM描述一致。270 matched / 540 cross 的240帧TF协议也与当前代码一致。

## 1. Prior KL：6.01可以是正常起点，存在结构性下界

Label selector曾用per-style prior初始化，因此其初始KL接近0并不奇怪。新selector的初始分布来自独立clip的统计，两者不是同一初始化问题，不能将0.024作为新模型应达到的数值基准。

实际新logits是：

    a_k = log(max(r_k, 1e-8)) + δ_k,    δ_k ∈ [-4, 4], temperature=1

当某个code未在exemplar出现时，底概率只有1e-8。即使网络给它+4、给已有code−4，相对重评分也最多乘exp(8)。因此per-style全动作prior中的部分质量无法由当前exemplar分布充分恢复。

只读取缓存，为每个90-style构建1/3/5个独立240帧train exemplar，排除一个监督clip，共270份profile。然后求解“每个code可独立选择δ∈[-4,4]”时的最小KL。这个自由度比实际共享几何网络大，因此所得值是实际模型的乐观下界。

| exemplar数 | 零残差初始KL均值 | 理想bounded-residual最小KL均值 | prior在exemplar未出现code上的质量 |
|---:|---:|---:|---:|
| 1 | 8.80 | 3.38 | 67.9% |
| 3 | 5.56 | 1.98 | 44.0% |
| 5 | 4.41 | 1.52 | 35.0% |

这些按style/slot等权，不是smoke两批的采样分布；不应把表中下界当成某个epoch精确应达到的值。初始KL均值约6.26，与smoke 6.01相符。实际网络还受共享key/query容量约束，可能达到更高的最低KL。

因此GLM“长期在6附近说明没学会prior、会影响matched”的表述过强。正确检查应结合：固定profile与exemplar数下的KL趋势、selector有效梯度、低flow时间的recipe敏感性，以及matched/cross验证效果。高KL不等于训练失败，低KL也不保证风格控制成功。

同时，CE=KL+target entropy。smoke的加权prior CE=.21647，其中常数下界=.09627、加权KL=.12020；这些loss大小不直接表示梯度支配程度。原告警在CE超过H+1时触发，而当前可达KL可能本就大于1，因此可能长期触发。告警文字已改成“需结合clip支持与残差约束判断”，没有改变loss、权重、模型或RNG。

## 2. Donor bank：32有收益的可能，但不只是构建/内存代价

“选定目标style后的平均候选≈2.1”确实提示匹配空间有限。但只有2个updates，不能证明它是最终cross accuracy的主因。需要看每action/style的覆盖及单候选比例，不能仅用均值判断。

同一份frame-weighted train source样本的CPU只读比较如下；probability=1用于观察是否存在合格target，而非模拟实际请求概率0.3。共1024 source、每bank三次查询，无encoder/flow/optimizer。

| bank密度 | 窗口数 | root/action可配对比例 | 选定style候选均值 | CPU单查询中位时间 |
|---:|---:|---:|---:|---:|
| 16 | 17,568 | 63.35% | 2.48 | .180秒 |
| 32 | 35,136 | 69.01% | 3.92 | .272秒 |

CPU检索时间增加约51%，不能用它预测GPU整体训练速度。但代码每次update都会重新计算source×bank的root/yaw门限、相位距离和style筛选，因此增加密度会增加训练主路径的运算与临时张量，绝非只有一次性的构建/常驻内存成本。按本小样本的eligible比例，请求概率.3对应的期望cross比例约19.0%→20.7%，不会随bank大小直接翻倍。

另外，16和32都是独立linspace网格；32只保留约12.58%的旧16个anchor，所以不是集合超集，不保证逐case单调改善。目标style在合格集合中均匀选择，增密后集合变化会改变所选目标，本表也不是同一source-target的phase质量消融。

建议先保留16，不因2-step smoke改默认实验。若后续检查表明candidate/phase覆盖确实限制cross，再在同一source-target集上比较32的检索质量与完整稳态GPU step time；增密时优先保留旧anchor再补点。不要先放松root/yaw条件来提高覆盖率。

## 3. 选型门限与CI：诊断保存没有解决统计不确定性

matched≥85%、4秒matched ADE≤5cm/cross ADE≤10cm作为工程选型门限可保留。但上一轮91.1%及±5.8pp来自其具体旧case/protocol，不能直接当成本轮固定manifest的CI。

当前每次验证使用相同source starts、targets、exemplars和Gaussian noise。同一checkpoint、相同环境的重复评估应一致；CI主要描述有限source clips对总体泛化估计的不确定性，不是每轮重新抽case导致的随机噪声。270个matched窗口来自90个source clips，镜像/重叠窗口不能当成270个独立观测。

`constraints_passed=false`只在点估计未满足门限时标注诊断候选，不计算CI。例如85.2%且CI跨过85%仍会标true；它没有“处理掉”统计不确定性。

建议保持固定case和现有选型规则，在最终报告中给出source_entry_id聚类CI；比较附近checkpoint时用相同case的paired cluster bootstrap差值，避免把1pp上下波动描述为确定收益。不必训练前新增一套复杂CI门控，更不能根据test/OOD调整验证门限。

## 开跑建议

可以按现有从零150 epoch计划启动。先查看第5/10 epoch的matched/cross style validation、root误差及条件敏感性，再判断优化是否有效；prior告警不单独作为失败或加大prior权重的依据。继续保持FP32、冻结VQ、不做decoder联合训练、不做rollout训练。

GLM的TF时间若能代表后续验证，30次验证约14.4分钟，另加初始化/统计开销。两步smoke的训练时间包含冷缓存与启动成本，不能推断完整GPU小时。未经稳态测量，不声称16→32“几乎无成本”。

- [Prior可达性原始记录](/home/shinn/桌面/multimedia/revision/NewCode/analysis/clip_recipe_preflight_review_2026-10-07/prior_feasibility.json)
- [Donor密度只读比较](/home/shinn/桌面/multimedia/revision/NewCode/analysis/clip_recipe_preflight_review_2026-10-07/donor_density.json)
