#!/usr/bin/env python
"""Collect the paper-parity runs into one markdown table.

    python analysis/summarize_paper_parity.py [--root .] [--out docs/table.md]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

METRICS = [
    ("mpjpe_cm", "MPJPE (cm)", "{:.4f}"),
    ("root_ade_cm", "RootADE (cm)", "{:.4f}"),
    ("heading_error_deg", "Heading (deg)", "{:.4f}"),
    ("velocity_dir_error_deg", "VelDir (deg)", "{:.4f}"),
    ("fid", "FID (pooled)", "{:.4f}"),
    ("fid_camdm_style", "FID (CAMDM-style, /dim)", "{:.4f}"),
    ("foot_sliding_cm", "F.S. (cm)", "{:.4f}"),
    ("jitteriness_cm", "Jitter (cm)", "{:.4f}"),
]

PROTOCOL_LABELS = {
    "A": "Protocol A: 10 styles, unmirrored, 905 windows (the paper's own test split)",
    "B": "Protocol B: 90 in-distribution styles, unmirrored, ~10k windows",
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--out", type=Path, default=None, help="optional markdown output path")
    parser.add_argument(
        "--prefixes",
        nargs="+",
        default=["camdm100", "paper_parity"],
        help="run-directory prefixes under eval_results/ (camdm100 = CAMDM extractor, paper_parity = 72-dim backup)",
    )
    args = parser.parse_args()

    runs: dict[str, dict[str, float]] = {}
    for prefix in args.prefixes:
        for summary_path in sorted((args.root / "eval_results").glob(f"{prefix}_*/motion_eval_summary.json")):
            tag = summary_path.parent.name.replace(f"{prefix}_", "")
            if tag in runs:
                continue
            payload = json.loads(summary_path.read_text(encoding="utf-8"))
            result = payload["results"][0]
            runs[tag] = {key: float(result[key]) for key, _, _ in METRICS if key in result}

    lines: list[str] = []
    for protocol in ("A", "B"):
        tags = sorted(tag for tag in runs if tag.startswith(f"{protocol}_"))
        if not tags:
            continue
        lines.append(f"### {PROTOCOL_LABELS[protocol]}")
        lines.append("")
        header = "| run | " + " | ".join(label for _, label, _ in METRICS) + " |"
        lines.append(header)
        lines.append("|" + "---|" * (len(METRICS) + 1))
        for tag in tags:
            row = [tag]
            for key, _, fmt in METRICS:
                value = runs[tag].get(key)
                row.append("n/a" if value is None else fmt.format(value))
            lines.append("| " + " | ".join(row) + " |")
        lines.append("")
    text = "\n".join(lines)
    print(text)
    if args.out is not None:
        args.out.write_text(text + "\n", encoding="utf-8")
        print(f"[Done] wrote {args.out}")


if __name__ == "__main__":
    main()
