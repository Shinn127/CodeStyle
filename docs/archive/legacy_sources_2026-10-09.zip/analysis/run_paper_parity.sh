#!/usr/bin/env bash
# Paper-parity evaluation: one extractor, one test set, all models.
#
#   Protocol A: the paper's own test set -- 10 styles, unmirrored, 905 windows
#               (database_100sty_375_memmap_head10_v4 reproduces the 2026-03 head10 DB;
#                the paper's MotionVQ row comes out digit-identical on it)
#   Protocol B: the 90 in-distribution styles, unmirrored, ~10k windows
#               (database_100sty_375_memmap_unmirrored)
#
# Extractor: checkpoints/fid_feature_extractor_full100_v4/best.pt, trained on all 100STYLE
# styles (see run_train_fid_feature_extractor_full100.sh).
#
# Usage: ./analysis/run_paper_parity.sh [protocol-a|protocol-b|all]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
PY="${PYTHON_BIN:-python}"
EXTRACTOR="${EXTRACTOR:-${ROOT}/checkpoints/fid_feature_extractor_full100_v4/best.pt}"
OUT_ROOT="${OUT_ROOT:-${ROOT}/eval_results}"
TAG_PREFIX="${TAG_PREFIX:-paper_parity}"

PAPER_CKPT="${ROOT}/checkpoints/basic_vqvae_375to291_32_4_2048/best.pt"
CKPT_100K="${ROOT}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048/best.pt"
CKPT_150EP="${ROOT}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt"

run_one() {
  local db="$1" ckpt="$2" tag="$3" taps="${4:-1}" extra="${5:-}"
  local out="${OUT_ROOT}/${TAG_PREFIX}_${tag}"
  mkdir -p "${out}"
  echo "=============================================================="
  echo "[Run] ${tag}  db=$(basename "${db}")  taps=${taps}  ckpt=$(basename "$(dirname "${ckpt}")")"
  # shellcheck disable=SC2086
  "${PY}" "${ROOT}/evaluate_motion_375to291.py" \
    --db "${db}" \
    --out-dir "${out}" \
    --models basic_vqvae \
    --basic-vqvae-ckpt "${ckpt}" \
    --test-fraction 1.0 \
    --fid-extractor-ckpt "${EXTRACTOR}" \
    --fid-bootstrap-samples 100 \
    --decode-smooth-taps "${taps}" \
    --device "${DEVICE:-cuda}" \
    ${extra} 2>&1 | tr '\r' '\n' | grep -E "^\[basic_vqvae\]|Error|Traceback" || true
}

PROTO="${1:-all}"
if [[ "${PROTO}" == "protocol-a" || "${PROTO}" == "all" ]]; then
  DB_A="${ROOT}/database_100sty_375_memmap_head10_v4"
  run_one "${DB_A}" "${PAPER_CKPT}" A_paper_taps1 1 "--allow-legacy-quantizer"
  run_one "${DB_A}" "${CKPT_100K}"  A_100k_taps1 1
  run_one "${DB_A}" "${CKPT_100K}"  A_100k_taps3 3
  run_one "${DB_A}" "${CKPT_150EP}" A_150ep_taps1 1
  run_one "${DB_A}" "${CKPT_150EP}" A_150ep_taps3 3
fi
if [[ "${PROTO}" == "protocol-b" || "${PROTO}" == "all" ]]; then
  DB_B="${ROOT}/database_100sty_375_memmap_unmirrored"
  run_one "${DB_B}" "${PAPER_CKPT}" B_paper_taps1 1 "--allow-legacy-quantizer"
  run_one "${DB_B}" "${CKPT_100K}"  B_100k_taps1 1
  run_one "${DB_B}" "${CKPT_150EP}" B_150ep_taps1 1
  run_one "${DB_B}" "${PAPER_CKPT}" B_paper_taps3 3 "--allow-legacy-quantizer"
  run_one "${DB_B}" "${CKPT_100K}"  B_100k_taps3 3
  run_one "${DB_B}" "${CKPT_150EP}" B_150ep_taps3 3
fi
echo "[Done] paper-parity runs written under ${OUT_ROOT}/${TAG_PREFIX}_*"
