"""Measure the ground-truth (data) floor of the representation metrics.

Runs the offline metric code with prediction == reference, so multi-frame error metrics
(MPJPE / rootADE / heading / vel-dir) come out as 0 by construction while the metrics that
are computed on the prediction alone (jitter) or on reference-derived contact masks (foot
sliding) yield the values a *perfect* model would score. That is the floor the paper's
0.252 cm jitter / 0.277 cm F.S. must be compared against.
"""

from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

NEWCODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEWCODE))

from Utils.motion_eval import MotionEvalConfig, compute_sequence_metric_sums  # noqa: E402
from Utils.vqvae_eval import select_eval_windows  # noqa: E402

DB = NEWCODE / "database_100sty_375_memmap"
CFG = MotionEvalConfig()


def load_db():
    meta = json.loads((DB / "meta.json").read_text())
    segs = json.loads((DB / "segments.json").read_text())
    x = np.memmap(DB / "X.f32", dtype=np.float32, mode="r", shape=(meta["num_frames"], 375))
    return meta, segs, x


def aggregate(records: dict[str, list[float]]) -> dict[str, float]:
    out = {}
    for key, (total, count) in records.items():
        out[key] = float(total / count) if count else float("nan")
    return out


class Accum:
    def __init__(self) -> None:
        self.sums: dict[str, float] = defaultdict(float)
        self.counts: dict[str, int] = defaultdict(int)

    def add(self, sums) -> None:
        self.sums["mpjpe"] += sums.mpjpe_sum_cm
        self.counts["mpjpe"] += sums.mpjpe_count
        self.sums["root_ade"] += sums.root_ade_sum_cm
        self.counts["root_ade"] += sums.root_ade_count
        self.sums["heading"] += sums.heading_error_sum_deg
        self.counts["heading"] += sums.heading_error_count
        self.sums["vel_dir"] += sums.velocity_dir_error_sum_deg
        self.counts["vel_dir"] += sums.velocity_dir_error_count
        self.sums["foot"] += sums.foot_sliding_sum_cm
        self.counts["foot"] += sums.foot_sliding_count
        self.sums["jitter"] += sums.jitter_sum_cm
        self.counts["jitter"] += sums.jitter_count
        self.sums["frames"] += sums.mpjpe_count / 24.0

    def metrics(self) -> dict[str, float]:
        return aggregate({k: (self.sums[k], self.counts[k]) for k in self.sums})


def score_window(x, start: int, frames: int) -> object:
    win = np.asarray(x[start : start + frames], dtype=np.float32)
    return compute_sequence_metric_sums(
        reference_375=win,
        prediction_375=win,
        cfg=CFG,
        motion_mean=None,
        motion_std=None,
    )


def main() -> None:
    meta, segs, x = load_db()

    # (a) exactly the in-training eval set: 90 val clips x 1 window of 60 frames, seed 1234
    preview = select_eval_windows(
        str(DB), split="val", clips=90, window_frames=60, windows_per_clip=1, min_frames=60, seed=1234
    )
    acc = Accum()
    for start, frames in preview:
        acc.add(score_window(x, start, frames))
    print(f"=== val eval set used in training ({len(preview)} windows of 60 frames) ===")
    for k, v in acc.metrics().items():
        print(f"  {k:8s} {v:.4f}   (count={acc.counts[k]:,})")

    # (b) the offline test split: seq_len 60, stride 30, precomputed clip-level split
    test_segs = [s for s in segs if s.get("split") == "test"]
    print(f"\n=== test split ({len(test_segs)} segments) ===")
    acc_all = Accum()
    per_style: dict[str, Accum] = defaultdict(Accum)
    n_windows = 0
    for seg in test_segs:
        stop = seg["frame_start"] + seg["num_frames"]
        starts = range(seg["frame_start"], stop - 60 + 1, 30)
        for st in starts:
            sums = score_window(x, st, 60)
            acc_all.add(sums)
            per_style[seg["style_name"]].add(sums)
            n_windows += 1
    print(f"windows: {n_windows:,}")
    for k, v in acc_all.metrics().items():
        print(f"  {k:8s} {v:.4f}   (count={acc_all.counts[k]:,})")

    rows = [
        (name, per_style[name].metrics().get("jitter", float("nan")), per_style[name].metrics().get("foot", float("nan")))
        for name in sorted(per_style)
    ]
    jitters = np.array([r[1] for r in rows])
    print(
        f"\nper-style real jitter: min={jitters.min():.4f} ({rows[int(jitters.argmin())][0]}) "
        f"median={np.median(jitters):.4f} max={jitters.max():.4f} ({rows[int(jitters.argmax())][0]})"
    )
    print("10 smoothest styles (real jitter):")
    for name, jit, fs in sorted(rows, key=lambda r: r[1])[:10]:
        print(f"  {name:20s} jitter={jit:.4f}  foot_sliding={fs:.4f}")


if __name__ == "__main__":
    main()
