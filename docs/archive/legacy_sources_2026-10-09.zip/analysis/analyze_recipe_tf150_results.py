"""Read-only TF150 report/representation/exposure audit; no generator updates or rollout."""
from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd
import torch
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from Utils.motion_eval import load_motion_model
from Utils.style_code_prior import sparse_code_histogram
from Utils.vq_target_cache import VQTargetCache

OUT=ROOT/'analysis/recipe_tf150_results_2026-10-07'


def read_report(name):
    folder=ROOT/'eval_results'/name
    return json.loads((folder/'minor_revision_generalization_summary.json').read_text()),pd.read_csv(folder/'minor_revision_generalization_per_sample.csv')


def paired_change(a,b,setting):
    cols=['source_entry_id','source_start','target_style']
    a=a[a.setting.str.startswith(setting)].copy();b=b[b.setting.str.startswith(setting)].copy()
    a['ok']=(a.pred_style==a.target_style).astype(float);b['ok']=(b.pred_style==b.target_style).astype(float)
    pair=a.merge(b,on=cols,suffixes=('_a','_b'),validate='one_to_one')
    if len(pair)!=len(a) or len(pair)!=len(b): raise ValueError('Paired reports have different cases')
    pair['dacc']=100*(pair.ok_b-pair.ok_a);pair['dade']=pair.root_ade_cm_b-pair.root_ade_cm_a
    groups=pair.groupby('source_entry_id').agg(n=('dacc','size'),acc=('dacc','sum'),ade=('dade','sum'))
    rng=np.random.default_rng(42);ids=rng.integers(len(groups),size=(1000,len(groups)))
    denominator=groups.n.to_numpy()[ids].sum(1)
    return dict(n=len(pair),clusters=len(groups),accuracy_change_pp=float(pair.dacc.mean()),
        accuracy_ci95_pp=np.percentile(groups.acc.to_numpy()[ids].sum(1)/denominator,[2.5,97.5]).tolist(),
        ade_change_cm=float(pair.dade.mean()),
        ade_ci95_cm=np.percentile(groups.ade.to_numpy()[ids].sum(1)/denominator,[2.5,97.5]).tolist())


def main():
    torch.set_num_threads(2);torch.set_float32_matmul_precision('highest')
    OUT.mkdir(exist_ok=True)
    db=ROOT/'database_100sty_375_memmap'
    names=json.loads((db/'StyleNames.json').read_text());all_names=json.loads((ROOT/'database_100sty_375_memmap_fid_full100/StyleNames.json').read_text())
    segments=json.loads((db/'segments.json').read_text());original={s['source_entry_id']:s for s in segments if not s['mirror']}
    meta=json.loads((db/'meta.json').read_text())
    raw=np.memmap(db/'X.f32',mode='r',dtype=np.float32,shape=(meta['num_frames'],375))
    history=[json.loads(row) for row in (ROOT/'checkpoints/flowmatch_recipe_tf150/history.jsonl').read_text().splitlines()]
    summary={}
    table=[]
    for e in [5,25,50,75,100,125,150]:
        report,rows=read_report(f'recipe_tf150_val_e{e:04d}_n5')
        a,b=report['summaries'][1:]
        table.append(dict(epoch=e,matched=a['target_style_acc_pct'],cross=b['target_style_acc_pct'],
            matched_ade=a['root_ade_cm'],cross_ade=b['root_ade_cm']))
    pd.DataFrame(table).to_csv(OUT/'validation_curve.csv',index=False)
    report,test=read_report('recipe_tf150_test_e0150_n5');cross=test[test.setting.str.startswith('cross')].copy()
    cross['ok']=cross.pred_style==cross.target_style
    style=cross.groupby('target_style').agg(n=('ok','size'),acc=('ok','mean'),ade=('root_ade_cm','mean'))
    style['name']=[names[int(i)] for i in style.index]
    style['acc_pct']=style.acc*100
    summary['test']=report['summaries']
    summary['cross_failures']=dict(source_retention_pct=100*float((cross.pred_style==cross.source_style).mean()),
        zero_target_styles=style[style.acc==0].name.tolist(),perfect_target_styles=style[style.acc==1].name.tolist(),
        macro_accuracy_pct=100*float(style.acc.mean()))
    report150,val150=read_report('recipe_tf150_val_e0150_n5')
    _,val50=read_report('recipe_tf150_val_e0050_n5');_,valbest=read_report('recipe_tf150_val_best_n5');_,val1=read_report('recipe_tf150_val_e0150_n1')
    summary['paired_validation']=dict(epoch50_to150=paired_change(val50,val150,'cross'),
        loss_best120_to150=paired_change(valbest,val150,'cross'),exemplars1_to5=paired_change(val1,val150,'cross'))
    summary['runtime']=dict(epochs=len(history),updates=len(history)*history[0]['train_num_batches'],
        elapsed_hours=sum(row['time_sec'] for row in history)/3600,
        training_hours=sum(row['train_time_sec'] for row in history)/3600,
        median_epoch_sec=float(np.median([r['time_sec'] for r in history[1:]])),
        cross_fraction=float(np.mean([r['train']['decoupled_fraction'] for r in history])),
        best_loss_epoch=min(history,key=lambda r:r['val']['loss'])['epoch'])
    actions={i:{s['suffix'] for s in segments if s['label']==i and s['split']=='train'} for i in range(90)}
    cross['action']=[original[int(i)]['suffix'] for i in cross.source_entry_id]
    cross['covered']=[a in actions[int(t)] for a,t in zip(cross.action,cross.target_style)]
    summary['action_coverage']=cross.groupby('covered').agg(n=('ok','size'),accuracy=('ok','mean')).to_dict('index')

    # Exactly reproduce the root/suffix gate's style probabilities. No VQ encode/decode needed.
    train=[s for s in segments if s['split']=='train']
    lengths=np.array([s['num_frames']-1 for s in train]);cumulative=lengths.cumsum();rng=np.random.default_rng(42)
    expected=np.zeros(90);count=0;eligible=0;source_counts=np.zeros(90)
    for _ in range(64):
        picks=rng.integers(cumulative[-1],size=512);which=np.searchsorted(cumulative,picks,side='right')
        before=np.r_[0,cumulative[:-1]][which];frame=np.array([train[i]['frame_start'] for i in which])+picks-before+1
        labels=np.array([train[i]['label'] for i in which]);suffix=np.array([train[i]['suffix'] for i in which])
        root=np.array(raw[frame,84:87]);dv=np.linalg.norm(root[:,None,[0,2]]-root[None,:,[0,2]],axis=-1)
        limits=np.maximum(.25,.2*np.linalg.norm(root[:,[0,2]],axis=-1))
        valid=(dv<=limits[:,None])&(np.abs(root[:,None,1]-root[None,:,1])<=30)&(labels[:,None]!=labels[None,:])&(suffix[:,None]==suffix[None,:])
        available=np.stack([valid[:,labels==s].any(1) for s in range(90)],axis=1)
        n=available.sum(1);eligible+=int((n>0).sum());count+=len(labels)
        expected+=(.3*available/np.maximum(n,1)[:,None]).sum(0)
        source_counts+=np.bincount(labels,minlength=90)
    style['expected_cross_target_share']=expected/expected.sum()
    style['source_frame_share']=source_counts/source_counts.sum()
    style['cross_exposure_ratio']=style.expected_cross_target_share/style.source_frame_share
    summary['cross_gate']=dict(proxy_source_frames=count,expected_cross_fraction=.3*eligible/count,
        spearman_exposure_vs_accuracy=float(spearmanr(style.cross_exposure_ratio,style.acc).statistic),
        note='64 sampled 512-frame train batches, mirror/length weights included; expected uniform over qualified styles, not actual logged target counts')
    print('Root gate audit finished',flush=True)

    model=load_motion_model(model_name='flowmatch_target',ckpt_path=ROOT/'checkpoints/flowmatch_recipe_tf150/epoch_0150.pt',num_styles=90).eval()
    cache=VQTargetCache(ROOT/'cache/vq_targets_vq150ep_repair_v2')
    book=model.vqvae.quantizer.embedding_weight.detach().numpy();slots=model.selected_style_slots
    def measure(indices):
        p=sparse_code_histogram(indices,selected_slots=range(32),num_embeddings=2048,topk=4)
        mu=p@book;var=np.maximum(0,p@(book*book)-mu*mu)
        u=book[indices[:,slots]];center=u.mean(0)
        lag=((u[:-10]-center)*(u[10:]-center)).mean(0)
        mass=[np.isin(indices[:,slot],np.flatnonzero(p[slot])).mean() for slot in slots]
        features={'mu8':mu[list(slots)].flatten(),'mu_var8':np.r_[mu[list(slots)].flatten(),var[list(slots)].flatten()],
            'mu32':mu.flatten(),'mu_var32':np.r_[mu.flatten(),var.flatten()],
            'mu_var_lag8':np.r_[mu[list(slots)].flatten(),var[list(slots)].flatten(),lag.flatten()]}
        return features,p[list(slots)],float(np.mean(mass))
    canonical=[];retained=[]
    for record in report150['config']['recipe_meta']['chosen_clips']:
        parts=[np.asarray(cache.indices[c['frame_start']:c['frame_start']+c['frames']],dtype=np.int64) for c in record['clips']]
        _,p,mass=measure(np.concatenate(parts));canonical.append(p);retained.append(mass)
    canonical=np.stack(canonical);style['recipe_head_mass']=retained
    train_features=[];train_labels=[];val_features=[];val_labels=[]
    for s in segments:
        if s['mirror'] or s['split'] not in ('train','val') or s['num_frames']<240:continue
        offsets=[0,(s['num_frames']-240)//2,s['num_frames']-240] if s['split']=='train' else [(s['num_frames']-240)//2]
        for off in offsets:
            start=s['frame_start']+off;f,_,_=measure(np.asarray(cache.indices[start:start+240],dtype=np.int64))
            if s['split']=='train':train_features.append(f);train_labels.append(s['label'])
            else:val_features.append(f);val_labels.append(s['label'])
    with torch.no_grad():
        for features in (train_features,val_features):
            mu=torch.from_numpy(np.stack([f['mu8'] for f in features]))
            e=model.style_selector.proto_to_style(mu).numpy()
            for f,value in zip(features,e):f['current_feature']=value
        current=model.style_selector(codebook_weight=model.vqvae.quantizer.embedding_weight,
            manual_probs=torch.from_numpy(canonical))
        canonical_h=current['style_proto'].numpy();canonical_e=current['style_feature'].numpy()
    probes={};y=np.eye(90)[train_labels]
    for key in train_features[0]:
        a=np.stack([f[key] for f in train_features]);b=np.stack([f[key] for f in val_features])
        mean=a.mean(0);std=a.std(0).clip(min=1e-5);a=(a-mean)/std;b=(b-mean)/std
        a=np.c_[a,np.ones(len(a))];b=np.c_[b,np.ones(len(b))]
        w=np.linalg.solve(a.T@a+np.eye(a.shape[1]),a.T@y)
        pred=(b@w).argmax(1)
        probes[key]=dict(dimensions=a.shape[1]-1,train_accuracy_pct=float(((a@w).argmax(1)==train_labels).mean()*100),
            validation_accuracy_pct=float((pred==val_labels).mean()*100),
            failed_targets=[names[int(t)] for t,q in zip(val_labels,pred) if t!=q])
    summary['representation_probe']=dict(train_clips=len(train_features)//3,train_windows=len(train_features),val_clips=len(val_features),
        lambda_ridge=1.,notes='Closed-set analytical ridge diagnostic on cached VQ window statistics. Only train fits/scaling; one central val window/clip. No generator/classifier updates, no OOD fitting. Not generation accuracy.',results=probes)
    summary['head_mass']=dict(mean=float(np.mean(retained)),min=float(np.min(retained)),max=float(np.max(retained)),
        spearman_vs_cross_accuracy=float(spearmanr(style.recipe_head_mass,style.acc).statistic))
    cloud=np.stack([f['current_feature'] for f in train_features]);scale=cloud.std(0).clip(min=1e-5)
    centers=np.stack([cloud[np.array(train_labels)==s].mean(0) for s in range(90)])
    ood=[]
    for path in sorted((ROOT/'eval_results/unseen_tf240_recipe_ep150/recipes').glob('*.json')):
        data=json.loads(path.read_text());p=np.zeros((8,2048),np.float32)
        for part in data['slots']:p[list(slots).index(part['slot']),part['codes']]=part['weights']
        with torch.no_grad():f=model.style_selector(codebook_weight=model.vqvae.quantizer.embedding_weight,manual_probs=torch.from_numpy(p))
        h=f['style_proto'].numpy()[0];e=f['style_feature'].numpy()[0]
        nearest_h=np.linalg.norm(canonical_h-h,axis=1).argmin();nearest_e=np.linalg.norm(canonical_e-e,axis=1).argmin()
        distance=np.linalg.norm((centers-e)/scale,axis=1)
        ood.append(dict(name=data['metadata']['style_name'],nearest_seen_prototype=names[int(nearest_h)],
            nearest_seen_feature=names[int(nearest_e)],nearest_cloud_center=names[int(distance.argmin())],
            feature_norm=float(np.linalg.norm(e)),scaled_center_distance=float(distance.min())))
    summary['ood_features']=ood
    summary['seen_feature_norm']=dict(min=float(np.linalg.norm(canonical_e,axis=1).min()),median=float(np.median(np.linalg.norm(canonical_e,axis=1))),max=float(np.linalg.norm(canonical_e,axis=1).max()))
    style['feature_norm']=np.linalg.norm(canonical_e,axis=1)
    summary['feature_norm_vs_cross_accuracy']=float(spearmanr(style.feature_norm,style.acc).statistic)
    style.sort_values('acc_pct').to_csv(OUT/'per_target_diagnostics.csv',index_label='target_style')
    (OUT/'audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({k:summary[k] for k in ['runtime','cross_failures','paired_validation','cross_gate','head_mass','seen_feature_norm','ood_features']},ensure_ascii=False,indent=2),flush=True)
    print('Ridge probes',[(k,v['validation_accuracy_pct']) for k,v in probes.items()],flush=True)
    fig,axes=plt.subplots(1,3,figsize=(14,3.6))
    epochs=np.array([r['epoch'] for r in history]);axes[0].plot(epochs,[r['train']['loss'] for r in history],label='Train (matched + cross)');axes[0].plot(epochs,[r['val']['loss'] for r in history],label='Validation (matched)');axes[0].axvline(51,color='gray',ls='--');axes[0].set(xlabel='Epoch',ylabel='Normalized latent MSE');axes[0].legend(fontsize=8)
    t=pd.DataFrame(table);axes[1].plot(t.epoch,t.matched,'o-',label='Matched');axes[1].plot(t.epoch,t.cross,'o-',label='Cross');axes[1].axhline(80,color='gray',ls=':');axes[1].set(xlabel='Epoch',ylabel='Validation style accuracy (%)',ylim=(0,100));axes[1].legend(fontsize=8)
    axes[2].hist(style.acc_pct,bins=np.arange(0,111,10),color='#c77743');axes[2].set(xlabel='Test cross accuracy per target (%)',ylabel='Number of target styles')
    fig.tight_layout();fig.savefig(OUT/'training_and_style.png',dpi=180);plt.close(fig)


if __name__=='__main__':main()
