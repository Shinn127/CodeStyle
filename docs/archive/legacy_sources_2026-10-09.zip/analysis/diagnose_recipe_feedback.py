"""Bounded CPU controls: identical flow latents, three decoder policies, no training/rollout."""
from pathlib import Path
import json
import sys
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from Utils.motion_eval import load_motion_model
from Utils.runtime import configure_torch_runtime,load_norm_stats
from Utils.reproducibility import case_noise_plan,state_fingerprint
from Utils.fid_feature_extractor import build_fid_feature_extractor_from_checkpoint
from evaluate_minor_revision_generalization import _classifier_stats
from simulate_realtime_flowmatch_control import _load_style_recipe


@torch.no_grad()
def main():
    torch.set_num_threads(2)
    configure_torch_runtime(device=torch.device('cpu'),tf32=False,cudnn_benchmark=False,matmul_precision='highest')
    model=load_motion_model(model_name='flowmatch_target',ckpt_path=ROOT/'checkpoints/flowmatch_tf150_staged_noise/best.pt',num_styles=90).eval()
    vq_before=state_fingerprint(model.vqvae.state_dict())
    classifier,meta=build_fid_feature_extractor_from_checkpoint(ROOT/'checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth',map_location='cpu')
    classifier.eval()
    mean,std=load_norm_stats(ROOT/'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/norm_stats.npz')
    saved=json.loads((ROOT/'analysis/recipe_failure_diagnostic_2026-10-06.json').read_text())
    starts=saved['starts'];targets=np.array(saved['targets'])
    db=ROOT/'database_100sty_375_memmap'
    names=json.loads((db/'StyleNames.json').read_text())
    raw=np.memmap(db/'X.f32',mode='r',dtype=np.float32,shape=(7068516,375))
    x=torch.from_numpy((np.stack([raw[s:s+241] for s in starts])-mean)/std)
    current=x[:,:-1].reshape(-1,375)
    previous=torch.cat([model.frame_latent(current[b:b+512]) for b in range(0,len(current),512)])
    policies={'continuous':dict(requantize=False,latent_clip=False),
              'clip_only':dict(requantize=False,latent_clip=True),
              'clip_quantized':dict(requantize=True,latent_clip=True)}
    def classify(raw,labels):
        pred,confidence,_=_classifier_stats(classifier,raw,np.asarray(labels),device=torch.device('cpu'),
            classifier_window=240,classifier_stride=240,classifier_batch_size=16,joint_set=meta['joint_set'])
        return dict(accuracy_pct=float(np.mean(pred==labels)*100),predictions=pred.tolist(),confidence=confidence.tolist())
    def sample(feature,labels):
        feature=feature[:,None].expand(-1,240,-1).reshape(-1,64)
        noise=case_noise_plan(model,starts,labels,241,seed=42,noise_std=1.).reshape(-1,128)
        latents=[]
        for b in range(0,len(current),512):
            latents.append(model.sample_latent(x_curr=current[b:b+512],style_label=None,
                prev_latent=previous[b:b+512],style_feature=feature[b:b+512],z0=noise[b:b+512],num_steps=8))
        latent=torch.cat(latents)
        result={}
        for name,policy in policies.items():
            motion=torch.cat([model.feedback_state(latent[b:b+512],**policy)[0] for b in range(0,len(latent),512)])
            output=motion.reshape(16,240,291).numpy()*std[84:]+mean[84:]
            packed=np.concatenate((np.zeros((16,240,84),np.float32),output),-1)
            row=classify(packed,labels)
            if (np.asarray(labels)<90).all():
                row['matched_accuracy_pct']=np.mean(np.array(row['predictions'])[:8]==np.asarray(labels)[:8])*100
                row['cross_accuracy_pct']=np.mean(np.array(row['predictions'])[8:]==np.asarray(labels)[8:])*100
            else:
                row['per_target_style_acc_pct']={meta['class_names'][int(label)]:float(np.mean(
                    np.asarray(row['predictions'])[np.asarray(labels)==label]==label)*100) for label in np.unique(labels)}
            result[name]=row
        return result
    label_feature=model.encode_conditions(x_curr=x[:,0],style_label=torch.from_numpy(targets))[2]
    controls={'seen_label':sample(label_feature,targets)}
    # Five independent 240-frame train crops saved by the preceding cache-based diagnosis.
    cachedir=ROOT/'cache/vq_targets_vq150ep_repair_v2'
    info=json.loads((cachedir/'meta.json').read_text())
    indices=np.memmap(cachedir/info['indices_file'],mode='r',dtype=info['indices_dtype'],shape=(info['num_frames'],info['num_codebooks']))
    from Utils.style_code_prior import sparse_code_histogram
    recipes=[]
    for label in targets:
        parts=[indices[r['start']:r['start']+240] for r in saved['train_recipe_exemplars'][int(label)]]
        recipes.append(sparse_code_histogram(np.concatenate(parts),selected_slots=model.selected_style_slots,num_embeddings=2048,topk=4))
    feature=model.encode_conditions(x_curr=x[:,0],style_label=None,manual_style_probs=torch.from_numpy(np.stack(recipes)))[2]
    controls['seen_train_clip_recipe']=sample(feature,targets)
    print('[Probe] Seen decoder policy comparisons complete',flush=True)
    # Reuse the user's real exported OOD recipes; names are evaluation labels, never embeddings.
    ood_dir=ROOT/'eval_results/unseen_tf240_staged_noise'
    manifest=json.loads((ood_dir/'case_manifest.json').read_text())
    ood=[];ood_targets=[]
    for style in ('Zombie','WiggleHips'):
        index=next(i for i,r in enumerate(manifest['recipes']) if r['style_name']==style)
        p,_,label,_=_load_style_recipe(ood_dir/'recipes'/f'style_{index:02d}.json',style_names=names,
            selected_slots=model.selected_style_slots,num_embeddings=2048,fallback_style_label=None,
            vq_fingerprint=vq_before,norm_fingerprint=model.eval_fingerprints['norm_fingerprint'])
        assert label is None
        ood.extend([p]*8);ood_targets.extend([meta['class_names'].index(style)]*8)
    feature=model.encode_conditions(x_curr=x[:,0],style_label=None,manual_style_probs=torch.from_numpy(np.stack(ood)))[2]
    controls['ood_zombie_wigglehips_recipe']=sample(feature,np.array(ood_targets))
    # Diagnose the clipping ceiling using all 31 reference clips (no flow sampling).
    source_meta=json.loads((ROOT/'database_100sty_375_memmap_zeroshot/meta.json').read_text())
    source=np.memmap(ROOT/'database_100sty_375_memmap_zeroshot/X.f32',mode='r',dtype=np.float32,shape=(source_meta['num_frames'],375))
    ae={name:[] for name in ('quantized_ae','clip_quantized_ae')};reference_labels=[];changed=[]
    for plan in manifest['recipes']:
        for c in plan['clips']:
            if c['role']!='reference':continue
            r=np.array(source[c['start']:c['start']+240],copy=True)
            z=model.frame_latent(torch.from_numpy((r-mean)/std))
            clipped=model.clip_latent_to_data_bounds(z)
            changed.append(float((z!=clipped).float().mean()))
            for name,policy in [('quantized_ae',dict(requantize=False,latent_clip=False)),
                                ('clip_quantized_ae',dict(requantize=True,latent_clip=True))]:
                motion=model.feedback_state(z,**policy)[0].numpy()*std[84:]+mean[84:]
                ae[name].append(np.concatenate((np.zeros((240,84),np.float32),motion),-1))
            reference_labels.append(plan['classifier_label'])
    ae_stats={name:classify(np.stack(value),np.array(reference_labels)) for name,value in ae.items()}
    assert state_fingerprint(model.vqvae.state_dict())==vq_before
    payload=dict(seed=42,split='validation',mode='teacher_forced',device='cpu/fp32/highest',
        note='Same flow latents for each decoder-policy contrast. 16 validation generated clips, 31 OOD reference clips; no rollout/training.',
        generation=controls,reference=ae_stats,mean_ood_reference_latent_clipped_fraction=np.mean(changed),vq_unchanged=True)
    (ROOT/'analysis/recipe_feedback_diagnostic_2026-10-06.json').write_text(json.dumps(payload,indent=2))
    print({k:{name:round(row['accuracy_pct'],2) for name,row in v.items()} for k,v in controls.items()},flush=True)
    print({k:round(v['accuracy_pct'],2) for k,v in ae_stats.items()},flush=True)


if __name__=='__main__':main()
