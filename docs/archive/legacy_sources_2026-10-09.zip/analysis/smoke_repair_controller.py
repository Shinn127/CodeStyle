"""Explicit 100-update GPU entry smoke; does not consume the A/B/C epoch budget."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis.run_repair_pipeline import commands
from Utils.motion_eval import load_motion_model, reconstruct_motion_batch
from Utils.reproducibility import case_noise_plan, state_fingerprint
from Utils.runtime import load_checkpoint, load_norm_stats
import train_flowmatch_vqvae_controller as trainer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--microbatch-size', type=int, choices=[128, 256, 512], default=512)
    parser.add_argument('--style-refinement', action='store_true', help='Use prior init/raw prototypes/entropy=.003')
    args = parser.parse_args(); args.output = args.output.resolve(); args.device = 'cuda'
    if not torch.cuda.is_available():
        raise RuntimeError('GPU smoke requires CUDA; no CPU/full training fallback')
    args.output.mkdir(parents=True, exist_ok=True)
    _, stages, _ = commands(args)
    if args.style_refinement:
        from analysis.run_style_refinement import apply_style_options
        for command in stages:
            apply_style_options(command)
    results = []
    for label, command in zip('ABC', stages):
        if '--resume' in command:
            raise ValueError('Smoke directory already contains a run; select a fresh output')
        command += ['--epochs', '1', '--rollout-val-every', '0', '--max-train-batches', '100',
                    '--max-val-batches', '1', '--save-every', '0']
        sys.argv = command[1:]
        torch.cuda.reset_peak_memory_stats()
        begin = time.perf_counter(); trainer.main(); torch.cuda.synchronize()
        elapsed = time.perf_counter() - begin
        out = args.output / label; cp = load_checkpoint(out / 'latest.pt')
        history = [json.loads(line) for line in (out / 'history.jsonl').read_text().splitlines()]
        updates = int(history[0]['train']['num_samples'] / 512)
        if updates != 100:
            raise ValueError(f'Smoke needs 100 optimizer updates, got {updates}')
        epoch_train_sec = history[0]['train_time_sec'] / updates * history[0]['train_num_batches']
        model = load_motion_model('flowmatch_target', out / 'latest.pt', num_styles=90).cuda().eval()
        before = state_fingerprint(model.vqvae.state_dict())
        feedback = model.feedback_state
        def checked_feedback(*parts, **kwargs):
            motion, latent = feedback(*parts, **kwargs)
            torch.testing.assert_close(motion, model.vqvae.decode(latent), rtol=0, atol=0)
            return motion, latent
        model.feedback_state = checked_feedback
        mean, std = load_norm_stats(cp['args']['norm_stats'])
        db = Path(cp['args']['db']); meta = json.loads((db / 'meta.json').read_text())
        segments = json.loads((db / 'segments.json').read_text())
        segment = next(s for s in segments if s['split'] == 'val' and not s.get('mirror') and s['num_frames'] >= 600)
        start = segment['frame_start']; target = segment['label']
        source = np.memmap(db / 'X.f32', mode='r', dtype='float32', shape=(meta['num_frames'], 375))
        for frames in (60, 600):
            raw = np.array(source[start:start + frames], copy=True)
            x = torch.from_numpy((raw - mean) / std)[None].cuda()
            generated = reconstruct_motion_batch(model_name='flowmatch_target', model=model, x=x,
                style_label=torch.tensor([target], device='cuda'),
                noise_plan=case_noise_plan(model, [start], [target], frames), flow_ode_steps=8)
            if not torch.isfinite(generated).all():
                raise FloatingPointError(f'{label}: non-finite {frames}-frame rollout')
        if state_fingerprint(model.vqvae.state_dict()) != before:
            raise RuntimeError('Frozen VQ state changed during rollout')
        bundled = {k[6:]: v for k, v in cp['model'].items() if k.startswith('vqvae.')}
        if state_fingerprint(bundled) != cp['args']['fingerprints']['vq_state_sha256']:
            raise RuntimeError('Frozen VQ state changed during training')
        results.append({'stage': label, 'optimizer_steps': updates, 'entry_elapsed_sec': elapsed,
            'peak_gpu_gib': torch.cuda.max_memory_allocated() / 1024**3,
            'estimated_epoch_training_sec': epoch_train_sec,
            'estimated_50epoch_training_gpu_hours': epoch_train_sec * 50 / 3600,
            'note': 'Estimate extrapolates 100 updates; excludes preparation, full validation rollouts and test. Entry time includes train-only stats.'})
        (args.output / 'smoke_summary.json').write_text(json.dumps(results, indent=2))
        del model; torch.cuda.empty_cache()


if __name__ == '__main__':
    main()
