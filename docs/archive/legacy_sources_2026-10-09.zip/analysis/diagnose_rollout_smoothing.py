#!/usr/bin/env python
"""How much of the style-accuracy gap is *rollout noise* vs *style control*?

Applies cheap, inference-time transformations to the decoded rollout and re-scores style accuracy
with the same classifier/protocol as the evaluation script:

  * ODE steps            8 / 16 / 32          (better latents)
  * causal EMA on the motion block           (real-time legal smoothing)
  * non-causal binomial 3/5-tap              (offline smoothing)

Nothing is retrained. Usage:

    python analysis/diagnose_rollout_smoothing.py --controller-ckpt checkpoints/flowmatch_vqvae_controller_decouple_p02/best.pt
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from Utils.fid_feature_extractor import (  # noqa: E402
    JOINT_SET_YBOT15,
    build_fid_feature_extractor_from_checkpoint,
    motion375_clip_to_classifier_input,
)
from Utils.motion_eval import load_motion_model, reconstruct_motion_batch, smooth_motion_block  # noqa: E402
from Utils.runtime import load_norm_stats, resolve_device, set_seed  # noqa: E402
from dataset import build_train_val_test_datasets  # noqa: E402


def causal_ema(seq: torch.Tensor, alpha: float) -> torch.Tensor:
    """Causal exponential moving average over time on the 291-dim motion block (per sequence)."""
    if alpha >= 1.0:
        return seq
    traj, motion = seq[..., :84], seq[..., 84:]
    out = torch.empty_like(motion)
    state = motion[:, 0]
    out[:, 0] = state
    for step in range(1, motion.size(1)):
        state = alpha * state + (1.0 - alpha) * motion[:, step]
        out[:, step] = state
    return torch.cat((traj, out), dim=-1)


def score(*, model, x, labels, target_labels, classifier, device, mean, std, ode_steps, smooth):
    preds, confs = [], []
    for start in range(0, x.size(0), 128):
        xb = x[start:start + 128]
        lb = labels[start:start + 128]
        with torch.no_grad():
            pred = reconstruct_motion_batch(
                model_name="flowmatch_velocity",
                model=model,
                x=xb,
                style_label=lb,
                flow_eval_mode="rollout",
                flow_solver="euler",
                flow_ode_steps=int(ode_steps),
                flow_noise_std=None,
                flow_requantize_z=False,
                flow_latent_clip=True,
            )
        if pred.dim() == 2:
            pred = pred.unsqueeze(1)
        pred = smooth(pred)
        raw = pred * std + mean
        inp = motion375_clip_to_classifier_input(raw, joint_set=JOINT_SET_YBOT15)
        with torch.no_grad():
            _, logits = classifier(inp.to(device=device))
        probs = torch.softmax(logits, dim=1)
        preds.append(probs.argmax(1).cpu())
        confs.append(probs.gather(1, target_labels[start:start + 128].unsqueeze(1)).squeeze(1).cpu())
    pred = torch.cat(preds).to(target_labels.device)
    conf = torch.cat(confs).to(target_labels.device)
    return float((pred == target_labels).float().mean()), float(conf.mean())


def main() -> None:
    parser = argparse.ArgumentParser(description="Rollout smoothing / solver-step diagnostic")
    parser.add_argument("--controller-ckpt", type=Path,
                        default=ROOT / "checkpoints" / "flowmatch_vqvae_controller_decouple_p02" / "best.pt")
    parser.add_argument("--db", type=Path, default=ROOT / "database_100sty_375_memmap")
    parser.add_argument("--classifier-ckpt", type=Path,
                        default=ROOT / "checkpoints" / "fid_feature_extractor_camdm100_mirror" / "100style_position_classifier.pth")
    parser.add_argument("--num-sources", type=int, default=200)
    parser.add_argument("--targets-per-source", type=int, default=5)
    parser.add_argument("--device", type=str, default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    set_seed(args.seed)
    device = resolve_device(args.device)
    model = load_motion_model(model_name="flowmatch_velocity", ckpt_path=args.controller_ckpt, num_styles=90)
    model = model.to(device).eval()
    ckpt_args = torch.load(args.controller_ckpt, map_location="cpu", weights_only=False).get("args", {})
    norm_stats = Path(str(ckpt_args.get("norm_stats") or (args.controller_ckpt.parent / "norm_stats.npz")))
    mean_np, std_np = load_norm_stats(norm_stats)
    mean = torch.from_numpy(mean_np.astype(np.float32)).to(device)
    std = torch.from_numpy(std_np.astype(np.float32)).to(device)
    classifier, _ = build_fid_feature_extractor_from_checkpoint(args.classifier_ckpt, map_location="cpu")
    classifier = classifier.to(device).eval()

    _, _, test_ds = build_train_val_test_datasets(
        db_path=args.db, seq_len=60, stride=30, normalize=False, val_ratio=0.1, test_ratio=0.1, seed=args.seed
    )
    rng = np.random.default_rng(args.seed)
    idx = np.sort(rng.choice(len(test_ds), size=min(args.num_sources, len(test_ds)), replace=False))
    x_raw = torch.stack([test_ds[int(i)]["x"] for i in idx]).float()
    src = torch.tensor([int(test_ds[int(i)]["label"]) for i in idx], dtype=torch.long).to(device)
    x = (x_raw.to(device) - mean) / std
    offs = torch.tensor([1, 7, 19, 37, 61], device=device)
    cross_targets = (src.unsqueeze(1) + offs) % 90

    variants = [
        ("raw, 8 steps", 8, lambda s: s),
        ("raw, 16 steps", 16, lambda s: s),
        ("raw, 32 steps", 32, lambda s: s),
        ("causal EMA a=0.5, 8", 8, lambda s: causal_ema(s, 0.5)),
        ("causal EMA a=0.3, 8", 8, lambda s: causal_ema(s, 0.3)),
        ("3-tap binomial, 8", 8, lambda s: smooth_motion_block(s, 3)),
        ("5-tap binomial, 8", 8, lambda s: smooth_motion_block(s, 5)),
    ]
    rows = []
    print(f"[Info] controller: {args.controller_ckpt}")
    for name, steps, smooth in variants:
        m_acc, m_conf = score(model=model, x=x, labels=src, target_labels=src, classifier=classifier,
                              device=device, mean=mean, std=std, ode_steps=steps, smooth=smooth)
        flat_x = x.repeat_interleave(cross_targets.size(1), dim=0)
        flat_lbl = cross_targets.reshape(-1)
        c_acc, c_conf = score(model=model, x=flat_x, labels=flat_lbl, target_labels=flat_lbl,
                              classifier=classifier, device=device, mean=mean, std=std,
                              ode_steps=steps, smooth=smooth)
        rows.append({"variant": name, "ode_steps": steps, "matched_acc": m_acc, "matched_conf": m_conf,
                     "cross_acc": c_acc, "cross_conf": c_conf})
        print(f"  {name:22s} matched {100*m_acc:6.2f}%  cross {100*c_acc:6.2f}%")
    if args.out is not None:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
        print(f"[Done] wrote {args.out}")


if __name__ == "__main__":
    main()
