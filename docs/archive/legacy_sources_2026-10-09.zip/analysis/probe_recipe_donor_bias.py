"""Root-qualified nearest-foot versus uniform-donor control; reads train data only."""
from pathlib import Path
import json
import sys

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from Utils.vq_target_cache import VQTargetCache


def main():
    db=ROOT/'database_100sty_375_memmap'
    names=json.loads((db/'StyleNames.json').read_text())
    segments=[s for s in json.loads((db/'segments.json').read_text()) if s['split']=='train']
    meta=json.loads((db/'meta.json').read_text());raw=np.memmap(db/'X.f32',mode='r',dtype=np.float32,shape=(meta['num_frames'],375))
    cache=VQTargetCache(ROOT/'cache/vq_targets_vq150ep_repair_v2')
    lengths=np.array([s['num_frames']-1 for s in segments]);cumulative=lengths.cumsum();rng=np.random.default_rng(42)
    slots=[4,9,10,17,18,20,23,24];rows=[];selected_ids=[];uniform_ids=[];target_labels=[]
    for _ in range(64):
        picks=rng.integers(cumulative[-1],size=512);which=np.searchsorted(cumulative,picks,side='right')
        frame=np.array([segments[i]['frame_start'] for i in which])+picks-np.r_[0,cumulative[:-1]][which]+1
        labels=np.array([segments[i]['label'] for i in which]);suffix=np.array([segments[i]['suffix'] for i in which])
        motion=np.array(raw[frame,84:]);root=motion[:,:3];feet=motion[:,3:75].reshape(512,24,3)[:,[18,19,22,23]]
        dv=np.linalg.norm(root[:,None,[0,2]]-root[None,:,[0,2]],axis=-1)
        limits=np.maximum(.25,.2*np.linalg.norm(root[:,[0,2]],axis=-1));yaw=np.abs(root[:,None,1]-root[None,:,1])
        valid=(dv<=limits[:,None])&(yaw<=30)&(labels[:,None]!=labels[None,:])&(suffix[:,None]==suffix[None,:])
        cost=((feet[:,None]-feet[None])/.2)**2
        cost=cost.mean(axis=(-1,-2))+(dv/.25)**2+(yaw/30)**2
        for i in np.flatnonzero(rng.random(512)<.3):
            candidates=np.flatnonzero(valid[i])
            if not len(candidates):continue
            target=int(rng.choice(np.unique(labels[candidates])))
            candidates=candidates[labels[candidates]==target]
            near=int(candidates[cost[i,candidates].argmin()]);other=int(rng.choice(candidates))
            def span(j):return float(np.linalg.norm((feet[j,:2].mean(0)-feet[j,2:].mean(0))[[0,2]]))
            rows.append(dict(style=target,name=names[target],candidate_count=len(candidates),nearest_distance=float(np.linalg.norm(feet[i]-feet[near])),
                uniform_distance=float(np.linalg.norm(feet[i]-feet[other])),nearest_span=span(near),uniform_span=span(other),
                nearest_max_height=float(feet[near,:,1].max()),uniform_max_height=float(feet[other,:,1].max())))
            selected_ids.append(frame[near]);uniform_ids.append(frame[other]);target_labels.append(target)
    frame_table=pd.DataFrame(rows)
    table=frame_table.groupby(['style','name']).mean();table['n']=frame_table.groupby(['style','name']).size()
    near=np.asarray(cache.indices[selected_ids])[:,slots];other=np.asarray(cache.indices[uniform_ids])[:,slots];labels=np.array(target_labels)
    def entropy(data):
        values=[]
        for slot in range(8):
            counts=np.bincount(data[:,slot],minlength=2048);p=counts[counts>0]/counts.sum()
            values.append(-(p*np.log(p)).sum())
        return float(np.mean(values))
    for label,name in table.index:
        mask=labels==label
        table.loc[(label,name),'nearest_entropy']=entropy(near[mask]);table.loc[(label,name),'uniform_entropy']=entropy(other[mask])
    out=ROOT/'analysis/recipe_tf150_results_2026-10-07'
    table.to_csv(out/'donor_bias.csv')
    summary=dict(seed=42,matched_pairs=len(rows),source_frames=64*512,
        singleton_candidate_fraction=float((frame_table.candidate_count==1).mean()),
        mean_candidates_per_chosen_style=float(frame_table.candidate_count.mean()),
        nearest_mean_distance=float(frame_table.nearest_distance.mean()),uniform_mean_distance=float(frame_table.uniform_distance.mean()),
        nearest_mean_span=float(frame_table.nearest_span.mean()),uniform_mean_span=float(frame_table.uniform_span.mean()),
        nearest_mean_max_height=float(frame_table.nearest_max_height.mean()),uniform_mean_max_height=float(frame_table.uniform_max_height.mean()),
        mean_slot_entropy_difference=float((table.nearest_entropy-table.uniform_entropy).mean()),
        limits='Expected training sampling proxy, same requested style/root/suffix eligibility. Not actual training target logs and not a generation metric.')
    (out/'donor_bias.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
    print(table.loc[[(names.index(name),name) for name in ['BigSteps','March','Skip','Morris','Kick','Neutral','Teapot']]].to_string())


if __name__=='__main__':main()
