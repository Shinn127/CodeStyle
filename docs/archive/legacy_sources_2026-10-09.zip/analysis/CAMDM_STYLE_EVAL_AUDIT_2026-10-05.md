# CAMDM风格分类与60帧评估时长核对

2026-10-05读取CAMDM官方main，commit `f4419ea01d7c8e844948ef6df92f265ef5012aa9`。本轮是代码/协议审计，没有训练新classifier、修改生成器或重新运行rollout。

## 官方公开代码实际做了什么

1. [`process_train_data.py`](https://github.com/AIGAnimation/CAMDM/blob/f4419ea01d7c8e844948ef6df92f265ef5012aa9/Evaluation/feature_extractor/process_train_data.py)把BVH按.01缩放到米，设`target_fps=30`，按原始fps/30的整数因子做temporal downsampling；60fps输入因此每两帧取一帧。随后统一面向方向、落地，取15个关节的local positions，减去每帧Hips的三维位置。这个整数采样实现对任意非整倍数fps不保证精确30fps，当前60fps数据的2倍抽样不存在该歧义。
2. [`train_classifier.py`](https://github.com/AIGAnimation/CAMDM/blob/f4419ea01d7c8e844948ef6df92f265ef5012aa9/Evaluation/feature_extractor/train_classifier.py)固定`window_size=60`，数据窗口`clip_offset=10`，输入[B,45,60]；两层残差Conv1d后flatten，经1024/512维FC和100类logits。用真实motion做CrossEntropy训练；公开脚本无train/val/test分离，打印与checkpoint字段`acc`都是训练窗口的top-1 accuracy。它不是生成动作的style accuracy。
3. [`compute_feat.py`](https://github.com/AIGAnimation/CAMDM/blob/f4419ea01d7c8e844948ef6df92f265ef5012aa9/Evaluation/compute_feat.py)读取生成BVH，复用上述预处理，使用60帧非重叠窗口（step=60），分类器eval/no_grad，按argmax得到每个窗口的style name；保存`feats`和`predicted`到NPZ。这里没有把全序列多个窗口先平均logits再输出一个style。
4. 公开Evaluation目录的最终指标脚本是FID、foot sliding/coherence和trajectory/orientation error。未发现汇总generated matched/cross/unseen style accuracy的独立入口。若基于NPZ计算它，最直接的额外定义是`mean(argmax(logits_window)==requested_style)`；style切换序列还需明确各窗口的目标及过渡段规则。不能把classifier训练acc字段用作生成指标，也不能声称本项目clip-level聚合规则由CAMDM官方完整规定。

## 本项目与CAMDM的差异

| 项目 | CAMDM公开实现 | 当前本地classifier/评估 |
|---|---|---|
| 时序采样 | 60fps输入降为30fps | 原始60fps，checkpoint temporal_stride=1 |
| 单窗口帧数 | 60 | 60 |
| 单窗口物理跨度 | 约2秒 | 约1秒 |
| Classifier训练窗口step | 10@30fps，约.333秒 | 10@60fps，约.167秒 |
| 生成序列评估切窗 | 60@30fps，非重叠 | step由classifier_stride指定；当前60帧horizon只有1窗口 |
| 多窗口结果 | 保存每窗口argmax预测 | 平均窗口logits，softmax后给每clip一个预测 |
| Hips坐标 | 每帧减去Hips XYZ，Hips为零 | feature直接取motion375 positions；保留Hips高度 |
| 网络 | Conv+flatten+FC，固定60帧 | 同构、本地重新训练，固定60帧 |

读取当前`fid_feature_extractor_camdm100_mirror/100style_position_classifier.pth`确认：100类、ybot15、45维、window_size60、temporal_stride1、include_mirror=True、50epoch，训练数据为本地full100库。当前generator特征构造只减去root的XZ，再转到root facing frame；抽查原始Hips为[0,.8767,0]等。官方预处理还减去Hips Y，并通过髋/肩估计面向，因此仅“同为root-relative、15 joints”不足以宣称全部预处理一致。

本地classifier的训练和评估采用同一本地坐标约定，以上差异不等于当前存在train/eval坐标错配。但不能直接套用官方权重到当前输入，或把当前数值当成完全相同CAMDM协议。镜像、本地retarget骨架与独立classifier训练也需一并标注。

本地相关位置：[分类器固定形状](/home/shinn/桌面/multimedia/revision/NewCode/Utils/fid_feature_extractor.py:102)、[窗口logits聚合](/home/shinn/桌面/multimedia/revision/NewCode/evaluate_minor_revision_generalization.py:140)、[classifier训练取帧](/home/shinn/桌面/multimedia/revision/NewCode/train_fid_feature_extractor_camdm.py:122)、[generator位置坐标](/home/shinn/桌面/multimedia/revision/NewCode/generate_database_100sty.py:487)。

## 60帧是否太短

用户的怀疑有实际依据：本项目观察时长只有CAMDM的一半。节奏、摆动、接触周期等时间性style线索可能因此不足，这是假设，需要长度对照。不能仅以“CAMDM也用60帧”反驳，也不能从官方2秒选择推断2秒必然最优。

当前真实motion96.4%、TF matched91.3%，但TF cross仅.06%、source retention87.58%，说明现有1秒窗口已经能识别大量真实/源风格，当前cross问题不太可能完全由短窗口解释。另外classifier按全量clips训练，96.4%不是独立classifier-heldout泛化准确率；它仍可作同cases参考，但不能独自证明1秒对所有style足够。

需要区分三个变量：

- 生成horizon：控制器生成多久，关系到反馈稳定性/换风格收敛。
- classifier观察跨度：一次预测看多久，关系到风格识别信息。
- clip聚合跨度：把多少个窗口的预测合成一个clip结果，可能提高稳定性，也可能掩盖局部失败。

现有`--horizons 120/240`仍调用60帧classifier，只改变生成/聚合跨度。原模型`fc1`输入固定128×60，不能直接喂120/240帧；把120帧压成60帧再喂目前60fps训练的classifier，也会改变时间采样分布，不能当正式2秒对照。

## 推荐的有限对照

1. 保留现有1秒结果与classifier，作为历史协议。修正TF/rollout命名，classifier只看生成帧，记录effective fps/window_seconds/聚合方式/源style retention。
2. 优先新增一个**30fps×60帧=2秒**的独立classifier，保持当前网络大小与训练目标，训练和生成评估统一按每两帧取一帧。若只测试“时长效应”，先保持本地骨架/坐标/镜像约定不变；若同时改为CAMDM的Hips centering/forward alignment，应作为另一明确协议，不能把效果全部归因于时长。
3. classifier使用原始clip级独立train/val/test，镜像与相邻窗口归属于同source_entry_id，100类都进入classifier训练、但generator仍只训练90类。先比较1秒与2秒在独立真实motion、quantized AE上的per-style/macro accuracy与混淆，再评估相同source/target cases的matched/cross/OOD。全量训练的legacy classifier结果继续独立标注。
4. 用120个原始60fps生成帧形成60个30fps输入帧，排除GT context；source长度与context按实际数据打包方式计算。采样不可跨clip边界，fps改变只在classifier输入侧进行，generator仍60fps、FP32、冻结VQ，训练stride仍1。
5. 同时保存每个分类窗口的target hit/source retention和clip级聚合，避免长序列平均隐藏style失效。若之后检查cross启动与稳定阶段，分别报告0–1秒与后续区间，不在主报告中隐去失败的启动段。当前不新增rollout运行。
6. 只有独立真实motion对照显示2秒仍缺少重要线索时，再考虑4秒classifier；不默认启动多个长度sweep。原1秒与新2秒必须分别列结果，85/80目标对应的主协议提前固定。

不能预先预测2秒会把cross从.06%提升到80%；它解决评估观察时长问题，source-style条件依赖和反馈稳定性仍需独立验证。
