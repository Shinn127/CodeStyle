"""Bounded CPU recipe/AE audit; no flow sampling or rollout. One reference per unseen style."""
from pathlib import Path
import json
import sys

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from evaluate_unseen_style import read_db, encode_recipe
from evaluate_minor_revision_generalization import _classifier_stats
from Utils.motion_eval import load_motion_model
from Utils.fid_feature_extractor import build_fid_feature_extractor_from_checkpoint
from Utils.runtime import configure_torch_runtime, load_norm_stats
from Utils.reproducibility import state_fingerprint
from Utils.style_code_prior import sparse_code_histogram


@torch.no_grad()
def main():
    torch.set_num_threads(2)
    configure_torch_runtime(device=torch.device('cpu'),tf32=False,cudnn_benchmark=False,matmul_precision='highest')
    out = ROOT/'analysis/unseen_recipe_audit_2026-10-06'
    manifest = json.loads((out/'case_manifest.json').read_text())
    ckpt = ROOT/'checkpoints/flowmatch_tf150_staged_noise/best.pt'
    model = load_motion_model(model_name='flowmatch_target',ckpt_path=ckpt,num_styles=90).eval()
    original = state_fingerprint(model.vqvae.state_dict())
    mean,std = load_norm_stats(ROOT/'checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/norm_stats.npz')
    seen,seen_segments,seen_raw,_ = read_db(ROOT/'database_100sty_375_memmap')
    _,_,raw,_ = read_db(ROOT/'database_100sty_375_memmap_zeroshot')
    classifier,metadata = build_fid_feature_extractor_from_checkpoint(
        ROOT/'checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth',map_location='cpu')
    classifier.eval()
    labels = torch.arange(90)
    learned = model.style_selector(codebook_weight=model.vqvae.quantizer.embedding_weight,
                                   style_label=labels,batch_size=90)
    features = learned['style_feature']
    center = features.mean(0)
    used = learned['style_probs'].gt(0).any(0)
    def forbidden(*args,**kwargs): raise AssertionError('Pure recipe accessed style embedding')
    model.style_selector.style_embedding.forward = forbidden
    rows = []
    for plan in manifest['recipes']:
        probs,_ = encode_recipe(model,raw,plan['clips'],mean=mean,std=std,chunk_rows=512)
        token = model.encode_conditions(x_curr=torch.zeros(1,375),style_label=None,
            manual_style_probs=probs,manual_style_strength=1.)[2][0]
        distance = (features-token).norm(dim=-1)
        nearest = distance.argmin().item()
        cosine = F.cosine_similarity(features-center,(token-center)[None],dim=-1)
        example = next(c for c in plan['clips'] if c['role']=='reference')
        real = np.array(raw[example['start']:example['start']+240],copy=True)
        normalized = torch.from_numpy((real-mean)/std)
        z = model.frame_latent(normalized)
        ae = real.copy(); ae[:,84:] = model.vqvae.decode(z).numpy()*std[84:]+mean[84:]
        predictions = []
        for clip in (real,ae):
            pred,confidence,_ = _classifier_stats(classifier,clip[None],np.array([plan['classifier_label']]),
                device=torch.device('cpu'),classifier_window=240,classifier_stride=240,
                classifier_batch_size=1,joint_set=metadata['joint_set'])
            predictions.append(dict(predicted=metadata['class_names'][int(pred[0])],
                correct=bool(pred[0]==plan['classifier_label']),target_confidence=float(confidence[0])))
        rows.append(dict(style=plan['style_name'],recipe_finite=bool(torch.isfinite(token).all()),
            nonempty_slots=int((probs.sum(-1)>0).sum()),max_codes_per_slot=int((probs>0).sum(-1).max()),
            seen_selector_code_overlap_mass=float((probs*used).sum(-1).mean()),
            nearest_seen_token=seen[nearest],nearest_token_l2=float(distance[nearest]),
            centered_cosine_to_nearest=float(cosine[nearest]),centered_token_norm=float((token-center).norm()),
            reference_source_entry_id=example['source_entry_id'],real=predictions[0],quantized_ae=predictions[1]))
        print(f"[Audit] {plan['style_name']}: token finite, reference GT/AE={predictions[0]['correct']}/{predictions[1]['correct']}",flush=True)
    seen_rows = []
    for name in ('Neutral','Robot'):
        label = seen.index(name)
        clips = [s for s in seen_segments if s['label']==label and s.get('split')=='train' and not s.get('mirror') and s['num_frames']>=240][:5]
        arrays = []
        for c in clips:
            x = torch.from_numpy((np.array(seen_raw[c['frame_start']:c['frame_start']+240])-mean)/std)
            _,indices,_ = model.vqvae.encode(x); arrays.append(indices.numpy())
        probs = sparse_code_histogram(np.concatenate(arrays),selected_slots=model.selected_style_slots,
            num_embeddings=model.vqvae.quantizer.num_embeddings,topk=4)
        token = model.encode_conditions(x_curr=torch.zeros(1,375),style_label=None,
            manual_style_probs=torch.from_numpy(probs),manual_style_strength=1.)[2][0]
        distances = (features-token).norm(dim=-1)
        seen_rows.append(dict(style=name,exemplars=len(clips),nearest_seen_token=seen[distances.argmin().item()],
            own_token_l2=float(distances[label]),nearest_token_l2=float(distances.min())))
    assert state_fingerprint(model.vqvae.state_dict()) == original
    payload = dict(seed=42,precision='fp32/highest',device='cpu',flow_ckpt=str(ckpt),
        note='Recipe tokens only; no flow sampling/rollout. One independent 240-frame reference per unseen style, not a complete accuracy estimate.',
        classifier_acc_split=metadata['acc_split'],classifier_split_protocol=metadata['split_protocol'],
        vq_state_unchanged=True,unseen=rows,seen_recipe_checks=seen_rows)
    (out/'token_and_ae_diagnostic.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
