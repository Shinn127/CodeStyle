#!/usr/bin/env bash
# Follow-up run: decoupled pairing (p=0.3) with a stronger style-prior weight (lambda_prior 0.02 -> 0.05).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-}"
if [[ -z "${PY}" ]]; then
  if [[ -x /home/shinn/miniforge3/envs/mcc/bin/python ]]; then PY=/home/shinn/miniforge3/envs/mcc/bin/python; else PY=python; fi
fi
VQ="${ROOT}/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt"
CACHE="${ROOT}/cache/vq_targets_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep"
PRIOR="${ROOT}/cache/style_code_prior_vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep.npz"
TAG="decouple_p03_prior005"
OUT="${ROOT}/checkpoints/flowmatch_vqvae_controller_${TAG}"

PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
  VQ_CKPT="${VQ}" VQ_TARGET_CACHE="${CACHE}" STYLE_CODE_PRIOR="${PRIOR}" \
  STYLE_PRIOR_LOSS=dense STYLE_HIST_WEIGHT=0.05 STYLE_ENTROPY_WEIGHT=0.02 OUT="${OUT}" \
  setsid "${ROOT}/run_train_flowmatch_vqvae_controller.sh" --epochs 20 --save-every 10 \
  --decouple-prob 0.3 > "/tmp/decouple_${TAG}.log" 2>&1
echo "[Done] training ${TAG}"
PYTHONUNBUFFERED=1 PYTHON_BIN="${PY}" DB="${ROOT}/database_100sty_375_memmap" \
  FLOW_CKPT="${OUT}/best.pt" OUT="${ROOT}/eval_results/gen_${TAG}" \
  setsid "${ROOT}/run_evaluate_minor_revision_generalization.sh" --horizons 60 \
  > "/tmp/decouple_eval_${TAG}.log" 2>&1
echo "[Done] evaluation ${TAG}"
