"""
Legacy entrypoint kept for backward compatibility.

The canonical trainer is `NewCode/train_lmm_375to291.py`.
"""

from __future__ import annotations

from train_lmm_375to291 import epoch_pass, main, parse_args

__all__ = ["epoch_pass", "main", "parse_args"]


if __name__ == "__main__":
    main()
