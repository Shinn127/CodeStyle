# 本地style classifier：60 fps、240帧、4秒

新训练入口默认使用原始60 fps的连续240帧，不做降采样。仍是15个ybot joints、45维position输入、CAMDM同类Conv/FC结构；`fc1`输入扩大为`128×240`。使用当前本地root-frame坐标并保留Hips高度，含镜像设置与现行本地classifier一致。generator、VQ、flow训练stride1和recon0不受此次修改影响。

## 训练

```bash
cd /home/shinn/桌面/multimedia/revision/NewCode
conda activate mcc
./run_train_fid_feature_extractor_camdm.sh
```

默认读取`database_100sty_375_memmap_fid_full100`，100类、镜像包含、window240、clip_offset10、batch1024、Adam lr1e-3、50epoch、seed42。精度FP32/highest、TF32关闭、无AMP。可以通过`WINDOW_SIZE / CLIP_OFFSET / BATCH_SIZE / INCLUDE_MIRROR / OUT / DEVICE / EPOCHS / PYTHON_BIN`覆盖。

这次只改变分类器观察长度与配套接口，保留CAMDM式all-clips classifier训练；`acc`明确标记`acc_split=train`，不当成独立验证或生成accuracy。没有新加数据划分或用generator的OOD训练。当前全100类库在含镜像时有713,114个合格240帧窗口，100类都有覆盖（metadata统计）。

默认独立产物：

`checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth`

checkpoint记录`window_size=240 / fps=60 / window_seconds=4 / temporal_stride=1 / position_convention / FP32信息 / acc_split`。已有checkpoint或history目录会拒绝覆盖。旧60帧模型的FC1形状不同，不能直接装成240帧模型，需要新训练。旧loader保留缺失window metadata时默认60的兼容语义。

本轮只完成代码与disposable fixture的一步训练验证，没有生成真实240帧trained checkpoint。FC1参数约为原60帧版本的4倍；真实GPU速度和显存尚未测量。

## Teacher-forced风格评估

训练完成后，明确选择controller checkpoint与独立输出目录：

```bash
FLOW_CKPT=$PWD/checkpoints/flowmatch_tf50_short5/best.pt \
OUT=$PWD/eval_results/gen_tf50_short5_tf_60fps_240f \
./run_evaluate_minor_revision_generalization.sh
```

wrapper默认选新240帧classifier和`FLOW_EVAL_MODE=reconstruct`，本轮不自动运行任何评估。Python评估入口在未传`--horizons`时从classifier metadata推导240；240帧classifier不接受60帧horizon。

新协议每case读取241行：第1行仅作GT context，生成并分类后240行，classifier不会看到GT首行。controller仍60fps推理，style classifier观察完整4秒。root轨迹用context初始化，ADE统计排除context。Gaussian noise长度与240次生成一致；manifest protocol_version3避免误用历史含GT窗口的protocol2。输出保存实际classifier fps/seconds、context规则、classification_start、effective re-quantization；TF matched行命名为`matched_style_teacher_forced_h240`。

需要明确rollout时可传`FLOW_EVAL_MODE=rollout`；它仍采用240个生成帧，但与TF结果分开保存。这是可用开关，不表示本轮已执行rollout。

## 旧结果与FID

旧60帧classifier仍可通过`CLASSIFIER_CKPT`或`--classifier-ckpt`加载。复播历史1行GT+59行生成、60行窗口的口径需显式指定`--horizons 60 --include-gt-context`，使用历史classifier，并选择独立目录。缺省新评估排除GT context，旧checkpoint也能生成60行后分类；两种口径分别标记。

已有FID extractor与历史60帧repair/sealed评估脚本保持原协议。4秒classifier用于新style accuracy，不自动替换FID提取器，不混合不同classifier特征空间的FID数字。style-consistency研究开关仍要求frame-level classifier，不能把240帧模型传入单帧损失。

240帧模型重新训练后才有有效新accuracy；旧1秒数字与新4秒数字应并列注明classifier与protocol，不以重命名旧checkpoint代替训练。
