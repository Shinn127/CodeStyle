# FlowMatch FP32 训练提效

**2026-10-09更新**：现有clip/recipe真实训练入口进一步提速，256+256短测25.82→17.40ms/update；固定validation rollout batch8→64约3.61倍。FP32/highest/noTF32保持，见[新性能报告](analysis/training_speed_2026-10-09/REPORT.md)。下文是2026-10-05历史探针，不与新配置混用。

2026-10-05 完成实现修订、CPU/CUDA 小模型验证和有界 GPU 性能探针；没有运行完整训练、生成新真实数据 cache 或执行真实 test。前向、反向、optimizer 与 GPU 日志累加保持 FP32，`matmul_precision=highest`、TF32=False，不使用 AMP。

## 已修改的计算路径

- **完整 batch512。** style 有界入口和 GPU smoke 默认 microbatch512，有效 batch仍512；不再默认拆成128×4。同机短测表明完整batch可以放下，避免四次 Python/反传调度。256×2和128×4保留为显式选项；不自动修改已存在 run 的 microbatch。
- **固定条件投影每次 Euler solve 只计算一次。** previous latent、motion、trajectory、style 的四个投影在8个子步之间复用，保留计算图和全部梯度。Transformer及动态latent/time token仍每步计算；没有缩短Euler8或截断reconstruction梯度。
- **初始化状态只在 setter/load 时读取。** latent stats/prior readiness保留原 checkpoint buffers，用CPU属性镜像，消除每次GPU normalize/transport调用的标量同步；加载状态时同步恢复镜像。
- **matched_root donor搜索向量化。** 仍在完整batch中执行suffix/root阈值筛选，均匀选一个合格style，再取该style内最接近donor；不同style的donor数量不影响选择概率。保留原始batch读取、全窗口固定donor、source root和joint velocity修正以及在线重新编码。
- **CUDA fused AdamW。** 默认融合FP32更新kernels；CPU回退普通AdamW。旧optimizer state加载后采用当前kernel选项；权重、moment和scheduler仍恢复。
- **减少无用搬运与统计。** cache帧号留在CPU；训练collate只传x/label/start/segment_id，避免把x已有的traj/motion再复制、IPC和pin一次。展开的style正则和统计只计算窗口第一次，其余步骤仍保留flow/recon/root/style-consistency；窗口权重不变。
- **验证rollout复用固定style token。** eval模式下固定label/recipe在一次sequence调用中只计算一次；`[B,T]` style切换和train-mode dropout保持逐帧路径。每个motion/trajectory条件、Gaussian noise、Euler和feedback均照原协议执行。

网络参数形状、loss种类/权重、学习率、有效batch、训练数量和checkpoint选择协议保持既有配置。VQ encoder/codebook/decoder全部冻结。FP32共享梯度累加及fused optimizer可能带来舍入差异；向量化donor和microbatch改变会改变随机数消费顺序，不能逐位重放旧代码训练轨迹。新代码同配置epoch续训一致性已由tiny-DB入口验证。

保留reconstruction监督时，每个展开步仍需1次flow训练点前向加8次Euler前向及相应反传；本版只削减重复工作和调度，不降低这部分目标本身的算量。

## 短测结果与边界

GPU：RTX5070Ti 16GB；Torch2.13.0+cu132；CPU threads=4；seed42。载入当前VQ150ep best，使用与实际相同的32×4/2048 VQ及6-token/256/2-layer/1024 controller尺寸。控制器为临时随机权重，输入与cache是合成fixture，丢弃训练权重。有效batch512，Euler8，recon=.1，prior=.02，entropy=.003；B/C展开2步，C的qualified decouple fraction≈.30。

原版每配置预热2、计时8个updates；最终版预热3、计时20个updates，计时范围为真实`_run_epoch`，含forward/backward/gradient clip/optimizer和必要同步。Profiler不计入计时。下表是计算路径吞吐，**不包含真实随机磁盘I/O、全量stats/fingerprints、checkpoint I/O和完整验证时间，也不是论文效果实验或完整epoch速度保证**。

| 计算配置 | 原128×4 ms/update | 原完整512 ms/update | 优化完整512 ms/update | 对原128×4提速 | 对原完整512提速 |
|---|---:|---:|---:|---:|---:|
| A：单步 | 75.97 | 37.75 | 34.66 | 2.19× | 1.09× |
| B：展开2步 | 149.26 | 77.00 | 69.22 | 2.16× | 1.11× |
| C：展开+matched_root | 217.30 | 102.55 | 73.97 | 2.94× | 1.39× |

优化版PyTorch峰值**allocated**显存A约1.78GiB，B/C约2.77GiB；不是nvidia-smi的进程占用/reserved显存，也不保证其他模型、配置或并发进程下不会OOM。优化前完整512的B/C峰值约3.07GiB。Profiler的B单update `aten::_local_scalar_dense`调用原128×4为249、优化512为3；包含CPU标量提取，不等同于249次CUDA同步。

固定style rollout（64×60帧、Euler8），每路径预热1次、计时3次：每帧重算style的参考路径为242.14ms，复用style为225.42ms，约1.07×，同一noise下输出逐值相同。这是已经启用其余优化后，仅比较style token复用的增益。

原始结果：[原128×4](analysis/fp32_performance_2026-10-05/baseline128.json)、[原完整512](analysis/fp32_performance_2026-10-05/baseline512.json)、[最终512](analysis/fp32_performance_2026-10-05/optimized512.json)、[rollout](analysis/fp32_performance_2026-10-05/rollout.json)。完整训练GPU小时应以真实新run的`history.jsonl`中`train_time_sec`及rollout validation耗时测量，不能直接把表中的计算提速当作总作业提速。

## 使用

新run直接使用style有界脚本，默认只打印命令：

```bash
conda activate mcc
cd /home/shinn/桌面/multimedia/revision/NewCode
python analysis/run_style_refinement.py
```

显式`--execute`才运行原A/B/C阶段训练。直接trainer默认microbatch=0，表示完整有效batch；wrapper支持追加`--microbatch-size 512 --fused-adamw --matmul-precision highest --no-tf32`。若512显存不足，明确选择256或128和新目录。原128 run续训传`--microbatch-size 128`并保持原其余训练参数；如果希望改用512，可用兼容checkpoint的`--init-ckpt`开始新run，重置optimizer/scheduler/RNG，不原地改已有run。

独立性能探针上限每配置20个updates，不写模型权重：

```bash
python analysis/benchmark_flowmatch_training.py \
  --out /tmp/flowmatch_fp32_perf.json --microbatch-size 512 \
  --updates 20 --warmup 3 --profile --rollout
```

`--no-fused-adamw`可以检查同一新实现下optimizer kernel影响。此工具使用合成batch和内存cache，不代替真实loader/epoch测量；`--rollout`额外对比固定style、64×60帧、同一noise的token复用路径和每帧重算参考路径，并检查输出逐值一致。

## 验证

全套轻量CPU suite：**160 passed、2 CUDA tests skipped、5 subtests passed**（10.43秒）；新性能回归在可访问CUDA的环境中另外执行，**11 passed**，含target/velocity的CUDA loss与全部控制器梯度、VQ无梯度、投影次数、load readiness、窗口正则权重、donor style均匀性与最近邻、label/recipe/style切换rollout逐值一致和collate输入一致。梯度对比使用FP32容差，不宣称训练轨迹逐位不变。
