# Unseen style / recipe评估与实现审计

独立clip/recipe训练入口现已修复，当前150epoch计划见 [`RECIPE_TF150_PLAN.md`](RECIPE_TF150_PLAN.md)。`--conditioning-mode recipe`在train/validation均使用纯recipe并冻结未使用的label selector；seen评估自动切换matched/cross recipe，新增`--source-split val`用于选型。本轮只做轻量验证，没有新的完整seen/OOD accuracy；旧label-only checkpoint的失效结果仍保留。

后续失效复核：见 [`analysis/RECIPE_FAILURE_ANALYSIS_2026-10-06.md`](analysis/RECIPE_FAILURE_ANALYSIS_2026-10-06.md)。用户完整结果为seen recipe cross12.08%、OOD0.10%；接口可执行不代表当前checkpoint已学会exemplar conditioning。已规范seen recipe默认为canonical独立train clips/TopK4，历史all-window/dense需显式 `--recipe-profile legacy`；下文早期审计记录保留，完整unseen能力尚未修复。

2026-10-06。审计对象为 `checkpoints/flowmatch_tf150_staged_noise/best.pt`（epoch135）；latest为epoch150。新run的recipe_prob=0、style-consistency=0。使用训练完成的 `fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth`，window240、fps60、100类ybot15。classifier的acc_split=train、split_protocol=camdm_all_clips，因此unseen是相对generator的90类训练集，不是classifier未见过的类别。

本轮完成代码审计、独立入口、轻量测试、固定case/exemplar manifest和CPU recipe/AE诊断。未执行完整flow生成、rollout、generator微调或5000-case unseen评估，没有新的完整unseen accuracy结果。

## Recipe具体实现

`exemplar motion375 -> 固定normalization -> 冻结VQ encode -> 每slot code histogram -> TopK4 -> 加权codebook均值 -> prototype32维 -> 已训练style projection -> style token64维`

VQ有32个slot、每slot4维、2048个共享codes。controller控制slots `[4,9,10,17,18,20,23,24]`；按该顺序拼接8个4维code均值。对于style s、slot m：

`p_s,m(k) = count(q_m=k) / exemplar总帧数`

保留频率最高的4个codes，在所保留codes内重新归一化；然后 `h_s,m = sum_k p_top4_s,m(k) * codebook[k]`。5个等长240帧exemplars合并统计，相当于每clip等权。recipe没有使用Laplace smoothing；train dense prior的Laplace smoothing=1是另一统计对象。TopK截断后的均值是连续style prototype，不能等同于单一VQ code或完整原始motion。

关键路径是 `sparse_code_histogram()`、`StyleCodeSelector.forward()`、`FlowMatchVQVAEController.encode_conditions()`。共享recipe `[M,K]` / `[1,M,K]`可广播，`[B,M,K]`可逐样本指定。label+partial recipe可保留未指定slots的label conditioning；pure recipe必须提供全部slots、非负有限非空概率、strength=1，且传style_label=None，因此不访问90类style embedding。

本实现复用现有codebook和style projection，不包含learned clip encoder。准确描述应为clip→VQ histogram→recipe→style token，不能把它写成训练过的clip-style encoder。

## 原有评估入口的限制与本次修正

`evaluate_minor_revision_generalization.py --use-target-style-recipe`是历史seen-target诊断：targets仍限于generator的90类；recipe构建遍历可能重叠、含镜像及不同split的windows，默认60帧，使用dense histogram；生成时仍传seen target label。它不满足5个独立240帧exemplars的OOD协议，也不能直接报告unseen。保留原行为以复播历史结果，并在CLI help中明确标注用途。

新增 `evaluate_unseen_style.py`：按名称将OOD数据库标签映射到classifier labels，generator始终使用style_label=None；不把90–99等classifier indices传给90类embedding。每类随机选5个独立、未镜像原始clips，各固定240帧作为exemplar；所有其余合格独立clips作为真实motion参考，exemplar/reference source_entry_id严格分离。

单clip exporter默认窗口已改240帧，并增加controller内嵌VQ、实际slot顺序和normalization验证；配置优先读取checkpoint args，避免同目录config漂移。新recipe metadata包含norm fingerprint；播放时能拒绝不匹配的normalization。旧recipe缺少norm fingerprint仍保持可读，但无法审计其当初编码用的normalization，应重新生成后用于正式结果。旧码本和slot顺序错配仍会被拒绝。pure recipe strength<1在导出前报错，需要混合时必须显式提供seen base-style。

## 固定评估协议

| 项目 | 当前独立入口 |
|---|---|
| Source | 90-style IND的原始未镜像test clips；1000个固定source windows，stride30 |
| OOD targets | TwoFootJump、WalkingStickLeft、WalkingStickRight、Waving、WhirlArms、WideLegs、WiggleHips、WildArms、WildLegs、Zombie |
| 配方 | 每style5个独立240帧exemplars，TopK与slot顺序取controller；strength1，无base-style |
| Cases | 每source5个固定不同OOD targets，总5000cases；seed42 |
| 时间 | 读取241帧source：1帧context+240帧生成；classifier只看240帧生成 |
| 模式 | 默认teacher-forced：每步使用source GT历史；不会反馈生成结果 |
| 输出策略 | 继承checkpoint clip→quantize→decode，不做smoothing |
| 噪声 | noise std继承checkpoint，按source start/target classifier label/seed固定Gaussian；不随batch或ODE步数改变输入 |
| 精度 | FP32/highest、TF32关闭 |
| 指标 | requested style acc、confidence、macro/per-style acc、source retention、Root ADE；95%CI按原始source_entry_id聚类bootstrap1000次 |
| 参考 | 未用于exemplar的真实OOD clips与quantized AE，分别统计style accuracy；不将exemplar自分类准确率作为参考结果 |

TF入口批量展平独立time points，缓存每case style feature，不把[B,8,2048]recipe在时间维展开；microbatch默认512。这避免逐帧重复selector和过多Python调用。轻量测试确认与既有逐帧TF路径相同输入/噪声下数值一致，并确认不访问style embedding。可设置microbatch256/128降低峰值显存。

ADE计算保留context以初始化root积分，但只平均后240个生成frames。它衡量相对source的轨迹保持；cross/OOD有意更换pose，不用对source pose的MPJPE证明目标style质量。4秒ADE不能与历史1秒阈值直接比较。FID不在此入口中计算，若额外报告需要固定原extractor并区分global/style/clip，不能用新classifier特征静默替代。

## 运行

在NewCode目录，先仅准备manifest，不生成：

```bash
/home/shinn/miniforge3/envs/mcc/bin/python evaluate_unseen_style.py \
  --prepare-only --device cpu
```

用户自行运行完整TF unseen：

```bash
/home/shinn/miniforge3/envs/mcc/bin/python evaluate_unseen_style.py \
  --flow-ckpt checkpoints/flowmatch_tf150_staged_noise/best.pt \
  --device cuda --batch-size 32 --microbatch-size 512 \
  --num-sources 1000 --targets-per-source 5 --ode-steps 8
```

输出为独立目录 `eval_results/unseen_tf240_staged_noise`：case_manifest.json、recipes/style_00.json等、per_sample.csv、summary.json。已有summary时拒绝覆盖；更换checkpoint或ODE步数使用新out-dir，可复制同一manifest到该目录以比较。manifest校验selected windows的真实X内容哈希、元数据、normalization、codebook、slots、classifier，允许相同内容不同路径，拒绝同路径内容变化。

如要与seen cross使用完全相同的source windows，seen入口新增显式 `--unmirrored-sources`（默认保留历史行为）：

```bash
/home/shinn/miniforge3/envs/mcc/bin/python evaluate_minor_revision_generalization.py \
  --flow-ckpt checkpoints/flowmatch_tf150_staged_noise/best.pt \
  --classifier-ckpt checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth \
  --horizons 240 --flow-eval-mode reconstruct --unmirrored-sources \
  --num-sources 1000 --targets-per-source 5 --out-dir eval_results/seen_tf240_unmirrored
```

随后unseen入口增加 `--source-manifest eval_results/seen_tf240_unmirrored/case_manifest.json`。旧60帧、含context或含镜像的manifest被拒绝，不能用于声称相同source的4秒比较。source count不足1000时报告实际数量；不可把较小数量说成1000。此处是TF结果，不能称为autoregressive结果；`--flow-eval-mode rollout`需要用户明确选择，本轮未执行。

单clip配方导出示例（用于独立可视化，不代替上述5-clip评估）：

```bash
/home/shinn/miniforge3/envs/mcc/bin/python build_zeroshot_style_recipe.py \
  --flow-ckpt checkpoints/flowmatch_tf150_staged_noise/best.pt \
  --db database_100sty_375_memmap_zeroshot --style Zombie \
  --num-frames 240 --topk 4 --strength 1 --device cuda
```

pure OOD播放只传recipe，不向90类generator的 `--target-style` 传Zombie等OOD名称，也不写base_style。classifier的100类label仅用于评价，不进入generator。

## 真实数据CPU诊断与可行性

固定manifest已保存到 `analysis/unseen_recipe_audit_2026-10-06/case_manifest.json`。10类OOD共有81个独立clips，各选5个后留下31个独立reference clips；1000个IND test sources、每source5targets已固定。本轮完整生成未执行。

CPU/FP32/2threads检查使用每OOD style的5个240帧exemplars构建token，并各抽1个独立reference进行GT/quantized AE检查；另抽Neutral/Robot各5个train exemplars检查seen recipe。全部10类recipe有限、8slots均非空、每slot至多4codes；pure接口不查style embedding，完整VQ state fingerprint前后相同。

10个reference的GT为10/10正确、quantized AE为9/10正确；WhirlArms AE被判为Punch。每style只有1clip，这不是完整accuracy估计或严格可达上界，只说明部分OOD运动可被既有VQ表示，且VQ本身也可能损失风格信号。

部分OOD配方所用概率质量与seen learned selector支持集的重合为：WildArms约24.0%、WiggleHips约27.4%、WhirlArms约35.4%；对应style token到nearest seen token的L2约17.19、30.25、12.17。这些距离只定位conditioning分布差异，不是style语义距离，也不是生成失败结论。Neutral recipe的nearest token是Neutral；Robot recipe的nearest token是SlideFeet，而own-token距离略大，说明seen histogram也不一定精确复现learned label token。

根本可行性：OOD可以通过同一码本构造新的连续prototype，再用已训练projection与flow field生成；无需新增OOD embedding。但generator的recipe_prob=0，projection/field没有直接见过这些exemplar分布。直方图还丢弃时间顺序及跨slot相关性，并可能混入action/trajectory信息，不能保证充分style/content解耦。新配方码组合落在已知style token之间或之外时，效果只能用真实生成评估确认。现在不调整TopK、norm或VQ来追求更高测试accuracy。

建议先用固定OOD manifest报告主结果，同时检查seen label→seen recipe是否有明显落差。若seen recipe也下降，优先研究现有train-only seen recipe增强（例如recipe_prob=.1–.2），不使用OOD generator训练、不直接优化报告classifier；若quantized AE在某些OOD就很差，先报告representation限制。任何微调需要单独授权和新目录，本轮没有启动。

诊断详情：`analysis/unseen_recipe_audit_2026-10-06/token_and_ae_diagnostic.json`，复查脚本为 `analysis/audit_unseen_recipe_tokens.py`。完整unseen是否接近seen cross仍待同checkpoint、同4秒TF协议下评估。

验证结果：全部轻量测试190项通过、2项CUDA测试跳过、5项subtests通过；覆盖独立clips分割、名称映射、pure recipe不查embedding、矢量化/逐帧TF及microbatch一致、240帧首帧排除、完整toy入口、错误normalization拒绝、保存结果保护，以及seen/unseen相同未镜像source采样。
