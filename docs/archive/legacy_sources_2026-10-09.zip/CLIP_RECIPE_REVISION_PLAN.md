# Clip / recipe 修订：代码与有界训练计划

**2026-10-09口径更正**：正式matched/cross/unseen全部使用rollout，训练保留teacher-forced；历史TF数字仅用于诊断。当前统一入口为`run_evaluate_style_rollout.sh`，详见 [当前计划](analysis/clip_recipe_failure_2026-10-08/PRACTICAL_REVISION.md)。后续validation也使用`--style-val-mode rollout`，旧TF best不能当作rollout best。

**2026-10-08 更新**：本文件记录的 `clip_recipe_scratch150` 已训练完成，cross/unseen未达标。当前推荐入口改为 `run_train_clip_recipe_practical.sh`；具体实现、短测与50-epoch验证计划见 [新训练方案](analysis/clip_recipe_failure_2026-10-08/PRACTICAL_REVISION.md)。仍从零初始化，训练及cosine周期均为50 epoch；不自动追加旧配置训练或强制重建temporal encoder。下面保留已完成实验的原配置，便于溯源。

2026-10-07，按最新要求改为从零训练。一个 `clip_recipe` controller 完整训练150 epoch：flow和style projection随机初始化，统计selector采用零残差初始化；不加载旧controller、旧optimizer或旧scheduler。VQ150ep及其normalization继续冻结。clip和recipe共享同一个模型，不分别计算150 epoch。

此版本替代此前A/B/C阶段微调方案；正式实验仍由用户自行启动。

## 已实现的路径

```text
clip → frozen VQ indices → 完整 histogram
     → label-free residual selector → TopK4 probabilities π
     → frozen codebook weighted mean → 原 P → 原 6-token flow

exported/manual recipe ρ → 同一个 codebook weighted mean → 同一个 P / flow
```

新增 `--conditioning-mode clip_recipe`。`label`、旧 `recipe` 模式保留原行为；新的 histogram 输入使用 `clip_histograms`，手工最终概率仍使用 `manual_style_probs`，同时提供时拒绝。风格 label 只用于训练配对和 prior supervision，通过独立的 `prior_labels` 传入，不进入生成条件。

Selector 使用冻结码本的标准化几何、完整 histogram 的统计和 slot embedding，以小型共享网络重评分；residual 零初始化，初始行为接近原 TopK histogram。保持 8 slots / TopK4 / 64D style feature / 6-token、256 hidden、2 layers、FFN1024。原 label embedding/logit head 在新模式下冻结。

`build_zeroshot_style_recipe.py --flow-ckpt ...`、seen evaluator、OOD evaluator 使用同一选码函数。新 checkpoint 导出的 recipe 保存 learned π，而非 raw histogram；记录 `probability_space=control`、selector 指纹及已有 VQ/slot/normalization 来源。最终 recipe 直接执行，不再通过 selector 二次变换。已有 raw histogram recipe 仍可显式作为手工控制概率使用，但不能称为新 clip selector 的导出结果。

## Cross donor 修正

`--cross-donor-source bank` 使用 train-only bank，默认每个 train segment 取 16 个固定窗口，每窗口 16 个相邻转移。当前真实数据库可构建 17,568 个窗口。验证/test clips 不进入 bank，source 的同源镜像也不能作为 donor。

匹配规则：同 action suffix、不同 style；整个窗口的平面 root 速度差满足 `max(.25m/s, .2×source speed)`，yaw 差≤30deg/s。目标风格在合格 styles 中均匀采样，再以相位描述和 root 差选 donor。相位描述使用左右脚相对方向、相对速度和相对落地高度，减少直接匹配绝对步幅对目标风格幅度的抑制；这是启发式匹配，尚不能宣称完成 content/style 解耦。

同一 source anchor / target style 使用固定 donor clip 与时间偏移，监督取 donor 的连续下一帧。训练仍为 seq_len=2、stride=1、unroll=1，没有生成反馈。source root/trajectory 保留，donor velocity 按 root 平移与 yaw 差修正，合成 motion 重新经过冻结 encoder 获得 target latent。没有合格 donor 时回退原样本。

新增日志：实际 `cross_samples`、`matched_samples`、各自 `flow_loss`，以及 `donor_candidates_mean`、`donor_phase_cost`。没有 cross 样本时 loss 数值为 0，同时 count=0，不能据此认定 cross 已学好。

## 单模型从零训练150 epoch

| epoch | 训练方式 | 历史增强 |
|---|---|---|
| 1–50 | clip_recipe + donor bank，teacher-forced | 干净GT history |
| 51–150 | 同一模型、同一optimizer/scheduler连续训练 | 以0.3概率加入共享gate/strength噪声 |

selector、P、flow从第1 epoch开始共同优化，完整覆盖150 epoch。不存在阶段间权重继承或optimizer重置；从头到尾使用同一条cosine曲线。已有label150与本轮都训练150 epoch，但新增选码器和donor bank使GPU小时未必相同。

公共配置：

| 项目 | 配置 |
|---|---|
| VQ / normalization / latent stats | 固定VQ150ep best及其normalization；在新run目录生成train-only latent stats |
| 训练精度 | FP32、highest、TF32=False |
| 数据 | 原90-style split，seq_len=2、stride=1、teacher-forced |
| Batch | 有效512，默认 microbatch512；可在启动前改为256×2或128×4 |
| Cross | matched_root、bank、请求概率0.3，实际比例单独记录 |
| Clip | 1/3/5个独立train exemplar，各240帧，排除监督source/donor |
| Flow | target prediction、normalized latent MSE、flow weight=1 |
| Selector loss | dense prior CE=.02、entropy=.003，从第1 epoch开始 |
| Motion loss | reconstruction、root reconstruction、classifier loss均为0 |
| 历史增强 | epoch1–50关闭；51–150共享gate概率0.3，latent=.3，pose/velocity=.2，root=.05，rotation不加噪 |
| Optimizer | AdamW、初始lr=5e-4、weight decay=1e-4、grad clip=1 / optimizer update |
| Scheduler | 单条cosine，min lr=1e-5，horizon=150 |
| Seed | 42 |
| 推理 | Euler8、std=1、clip→quantize→decode |

前50 epoch先学习干净历史条件下的动力学和风格控制，后100 epoch增加对历史误差的鲁棒性。额外 history mask、output-distribution KL、更多 slots、更大 TopK、temporal clip encoder 均未加入默认实验，便于解释本轮变化。

## 验证、选型和停止条件

每 epoch 记录 matched validation loss，单独保存 `best_loss.pt`。每5 epoch及训练结束执行 **teacher-forced style validation**：90个未镜像val clips，每clip3个固定起点，生成240帧；每source matched一次、cross两个固定目标，共270 matched + 540 cross。分类器为60fps/240f/100类，按style names映射标签，分类输入排除GT初始帧。

验证 exemplar 固定为每style5个独立train clips；只缓存原始 histogram，每次验证重新计算 learned π。source起点、targets、exemplars、seed、classifier/VQ/normalization/窗口内容指纹写入 `tf_validation_cases.json`。它是新的固定验证协议，与上一轮5-target快照的数字不能直接混用。

从零训练不使用随机初始化模型或旧checkpoint作reference，也不进行epoch0的大规模style评估。`best.pt` 使用固定规则选择：

1. 优先满足 matched accuracy ≥85%，4秒 matched Root ADE≤5cm、cross Root ADE≤10cm。
2. 在相同通过状态下，优先cross accuracy，再比较matched accuracy，最后比较按上述ADE限值归一化的root误差和。
3. 暂无通过约束候选时保存诊断best，标注 `constraints_passed=false`；不因早期准确率低而提前终止。

5/10cm是本轮240帧TF选型的工程门限，不是论文复现达标阈值。目标仍是matched≥85%、cross≥80%、unseen接近cross；unseen不用于训练或checkpoint选择。取消原来的A/B/C门控和1pp提升条件，最多完成150 epoch，不自动追加训练。

结束后将验证best的路径与选择记录写入 `selected_checkpoint.json`。test/OOD只在选型锁定之后执行。

## 运行

```bash
cd /home/shinn/桌面/multimedia/revision/NewCode

# 只显示完整命令，不训练。
DRY_RUN=1 bash run_train_clip_recipe_revision.sh

# 可选GPU入口smoke：只跑2个updates，独立 _smoke 目录，关闭大规模style验证。
SMOKE=1 bash run_train_clip_recipe_revision.sh

# 首次正式运行：从零训练150 epoch。
bash run_train_clip_recipe_revision.sh

# 仅在本次新训练中断后，显式恢复其optimizer/scheduler/RNG。
RESUME=1 bash run_train_clip_recipe_revision.sh
```

默认输出 `checkpoints/clip_recipe_scratch150`。脚本不接受 `INITIAL_CKPT` / `INIT_CKPT`，也不会自动发现旧controller进行初始化。新run的 `latent_stats.npz` 由冻结VQ/cache的train帧统计得到；复用的是VQ数据缓存与统计先验，不是旧controller权重。

支持 `RUN_ROOT`、`DEVICE`、`NUM_WORKERS`、`MICROBATCH_SIZE`、`RECIPE_BANK_MAX_ENTRIES` 环境变量。脚本拒绝任意附加CLI参数，避免误改epoch预算。输出已有训练记录时，须使用新 `RUN_ROOT` 开始另一轮从零训练，或用 `RESUME=1` 恢复本轮，不会覆盖已有结果。

显存不足时先在smoke中尝试 `MICROBATCH_SIZE=256` 或128；donor仍基于完整有效batch工作，梯度裁剪只在optimizer update前执行。正式续训不能偷偷改变microbatch等被校验的训练配置。

## 效率与测量

训练没有Euler采样、decoder或分类器反传。只有合成cross target需要冻结VQ encoder；cached GT latent继续复用。完整 histogram以稀疏非零项缓存，默认最多131072条，旨在容纳当前90-style/独立clip/64变体/1,3,5 exemplar组合，避免过小LRU导致重复读缓存。可以下调entry上限节省CPU内存，但必须观察 `recipe_bank_hit_fraction` 与训练时间。

实现阶段的512-case donor只读检查成功；它没有运行真实latent编码，不是完整训练benchmark。当时的执行环境无法运行CUDA测试。后续用户提供GLM的GPU smoke/TF验证记录见下文；仍不套用旧模型3分钟/epoch或用两个updates推断完整GPU小时。

用户运行GPU smoke后，应以正式第一个epoch的完整计时校正预算：

    预计GPU时间 ≈ 50×干净历史每epoch秒 + 100×加噪历史每epoch秒
                  + 30次TF style validation时间 + latent统计/数据准备时间

`history.jsonl` 已分别记录 `train_time_sec`、epoch时间与 `tf_style_val.time_sec`；epoch原记录在style validation之前，因此相加时需计入后者。区分前50与后100 epoch的实测稳态值，并考虑缓存预热。smoke只有2步，不能据此推断cache充分预热后的完整epoch速度。

## 导出与最终评估

先从 `selected_checkpoint.json` 读取 `selected.path`。对新模型，必须用checkpoint导出recipe，单独的config不包含learned selector权重。

```bash
PY=/home/shinn/miniforge3/envs/mcc/bin/python
FLOW_CKPT="$($PY -c 'import json; print(json.load(open("checkpoints/clip_recipe_scratch150/selected_checkpoint.json"))["selected"]["path"])')"

$PY build_zeroshot_style_recipe.py \
  --flow-ckpt "$FLOW_CKPT" \
  --db database_100sty_375_memmap_zeroshot \
  --num-frames 240 --topk 4 --out cache/clip_recipe_revision_example.json

$PY evaluate_minor_revision_generalization.py \
  --flow-ckpt "$FLOW_CKPT" \
  --classifier-ckpt checkpoints/fid_feature_extractor_camdm100_mirror_60fps_240f/100style_position_classifier.pth \
  --recipe-only --recipe-profile canonical --recipe-exemplars-per-style 5 \
  --flow-eval-mode rollout --horizons 240 --source-split test --unmirrored-sources \
  --flow-ode-steps 8 --flow-requantize-z --flow-latent-clip \
  --case-manifest eval_results/recipe_tf150_test_e0150_n5/case_manifest.json \
  --out-dir eval_results/clip_recipe_revision_rollout_test

$PY evaluate_unseen_style.py \
  --flow-ckpt "$FLOW_CKPT" --flow-eval-mode rollout \
  --source-manifest eval_results/recipe_tf150_test_e0150_n5/case_manifest.json \
  --out-dir eval_results/clip_recipe_revision_rollout_unseen
```

这些最终评估不由训练脚本自动启动。保留seen/OOD各5000cross cases、固定Gaussian、独立exemplar/reference及原source-entry聚类bootstrap协议；240f/4s ADE不与旧60f阈值直接比较。manual-only实时推理要求完整slots、strength=1，旧label模型仍可使用label+partial recipe。

## 验收状态

此前实现阶段检查：完整 `tests` 测试集 **217 passed、2个CUDA测试跳过、5项subtests通过**；Python编译、shell语法、`git diff --check`通过。包含从零训练入口、固定门限选型、跳过初始随机模型reference和本轮精确续训检查。另完成90-style / 8-slot / K2048实尺寸的前向与反向检查：selector梯度有限且非零、clip/recipe feature一致、VQ指纹不变；只用3个合成输入，没有optimizer update或rollout。更新的GLM GPU验收记录见下一节；正式生成质量仍未验证。

实现层面已覆盖：新模型从零初始化；clip/导出recipe一致；FM-only及prior-only能更新selector；无label条件、无decoder/Euler训练；VQ状态不变；完整histogram缓存冷/热/淘汰一致；窗口donor连续映射、root保留与velocity修正；真实CLI训练/validation/保存/精确续训；240帧TF验证及checkpoint选择。

训练效果仍需上述实验验证。目标仍是matched≥85%、cross≥80%、unseen接近cross；通过代码测试或checkpoint选型约束不能宣称已达标。

## 后续GLM验收与分析复核

用户提供的GLM记录：219项CPU及26项CUDA/clip-recipe通过，真实GPU smoke两updates通过；matched/cross samples=817/207、recipe fraction=1、shortfall=0、donor candidates=2.14。独立TF验证810 cases耗时28.8秒。smoke数据已与本地history核对；测试总数/TF时间按GLM记录引用，本轮未重复GPU测试。

复核补充：[训练前分析复核](/home/shinn/桌面/multimedia/revision/NewCode/analysis/clip_recipe_preflight_review_2026-10-07/REVIEW.md)。bounded histogram selector存在非零prior-KL下界，不能用label版的0.024作预期；bank增密增加每次update的检索成本；点估计的constraints标记不等于CI保证。默认模型、loss权重和bank密度保持不变，只修正prior告警文字。
# FP32 速度优化（2026-10-07）

训练主路径已完成保持目标和RNG的提效，真实128-batch warm短测约1.40×；详细改动、数值检查与续训状态见 [训练提效记录](analysis/training_speed_2026-10-07/REPORT.md)。训练配置和150 epoch上限不变；本次运行从自身latest续训。
