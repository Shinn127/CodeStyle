# 50 epoch Teacher-forced 训练与 matched/cross 报告规划

分类器口径更新：本地style classifier改为60fps/240帧（4秒），见 [`STYLE_CLASSIFIER_240F.md`](STYLE_CLASSIFIER_240F.md)。训练/加载/主generalization评估已适配；独立240帧权重仍需用户训练，本计划的TF联合checkpoint选择器仍属于待实施接口。下述历史Root ADE gate来自60帧协议，不能直接套到4秒ADE；在选择器实现前需保持60帧轨迹诊断单独统计，或重新制定并固定4秒gate。

当前阶段只训练和评估teacher-forced，不做自回归展开、rollout validation或长序列。本文是规划；本轮未启动训练、评估或改写现有运行。推荐一个独立50 epoch matched-only基线，decouple/root weight都设0，同时报告matched和cross。cross结果作为未直接训练的条件组合诊断。matched_root是此前代码修订加入的可选合成监督，尚无充分效果证据，不默认纳入这轮基线；若用户选择混合监督，再改为请求概率.3、root weight.1，仍只运行一条50 epoch实验。

Teacher-forced定义：每个预测的previous motion使用source GT，previous latent由同一个冻结VQ编码source GT；下一次预测继续取GT，不反馈生成的motion/latent。cross解耦只改变本步请求style与监督目标，不改变这个定义。训练使用随机t处的单次flow field预测；Euler8仅用于生成评估，不是跨帧rollout。

## 固定训练设置

| 项目 | 设置 |
|---|---|
| 初始化与预算 | 独立目录从头训练，seed42，50 epoch，总计一条实验；不自动追加seed/sweep/epoch |
| 数据 | 当前90-style IND、既有clip-level train/val/test，保留镜像训练增强 |
| VQ与normalization | VQ150ep best与其固定stats；encoder/codebook/decoder全部冻结、eval |
| 来源 | 已修复FP32 cache/prior，train-only latent stats；内容指纹一致 |
| 模型 | 现有6-token、hidden256、2 layers、FFN1024；不新增encoder/损失分支 |
| 训练路径 | `seq_len=2`、`stride=1`（保留重叠窗口）、`unroll_steps=1`、`train_feedback_context=False` |
| 目标 | target prediction，normalized latent MSE |
| Solver | 训练不运行Euler；生成评估用Euler8，Gaussian noise std1 |
| Style | learned selector、8 slots、top-k4、temperature1、dense prior、prior初始化、raw prototype |
| 条件增强 | previous latent/motion noise=.3，dropout0；eval两种previous noise都关闭 |
| Cross训练监督 | 默认关闭：decouple probability0；cross仅用于固定teacher-forced评估 |
| Loss | flow1、recon0、root0、prior.02、entropy.003；style-consistency0、recipe训练增强0 |
| Optimizer | FP32 fused AdamW，lr5e-4、weight decay1e-4、grad clip1 |
| Schedule | cosine horizon50、stop50、min lr1e-5 |
| Batch/精度 | 有效batch512，优先完整512；FP32/highest、TF32=False，无AMP |
| 验证/保存 | 每epoch TF loss；每5epoch固定TF matched/cross验证及快照；关闭所有rollout回调 |

本轮关闭reconstruction loss，root/style-consistency loss也保持0。训练和普通TF loss validation不调用Euler积分或decoder，仅对随机t的flow field进行一次前向并计算latent监督和style regularizers。VQ encoder/codebook用于固定GT latent（优先读取既有cache）；decoder只在生成评估需要motion时使用。日志recon/root为0表示该项关闭，不表示重建误差为0。

当前直接Python入口和shell wrapper默认recon weight0、rollout validation关闭，默认独立输出目录为`checkpoints/flowmatch_tf50_fp32_norecon`。本轮参数为`--epochs 50 --lr-schedule-epochs 50 --seq-len 2 --stride 1 --unroll-steps 1 --recon-weight 0 --root-recon-weight 0 --style-consistency-weight 0 --decouple-prob 0 --rollout-val-every 0 --no-train-feedback-context --matmul-precision highest --no-tf32`。历史A/B/C脚本仍显式使用其原recon.1配置，不能用于启动本轮。旧recon.1 run保持原义；改变loss应在新目录训练或通过`--init-ckpt`仅继承兼容权重，不能直接resume。

可选matched_root沿用现有语义：同action suffix、合格root速度/yaw、均匀选择目标style再选最近donor，source GT root保留、donor pose/rotation与修正joint velocity作为目标，source trajectory+合成motion重新编码target latent。donor从完整不可变batch选择；不合格时回退原matched样本。请求.3不等于实际cross比例；启用时报告按target style/action统计实际覆盖，避免“开了cross却几乎没用上”。这只是近似配对：没有严格对齐gait phase，GT source previous pose到donor target pose仍可能跳变，不能预先保证提升cross效果或保持时序连续性。

默认matched训练只出现source A/request A/target A，cross评估则是source A/request B；这是未直接监督的条件组合。style prior约束style token的码本分布，不等于提供这类配对，也不保证模型已学会忽略previous motion中的source style。cross低accuracy需要结合source retention和条件干预分析，不能单凭该结果判定prior统计失效。

现有5/20epoch模型作为历史诊断保留。若将它们作为初始化，必须使用`--init-ckpt`重置optimizer/scheduler/RNG，并标为“额外50epoch微调”；不作为从头50epoch结果，也不把原短cosine状态改为50epoch直接续训。

## 固定teacher-forced评估协议

训练期间仅使用validation。最终先锁定validation-selected checkpoint，再进行一次test，不按test挑模型。

- 每case读取241个GT feature rows，以第一行作为context，独立预测后240行；classifier只看240个生成motion，排除GT起始帧。
- **Matched**：source style A，request A；每个时间步GT motion/latent来自source A。
- **Cross**：source style A，request B≠A；每个时间步GT motion/latent仍来自source A。accuracy按请求B计，不按source A计；额外报告source-style retention判断是否照搬source。
- trajectory均使用同一个source的GT控制。主输出策略clip→quantize→decode，无decode smoothing；continuous作为单独诊断，不与主指标混合。
- Euler8、noise std1、固定seed42。case manifest保存source_entry_id、context start、generated start、target、noise seed及输出策略。同一source的matched/cross可共用Gaussian noise，隔离label变化；模型/batch size/ODE比较复用manifest。
- classifier固定新240-frame/60fps/ybot15/100-class版本及指纹，按style names映射90个generator labels；不以classifier loss优化generator。
- validation沿用90个未镜像clips，各3个固定240帧生成窗口；每窗口matched1个、cross2个固定seen targets。
- test固定1,000个未镜像source windows，每source生成240帧、matched1个、cross5个seen targets。targets按seed均匀选择，必须不等于source label；manifest固定后不重采样。
- 95%CI按原始source_entry_id聚类bootstrap1,000次；同source多个窗口/targets在同一cluster。保存逐case输出，不能把相关窗口当独立样本。

输出matched/cross各自的target accuracy、target confidence、source retention、Root ADE、按target style的macro accuracy及coverage。matched额外报告MPJPE/local jitter/local与world F.S.及contact coverage。cross pose有意不同于source，不用“对source pose的MPJPE”评价目标style正确性。GT与quantized AE style accuracy作为同cases参考上界；TF结果明确标为TF，不当成自回归或论文联合复现结果。

## checkpoint选择与报告

保存`best_loss.pt`、每5epoch快照、`latest.pt`和独立`best_tf_style.pt`。

推荐用固定validation的

`S_TF = (Acc_matched + Acc_cross) / 2`

选择style checkpoint：accuracy用0–1，先筛选Root ADE matched≤4.12cm、cross≤4.63cm的候选，再取最高S_TF；同分时取较低matched MPJPE，再取较早epoch。如果全部未通过ADE gate，取最高S_TF的诊断候选并标明gate失败。这是本次TF研究的内部选择规则，不表示达到论文rollout目标。

训练过程每5epoch汇报同一validation manifest上的matched/cross曲线；50epoch结束汇报锁定checkpoint的test结果，并附epoch50结果作为固定终点参考。两套结果分开列，不能拼接各checkpoint最好值。

最终表格至少包括checkpoint/epoch、协议、matched/cross数量、target accuracy±聚类CI、target confidence、Root ADE±CI、cross source retention、GT/AE参考、实际cross训练比例及耗时。单seed限制保留，低cross结果按“是否有cross监督、实际覆盖、source retention、token干预响应”分析。

## 启动前需要完成的最小接口工作

1. 新增独立TF50入口，显式关闭`--rollout-val-every`，禁止调用A/B/C或rollout recovery脚本；绑定上述配置、新目录和50epoch上限。
2. 为固定style验证增加teacher-forced模式。现有`evaluate_validation()`默认执行rollout，不能直接沿用；CLI `reconstruct`实现已逐步取GT，可复用。优先批量处理独立time points，降低GT编码与Python循环开销。
3. 主generalization入口已支持241 source rows→240 generated rows，分类与ADE排除GT context，protocol3 manifest保留独立case记录；历史protocol2可显式复播。现有generalization脚本仍使用test split，训练中的checkpoint选择需要单独validation入口。
4. 添加GT条件不被生成结果覆盖、cross标签映射、首帧排除、case/noise固定、无rollout调用及best_tf/latest一致的轻量检查，然后只做短入口smoke。

如果只使用当前训练入口，可关闭rollout、按`best_loss.pt`锁定模型，再以`--flow-eval-mode reconstruct`和新240帧classifier报告test；该评估已排除GT首帧，但训练中的TF style联合选择尚未实现，不能静默声称完整选择协议已实现。

## 资源估计与边界

已完成的真实单步A训练：约11158 updates/epoch、391秒train、408秒含普通validation，每epoch约6.8分钟；旧配置50epoch约5.7 GPU小时。该实测包含recon.1，不能沿用为本轮recon0的耗时预测。stride保持1，因此每epoch窗口数和optimizer update数不因本次修改减少。

关闭recon后，单步训练每microbatch的flow field调用从1次随机t监督+8次Euler降为1次，同时去掉decoder前向与该支路反向；这不是9倍端到端加速承诺，GT latent读取、style conditioning、优化器和I/O仍有成本。本轮尚无真实GPU耗时/显存测量，后续只据实际速度更新预算。若启用可选matched_root与root loss，在线编码和motion loss会增加计算，须单独计时。完整512优先，OOM时明确选择256×2或128×4；donor仍在完整512上选择，grad clip每update一次。

本轮不执行训练、rollout、自动追加实验或中断已有进程。完成条件是50epoch TF run、固定manifest下的matched/cross报告和失败分解；不能先承诺cross成功，也不能以TF高accuracy替代闭环验证。
