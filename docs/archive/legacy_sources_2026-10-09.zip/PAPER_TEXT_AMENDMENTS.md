# 论文修订文本（style prior / selector 部分，可直接粘贴）

用于 R2 minor revision。以下给出**原文 → 建议改写**，每条都只在"把公式说清楚/与实现对齐"的范围内修改，
不改变方法本身。行号对应 `MM-2025-11-0162.R2_Ma.tex`。

---

## 1) 式(3)：补上 TopK 后的重归一化

**原文（约 450-454 行）**

```latex
A style-code selector then predicts a code distribution for each selected slot:
\begin{equation}
    a_{s,j} = \mathcal{G}_j(h_s), \qquad
    \pi_{s,j} = \operatorname{TopK}_{K_s}\!\left(\operatorname{Softmax}(a_{s,j}/\tau)\right),
\end{equation}
where $\tau$ is a temperature parameter and $\operatorname{TopK}_{K_s}$ retains only the $K_s$ largest probabilities to encourage sparse code selection.
```

**建议改为**

```latex
A style-code selector then predicts a code distribution for each selected slot:
\begin{equation}
    a_{s,j} = \mathcal{G}_j(h_s), \quad
    p_{s,j} = \operatorname{Softmax}(a_{s,j}/\tau), \quad
    \pi_{s,j} = \frac{\operatorname{TopK}_{K_s}\!\left(p_{s,j}\right)}
    {\sum_{k}\operatorname{TopK}_{K_s}\!\left(p_{s,j}\right)_k},
\end{equation}
where $\tau$ is a temperature parameter and $\operatorname{TopK}_{K_s}$ retains only the $K_s$ largest
probabilities to encourage sparse code selection. The retained entries are renormalized to sum to one,
so that the weighted aggregation in Eq.~(4) is independent of how much probability mass was dropped.
We write $p_{s,j}$ for the selector distribution and $\pi_{s,j}$ for its sparsified version used to build
the style token.
```

（理由：不重归一化会让式(4) 的 $u_{s,j}$ 幅度随 logits 形状漂移；同时为式(6) 引入 $p_{s,j}$ 记号。）

---

## 2) 式(6)：把 $L_{prior}$ 写成良定形式

**原文（约 465-478 行）**

```latex
During training, the selector is supervised by the offline style-code prior and a sparsity-promoting entropy term:
\begin{equation}
    \mathcal{L}_{prior} =
    \frac{1}{|\Omega|}
    \sum_{j \in \Omega}
    \operatorname{KL}\!\left(\bar{\pi}_{s,j}\,\|\,\pi_{s,j}\right),
    \qquad
    \mathcal{L}_{ent} =
    \frac{1}{|\Omega|}
    \sum_{j \in \Omega}
    \mathcal{H}(\pi_{s,j}),
\end{equation}
where minimizing $\mathcal{L}_{ent}$ encourages peaky selections.
```

**建议改为**

```latex
During training, the selector distribution is supervised by the offline style-code prior and a
sparsity-promoting entropy term:
\begin{equation}
    \mathcal{L}_{prior} =
    \frac{1}{|\Omega|}
    \sum_{j \in \Omega}
    \operatorname{KL}\!\left(\bar{\pi}_{s,j}\,\|\,p_{s,j}\right),
    \qquad
    \mathcal{L}_{ent} =
    \frac{1}{|\Omega|}
    \sum_{j \in \Omega}
    \mathcal{H}(\pi_{s,j}),
\end{equation}
where $p_{s,j}$ is the selector distribution of Eq.~(3) \emph{before} the TopK sparsification, which keeps
$\mathcal{L}_{prior}$ finite (the smoothed prior has full support, whereas $\pi_{s,j}$ is zero outside the
$K_s$ selected entries, so evaluating the KL on $\pi_{s,j}$ would be infinite), and minimizing
$\mathcal{L}_{ent}$ encourages peaky selections. The sparsity of $\pi_{s,j}$ is thus produced by the
entropy term and by the TopK operator itself, while the prior regularizes the selector's code
distribution.
```

（理由：原文的 KL 在数学上恒为 +∞；改成对 $p_{s,j}$ 计算后 KL$=0$ 可达，梯度是标准蒸馏梯度。
若不希望改公式，退一步可把 KL 换成有界的 JS 散度 $\operatorname{JS}(\bar\pi_{s,j}\|\pi_{s,j})$，
但此时存在不可达下界（见 §4 附注），不推荐。）

---

## 3) 补超参数（当前论文只给了符号）

在原"Implementation details"段（约 544-560 行）中，把

```latex
Flow matching is trained for 50 epochs with batch size 512, learning rate
$5\times10^{-4}$, AdamWR, cosine-annealing warm restarts, flow-loss
weight 1.0, and reconstruction-loss weight 0.1.
```

**建议改为**

```latex
Flow matching is trained for 50 epochs with batch size 512, learning rate
$5\times10^{-4}$ annealed with a cosine schedule, flow-loss weight 1.0, and
reconstruction-loss weight 0.1. The style regularizers use weights
$\lambda_{prior}=0.02$ and $\lambda_{ent}=0.02$, with $K_s=4$ codes per slot kept by the TopK operator,
temperature $\tau=1$, Laplace smoothing $\alpha=1$ for the prior, and $M_s=8$ selected slots.
```

（理由：附录写的 "AdamWR / warm restarts" 与实现（AdamW + `CosineAnnealingLR`）不符；λ 值原先缺失。）

---

## 4) 附注：先验的统计性质（可选，但很能提升可信度）

建议在式(2) 之后或附录加一句：

```latex
In practice the per-slot priors are diffuse --- on 100STYLE the average entropy of
$\bar{\pi}_{s,j}$ is $4.8$ nats (upper bound $\log K = 7.6$) and about $81\%$ of the mass lies outside
the top-$K_s$ entries --- so the prior mainly serves to \emph{select} the style-control slots $\Omega$ and
to regularize the selector, while the fine-grained code selection is carried by the TopK operator and,
for out-of-distribution styles, by the code recipe $\rho$. This is consistent with the incomplete
content--style disentanglement discussed in the limitations.
```

（理由：审稿人若复算会发现先验很平；主动说明可避免"KL 下界"一类质疑，也与论文自己承认的
content/style 不完全解耦相互印证。）

---

## 5) clip 分支：改成与实现一致的表述（或补实现）

**原文（约 449 行）**

```latex
For label-based control, $\mathcal{E}_s$ is implemented as an embedding/MLP encoder; for clip-based control, it is implemented as a temporal encoder over the reference style motion.
```

现有代码只实现了 label 分支（`StyleEncoder` 为 `nn.Embedding`，selector 为 embedding+MLP）；
clip/OOD 条件是通过"示例片段的码频 → recipe $\rho$"走式(8) 的 β 通路实现的。两种处理：

- **不补实现（推荐，工作量小）**：改为
  ```latex
  For label-based control, $\mathcal{E}_s$ is implemented as an embedding/MLP encoder. Clip-based
  conditioning is realized through the code recipe of Eq.~(8): the code histogram of the reference
  clip over the selected slots $\Omega$ is used as $\rho$, which also covers out-of-distribution styles.
  ```
- **补实现**：新增 temporal transformer 编码器并用 $m_s$ 训练（属新增能力，需要额外实验与评测）。

---

## 6) 不需要改的部分

式(1)(2)(4)(5)(7)(8)、先验的 Laplace 形式、JS 显著度与 $M_s$ 选择、推理混合 $\tilde\pi=(1-\beta)\pi+\beta\rho$、
$\lambda_{rec}=0.1$、$lr=5\times10^{-4}$、batch 512、50 epochs —— 与代码逐项一致，**保持原文**
（式(7) 的熵项在代码中确实是最小化 $\mathcal H(\pi)$，方向正确）。

---

## 7) FID 特征提取器的描述（Manifold Evaluation 段，约 313 行）

**问题**：现稿写 "we train a feature extractor via a motion **reconstruction** objective"，
但 CAMDM 的实现（也是我们 R2 定稿里"FID uses the feature extractor from the CAMDM
implementation"所承诺的口径）训的是**风格分类器**（交叉熵），不是重建目标；而且提取器的
输入/规模也值得写清（15 个 ybot 关节的局部位置 = 45 维、60 帧窗口、100 个风格、512 维倒数
第二层激活）。

**原文**

```latex
Following \cite{chen2024taming}, we train a feature extractor via a motion reconstruction
objective to obtain high-level semantic features.
```

**建议改为**

```latex
Following \cite{chen2024taming}, FID uses the motion feature extractor from the CAMDM
implementation: a style classifier over 60-frame windows of the local positions of 15 body
joints, trained on all 100 styles of 100STYLE, whose penultimate 512-dimensional activations
serve as the semantic motion features.
```

**配套事实（可写入 response letter / 附录）**：
- 该提取器在本代码库中由 `train_fid_feature_extractor_camdm.py` 复现（与上游
  `Evaluation/feature_extractor/train_classifier.py` 逐项对齐：网络结构、45 维输入、
  clip offset 10、batch 1024、Adam lr 1e-3、50 epoch、无划分、存盘键一致），
  训练数据为全部 100 个风格（`database_100sty_375_memmap_fid_full100`，391,373 个窗口）。
- 唯一有意差异：上游把 100STYLE 重采样到 30 fps，本实现保持原生 60 fps 以便与评测数据同分布；
  上游无镜像增强，本实现默认只用非镜像 clip（`--include-mirror` 另存镜像版）。
- 校验：训练准确率 99.90%（100 类）；无镜像数据上 90.4%，镜像数据 0.8%（训练集中没有镜像）。
