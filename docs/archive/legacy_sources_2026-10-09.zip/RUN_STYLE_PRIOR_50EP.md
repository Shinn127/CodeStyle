# Style-prior 控制器训练（50 epoch，90-style 库 + 150ep 表征）

执行自 [STYLE_PRIOR_TRAINING_PLAN.md](docs/archive/STYLE_PRIOR_TRAINING_PLAN.md)。本文件记录实际运行的配置、过程与结果。

## 1. 运行配置（已核对溯源）

| 项 | 值 |
|---|---|
| 命令 | `run_train_flowmatch_vqvae_controller.sh --epochs 50 --save-every 10`（`STYLE_PRIOR_LOSS=dense`、`STYLE_HIST_WEIGHT=0.02`、`STYLE_ENTROPY_WEIGHT=0.02`）|
| DB | `database_100sty_375_memmap`（90 style，clip 级 90/10/10，5,712,896 训练窗/epoch）|
| 冻结表征 | `checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt`（AE 路径，32×4，K=2048）|
| VQ 目标缓存 | `cache/vq_targets_..._150ep`（meta 的 db/ckpt/32×4/K 与上者全等）|
| 先验 | `cache/style_code_prior_..._150ep.npz`（`split=train`、`smoothing=1.0`、$M_s=8$、$\Omega=[4,9,10,17,18,20,23,24]$；记录 vqvae_ckpt/db/num_codebooks，与本次运行全等）|
| 输出目录 | `checkpoints/flowmatch_vqvae_controller_prior_90st` |
| 日志 | `/tmp/prior_main50.log`（tqdm + 逐 epoch 行）；结构化记录 `history.jsonl` |
| 超参 | batch 512、lr 5e-4 → 1e-5（cosine）、AdamW(wd 1e-4)、grad-clip 1.0、2 层 transformer(256/4/FFN1024)、style slots 8 / TopK 4 / τ=1.0、prediction mode = velocity、recon 0.1 |
| 时间 | 实测 **202.6 s/epoch** → 50 epoch ≈ **2.8 h** |

## 2. 冒烟（2 epoch，先行验证）

| epoch | flow | recon | $L_{prior}$ | $\mathcal{H}(\pi)$ | top1 | 加权占比（flow/recon/prior/ent）|
|---|---|---|---|---|---|---|
| 1 | 0.5371 | 0.1671 | 5.2161 | 0.4086 | 0.900 | 80.6% / 2.5% / **15.7%** / 1.2% |
| 2 | 0.3598 | 0.1070 | 5.1742 | 0.3893 | 0.911 | 74.7% / 2.2% / **21.5%** / 1.6% |
| test | 0.4811 | 0.1477 | 5.1799 | 0.3882 | 0.912 | — |

对照：$L_{prior}$ 的下界 $\mathbb{E}_{\Omega}[\mathcal{H}(\bar\pi)] = **4.834**$ nats（实测本先验）。
冒烟已落在 5.17–5.22，且先验项占比 15.7→21.5%（门槛 ≤30%），top1 ≈ 0.91 不塌。

## 3. 主训练（已完成）

50 epoch / 2.81 h（202.4 s/epoch），`best.pt` = **epoch 49**（best val total loss 0.374432）。
全程 **未触发任何 `[Warn]` 软门禁**。

| epoch | flow | val_flow | recon | $L_{prior}$ | H(π) | top1 | prior 占比 |
|---|---|---|---|---|---|---|---|
| 1 | 0.5371 | 0.5082 | 0.1671 | 5.2161 | 0.4086 | 0.900 | 15.7% |
| 5 | 0.2985 | 0.3758 | 0.0911 | 5.1751 | 0.3880 | 0.912 | 24.7% |
| 10 | 0.2597 | 0.3329 | 0.0838 | 5.1759 | 0.3865 | 0.912 | 27.3% |
| 20 | 0.2293 | 0.2951 | 0.0787 | 5.1762 | 0.3846 | 0.913 | 29.7% |
| 30 | 0.2107 | 0.2750 | 0.0763 | 5.1762 | 0.3831 | 0.913 | 31.4% |
| 40 | 0.1976 | 0.2594 | 0.0748 | 5.1761 | 0.3821 | 0.913 | 32.7% |
| 50 | 0.1918 | 0.2533 | 0.0743 | 5.1760 | 0.3817 | 0.913 | 33.3% |
| **test** | **0.2823** | — | 0.1138 | 5.1810 | 0.3814 | 0.913 | — |

三点结论：

1. **flow/recon 稳定收敛**（train flow 0.537→0.192，val flow 0.508→0.253），说明先验监督没有干扰主任务。
2. **$L_{prior}$ 在第 ~11 epoch 触底 5.176 后不再下降**，比下界 $\mathbb{E}_\Omega[\mathcal H(\bar\pi)]=4.834$
   高 **0.34 nats**。这不是训练不足，而是该损失的定义决定的：$\mathbb{E}_x[\mathrm{KL}(\bar\pi\,\|\,\pi_\theta(x))]
   = \mathrm{CE} \ge \mathcal H(\bar\pi)$，**取等要求 selector 对每个输入都输出与边际先验完全相同的分布**，
   也就是放弃上下文信息；而 flow/teacher-forcing 目标要求它按上下文给出有判别力的码分布。
   0.34 nats 就是"当前 $\lambda_{prior}=0.02$ 下，上下文信息与先验的残余张力"。
3. **prior 占比从 15.7% 升到 33.3%**（超过计划的 ≤30% 目标，但低于 35% 告警线）：分母 flow 在收敛、
   分子 $L_{prior}$ 恒定，这个比例本身不是稳态量。若要让长期占比回到 30% 以下，把 $\lambda_{prior}$
   降到 ~0.015 或让 flow 权重随时间上升即可（属计划 §5 的消融 C）。

## 4a. 评测：风格准确率（matched / cross，h=60，1000 源 × 5 目标）

```bash
FLOW_CKPT=$PWD/checkpoints/flowmatch_vqvae_controller_prior_90st/best.pt \
  ./run_evaluate_minor_revision_generalization.sh --horizons 60
```

| setting | 目标风格准确率 | RootADE (cm) | 备注 |
|---|---|---|---|
| real motion 上界 | **96.40%** | — | 分类器 in-distribution 的自检 |
| matched-style rollout | **64.90%** | 1.348 | |
| cross-style transfer | **10.44%** | 1.790 | |

与上一版控制器（target 模式 + 7 月分类器，`generalization_full_new`）对照：

| setting | 旧：准确率 / RootADE | 新：准确率 / RootADE |
|---|---|---|
| real 上界 | 92.20% | 96.40% |
| matched | 65.40% / **2.610** | 64.90% / **1.348** |
| cross | 5.14% / **2.969** | 10.44% / **1.790** |

- **RootADE 是几何量、与分类器无关，可直接比：matched 2.61→1.35 cm（1.9×）、cross 2.97→1.79 cm（1.7×）**。
- 风格准确率的口径变了（分类器从 7 月 72 维换成 CAMDM 45 维镜像版，上界 92.2%→96.4%），
  所以准确率只能谨慎比：matched 基本持平、cross 翻倍。

## 4b. 评测：运动质量（rollout 口径，90-style 库，19,988 窗口）

```bash
python evaluate_motion_375to291.py --models flowmatch_velocity \
  --flowmatch-velocity-ckpt checkpoints/flowmatch_vqvae_controller_prior_90st/best.pt \
  --flow-vqvae-ckpt checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt \
  --db database_100sty_375_memmap \
  --fid-extractor-ckpt checkpoints/fid_feature_extractor_camdm100_mirror/100style_position_classifier.pth
```

| 指标 | 值 | 参照 |
|---|---|---|
| MPJPE | 5.952 ± 0.035 cm | 表征层 AE 口径 1.32 cm（rollout 自回归累积误差，口径不同）|
| RootADE | 1.344 ± 0.014 cm | 旧控制器 generalization h60 matched 2.610 cm |
| Heading | 2.197 ± 0.016 deg | |
| VelDir | 2.544 ± 0.019 deg | |
| F.S. | 1.015 ± 0.026 cm | 表征层 AE 0.266 cm |
| Jitter | 0.833 ± 0.004 cm | 表征层 AE 0.229 cm |
| FID（池化）| 36.170 ± 0.771 | |
| FID（CAMDM 聚合 /512）| 0.3377 | 参照：纯重建 0.0050 |
| p95 延迟 | 4.384 ms | 控制器 8 步 Euler + VQ 解码 |

注意：这是**全控制器 rollout** 口径（自回归、因果、无 teacher forcing），数值天然大于表征层
AE 口径；与论文 Table 2 的 FSD/Accel 也不同定义，不能直接互引。

## 4. 训练完成后的评测（计划 §7，按序执行）

```bash
PY=/home/shinn/miniforge3/envs/mcc/bin/python
FLOW=$PWD/checkpoints/flowmatch_vqvae_controller_prior_90st/best.pt
VQ=$PWD/checkpoints/vqvae_traj_motion_skip_cat_mlp_375to291_32_4_2048_150ep/best.pt

# ① 控制器级：test 段已含 flow/recon/L_prior/H(pi)/top1（见 history.jsonl 的 "test" 行）

# ② 风格准确率（matched / cross / zero-shot），分类器已切到 CAMDM 口径
PYTHON_BIN=$PY DB=$PWD/database_100sty_375_memmap FLOW_CKPT=$FLOW VQ_CKPT=$VQ \
  ./run_evaluate_minor_revision_generalization.sh

# ③ 运动质量：rollout → 指标
PYTHON_BIN=$PY DB=$PWD/database_100sty_375_memmap FLOW_CKPT=$FLOW VQ_CKPT=$VQ \
  PREFIX=prior_90st ./run_simulate_realtime_flowmatch_control.sh
PYTHON_BIN=$PY ./run_evaluate_motion_375to291.sh --models flowmatch_velocity \
  --flowmatch-velocity-ckpt $FLOW --flow-vqvae-ckpt $VQ \
  --fid-extractor-ckpt $PWD/checkpoints/fid_feature_extractor_camdm100/100style_position_classifier.pth \
  --out-dir eval_results/flowmatch_prior_90st
```

口径提醒：论文 Table 2 的 FID/FSD/Accel/TrajErr 是**全控制器 rollout** 口径，与表征层 AE 口径不同；
风格准确率用的分类器必须与 FID 链路一致（本次已把 wrapper 默认切到
`fid_feature_extractor_camdm100/100style_position_classifier.pth`，可用 `CLASSIFIER_CKPT=` 回退）。

## 5. 验收判据（计划 §1）

| 判据 | 目标 | 结果 | 判定 |
|---|---|---|---|
| $L_{prior}$ | → 4.83 nats（下界）| 5.176（距下界 +0.34）| ✅ 贴住下界（残余为上下文信息，见 §3）|
| prior 占比 | ≤30% | 15.7% → 33.3% | ⚠️ 末段超线（flow 收敛所致，非先验变大）|
| $\mathcal H(\pi)$ | 下降 | 0.4086 → 0.3817 | ✅ |
| top1 | 稳定不塌 | 0.900 → 0.913 | ✅ |
| flow / val flow | 与无 selector 基线同量级 | val 0.508 → 0.253 | ⏳ 待消融 A |
| 下游运动指标 | 不差于旧控制器 | RootADE 1.35 / 1.79 cm（旧 2.61 / 2.97）| ✅（几何量可直接比）|
| rollout 运动质量 | 记录并与基线对照 | MPJPE 5.95 / F.S. 1.02 / jitter 0.83 cm；FID(CAMDM 聚合) 0.338 | ⏳ 待消融 A 才能给"净效果"|

### 执行中发现并修掉的两个口径问题

1. **`evaluate_minor_revision_generalization.py` 不支持 45 维提取器**：它的分类器输入构造写死 24 关节，
   换成 CAMDM 分类器后直接报 `Expected feature dim 45, got 72`。已改为按 checkpoint 的
   `joint_set`/`in_feat` 自动分发（`build_fid_feature_extractor_from_checkpoint`），并在 summary 的
   config 里记录 `classifier_joint_set`；修完先用 `--num-sources 5` 做了端到端小冒烟。
2. **分类器必须与数据的镜像增强同分布**：CAMDM 分类器默认只训了无镜像数据，在混合测试集上
   real-motion 上界只有 **47%**（镜像 clip 上仅 1.85%），会把风格准确率整体压到 ~50%。
   已把该脚本的默认分类器切到**镜像版** `fid_feature_extractor_camdm100_mirror`
   （上界 96.40%，镜像 98.15% / 无镜像 94.81%）。这条同样适用于 FID 链路：在带镜像的库上评测要用镜像版提取器。

---

## 6. 与论文数值的对照审计（2026-10-03）

论文 R2 表 `tab:Quantitative_generalization`：

| Setting | Root ADE (cm) | Style Acc. (%) |
|---|---|---|
| Real motion | -- | 92.30 ± 1.65 |
| Matched-style | 2.747 ± 0.111 | 84.40 ± 2.97 |
| Cross-style | 3.088 ± 0.060 | 71.02 ± 2.61 |
| Unseen-style | 2.913 ± 0.082 | 67.17 ± 3.01 |

在仓库里逐项追溯（遍历所有 `*generalization*` 的 summary 与 per-sample CSV）：

- **Root ADE 与 Real-motion 上界可追溯** → `eval_results/minor_revision_generalization_recipe_seen`：
  上界 92.30%（论文 92.30）、matched RootADE 2.743（论文 2.747）、cross 3.088（论文 3.088）。
- **Style Acc. 三行无法追溯**：同一 run 的 per-sample CSV 给出 top-1 准确率 matched **64.30%** / cross **4.88%**，
  `pred_conf` 为 92.46% / 88.08%，都不等于 84.40 / 71.02 / 67.17；全树（除 .tex）没有任何文件含这三个数。
  也就是说：**论文这三行准确率目前没有可复现出处**（可能是被覆盖的旧 run/旧库，或记录口径错误）。
  另外论文自己的 Discussion 承认 cross-style/zero-shot 存在 "residual content-style interference"、"style misalignment"，
  与 "cross-style 71%" 的乐观数字相矛盾。
- 我们的现行数字（本文件 §4a）：上界 96.40（CAMDM-mirror 分类器）/ 92.30（7 月分类器）、
  matched 64.90、cross 10.44。**结论：轨迹类指标我们优于论文（1.9×/1.7×），风格准确率一列需要重导。**

### requantization 的实测效果（评估期开关，未重训）

| 指标 | `--flow-requantize-z` 关 | 开 | 变化 |
|---|---|---|---|
| MPJPE (cm) | 5.952 | 5.816 | −2.3% |
| RootADE (cm) | 1.344 | 1.353 | +0.7% |
| Heading (deg) | 2.197 | 2.129 | −3.1% |
| VelDir (deg) | 2.544 | 2.477 | −2.6% |
| F.S. (cm) | 1.015 | 1.023 | +0.8% |
| Jitter (cm) | 0.833 | 0.883 | **+6.0%** |
| FID（池化）| 36.170 | 37.719 | +4.3% |
| FID（CAMDM 聚合）| 0.3377 | 0.3093 | −8.4% |
| p95 延迟 (ms) | 4.384 | 4.857 | +10.8% |

即：后验启用的 requantization 只带来小幅精度收益，jitter/FID(池化) 反而变差——与论文
"Re-quantization further improves all metrics" 的说法不一致（他们的模型是在各自设置下训练的，
post-hoc 开关不等价）。

---

## 7. Style Acc 偏低的诊断分解（2026-10-03）

### 7.1 分段归因（同一个 CAMDM-mirror 分类器、同一批测试 clip）

| 阶段 | style acc | 结论 |
|---|---|---|
| real motion（上界） | **95.75%**（n=1200）| 分类器本身没问题 |
| VQ **AE 路径**重建（teacher-forced，表示层单独） | **91.33%** | **表征层几乎无损保留风格** → 问题不在 VQ |
| 控制器 rollout，matched | 64.90% | 掉 26 点：rollout 质量损失 |
| 控制器 rollout，cross | 10.44% | 再掉 54 点：风格-内容耦合 + rollout 噪声 |

cross 的**判别性证据**：pred==source 仅 11.48%、pred==target 10.44%、其余 78% 散落到 98 个类；
吸引子为 Drunk 12.3% / Proud 9.2% / Lunge 4.2%，另有 **9.06% 落在本库不存在的 OOD 风格类**
（Waving、WiggleHips…）→ 典型"运动偏离流形、分类器只能乱猜"，而不是"复刻源风格"。
按目标风格看极不均匀：Roadrunner 58.8%、FlickLegs 58.2%、Chicken 42.7% 对
Balance/Robot/RaisedRightArm/LimpLeft 0.00%；chance≈1.01% → 平均 **10× enrichment**（token 有作用，但弱）。

### 7.2 排除的两个嫌疑

- **style token 没有塌陷**：90 个 token 两两 cosine 均值 0.313（min −0.218，无 >0.99 的重复），
  style 间 top-4 码重叠仅 25%（max 59%）→ selector 输出的风格 token 是可分辨的。
- **不是"复制源风格"**：cross 下 pred==source 只有 11.5%，与 pred==target 相当。

### 7.3 与论文自身消融表的对照（关键）

论文 `tab:flowmatch_ablation`（同一套 metric 代码、100-style 测试集）：

| 方法 | MPJPE (cm) | F.S. (cm) | Jitter (cm) |
|---|---|---|---|
| FM-Velocity | 6.348 | 0.723 | 0.431 |
| FM-Target | 6.089 | 0.611 | 0.374 |
| FM-Velocity + ReQ | 6.291 | 0.696 | 0.397 |
| FM-Target + ReQ | 6.016 | 0.600 | 0.348 |
| **本次控制器（velocity，无 ReQ）** | **5.952** | **1.015** | **0.833** |

- **MPJPE 我们已优于论文最优行**（5.95 vs 6.02），说明 rollout 的"位置精度"没有问题；
- **F.S. / Jitter 约差 2×**（1.015 vs 0.60；0.833 vs 0.35）→ 这是真正该修的运动质量问题，
  它同时压低 matched 与 cross 的 style acc；
- 推论：既然论文自己的 rollout MPJPE≈6.0 cm（与我们同级），在**同一个上界 92.3% 的分类器**下，
  他们的 matched 只有 64.3%（可追溯 run），因此论文表里的 84.40/71.02/67.17 更可能是记录错误，
  而不是"曾有一个远比现在好的控制器"。

---

## 8. Style prior 独立检验（`verify_style_code_prior.py`，21/21 通过）

工具：`python verify_style_code_prior.py --controller-ckpt .../best.pt --expect-entropy-floor 4.834`
（失败时退出码非 0；已加 3 个回归测试，含"篡改 counts / Ω 必须报 FAIL"）

| 检查组 | 结果 |
|---|---|
| 1 溯源 | vqvae_ckpt / db / num_codebooks=32 / num_styles=90 与缓存、库全等 |
| 2 几何 | 行和 1±2.4e-8；Laplace 下界满足（min entry 7.76e-6）；形状一致 |
| 3 **独立重算** | 从 `indices.u16`+`Labels.i32`+`segments.json` 重算：**counts 5,898,240 项 0 误差**；prior/global_prior/slot_saliency 最大偏差 ≤4.4e-8；Ω=[4,9,10,17,18,20,23,24] 与显著性 top-8 完全一致 |
| 4 划分纯度 | train 先验 vs val+test 先验（Ω 上）median JS **0.111**、mean 0.148 → 无泄漏、统计稳定 |
| 5 镜像敏感性 | unmirrored-train vs all-train 在 Ω 上 mean JS **0.076** → 镜像增强基本不改变风格码分布 |
| 6 信息量 | top-1 码平均占 **4.15%**（uniform 0.049%，**85×**）；近均匀行 0/2880；单一码主导行 1/2880（ArmsAboveHead·slot17，0.952）；2048/2048 码都被用到；**Ω 槽位 top-1 集中度 0.069 vs 非 Ω 0.032（2.1×）→ 显著性筛选有效** |
| 7 熵 | $\mathbb E_\Omega[\mathcal H(\bar\pi)]$=**4.8342** nats（文档值 4.834 ✓）；top-4 之外仍有 **80.7%** 质量 |
| 8 与训练后 selector 一致性 | dense KL(π̄‖π)=**0.364** nats（下界 4.834+0.364=5.198 ≈ 训练日志 5.176）；论文式 (6) 的 TopK 稀疏形式 = **18.82 nats**（复现旧 clamp 量级）|

**关键发现（第 8 组的后半）**：selector 在**分布层面**学到了先验（KL 0.36），但**硬选择只有 42.4% 与先验 top-4 重合**
（top-1 码仅 31.9% 相同）。分槽位 18.1%–59.2%；分风格差异明显：

- 对齐好：Monk 68.8%、Star 65.6%、ArmsBehindBack/ArmsBySide/ArmsFolded 59.4%（静态姿态特征强）
- 对齐差：Drunk 21.9%、Rushed 21.9%、Neutral 25.0%、BigSteps 25.0%、TogetherStep 25.0%（locomotion 类）

原因是先验本身弥散（top-4 只承载 ~19% 质量），dense KL 可以很小而 top-4 排序不同。由于 style token 正是用
TopK-4（且 $u=\sum\pi z$ 是这些码的期望）构建的，**token 的风格信号天然偏弱**——这与 cross-style 只有
10× 富集、而非更高，是一致的。可操作的改进：① 降 selector temperature τ 让 π 更尖锐；② 提高 λ_prior；
③ 显式监督 top-K 集合（对先验 top-K 加 ranking/hinge 项，或把期望改成 sharpened softmax）。

---

## 9. 廉价诊断：style token 到底起多大作用（`analysis/diagnose_style_token.py`）

不做任何重训，在**评估期**对训练好的控制器做三组干预（200 源；cross 为每源 5 个随机目标风格，
共 1000 次 rollout）。同一批数据、同一分类器（CAMDM-mirror）：

| 配置 | matched acc | cross acc | token 两两 cos |
|---|---|---|---|
| **mean-token（把 token 换成全体均值 = 零风格信息）** | **13.50%** | 0.70% | 1.000 |
| **baseline（τ=1.0, gain=1, β=0）** | **68.00%** | 7.90% | 0.313 |
| τ=0.5 | 61.00% | 8.50% | 0.327 |
| τ=0.3 | 65.00% | 6.70% | 0.326 |
| token gain ×2 | 31.00% | 6.20% | 0.088 |
| token gain ×3 | 20.50% | 5.00% | 0.032 |
| prior-mix β=0.3（π̃=0.7π+0.3π̄） | 61.00% | 7.90% | 0.310 |
| prior-mix β=0.5 | 54.00% | 6.80% | 0.308 |

（完整 JSON：`eval_results/style_token_diagnostic.json`）

### 结论

1. **token 是被重度使用的，不是被忽略**：换成均值 token 后 matched 从 **68.0% 掉到 13.5%**
   （cross 从 7.9% 掉到 0.7%）——即风格信号几乎全部来自 token，内容本身只值 ~13.5 个点。
   也能读出分解：内容基线 13.5 → 加 token 68.0 → real 上界 96.4，token 填掉了其中约 2/3 的差距。
2. **cross-style 上 token 的有效性只有 ~11× 富集**（0.70% → 7.90%），远低于 matched 的水平
   → 说明 token 能"保持"风格，却难以"覆盖"内容自带的风格。
3. **三条廉价干预全部无效或有害**：锐化 τ（61–65%，不升）、放大 token（31%/20.5%，严重破坏——
   因为 generator 只见过 τ=1 的 token 分布，脱离分布就崩）、推理期混入先验（54–61%，不升）。
   注意 prior-mix 连 top-4 对齐都只从 42.4% 动到 48.7%（先验本身弥散，混一半也推不动排序）。
4. 因此瓶颈不在推理端、不在先验本身、也不在 selector 的分布拟合，而在**训练任务的激励结构**：
   content 与 style 永远来自同一条 clip ⇒ 模型学到的是"续写当前动作"，风格 token 只被用来在
   该风格族内做微调，从未被要求覆盖内容自带的风格。唯一还剩的有效杠杆是**解耦配对训练**
   （content/trajectory 来自源 clip，target latent 来自被请求风格的另一条 clip）+ 可选 style-consistency 损失。
